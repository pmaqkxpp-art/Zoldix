import { lazy, Suspense, useEffect, useState } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import ErrorBoundary from './components/ErrorBoundary.jsx';
import TopBar from './components/TopBar.jsx';
import BackButton from './components/BackButton.jsx';
import Loader from './components/Loader.jsx';
import { initAds, setAdsCurrentRoute } from './config/ads.js';
import { applyDocumentMetadata, loadSiteConfig, subscribeSiteConfig } from './config/siteConfig.js';

const Home = lazy(() => import('./pages/Home.jsx'));
const Vestra = lazy(() => import('./pages/Vestra.jsx'));
const Hina = lazy(() => import('./pages/Hina.jsx'));
const Aero = lazy(() => import('./pages/Aero.jsx'));
const Zestwell = lazy(() => import('./pages/Zestwell.jsx'));
const Admin = lazy(() => import('./pages/admin/Admin.jsx'));

const IMMERSIVE_ROUTES = new Set(['/vestra', '/hina', '/aero', '/zestwell']);

function RouteFallback() {
  return (
    <div
      style={{
        minHeight: '100dvh',
        display: 'grid',
        placeItems: 'center',
        background: 'var(--wrapper-bg, #0d0d10)',
        color: '#f5f3ef',
        fontFamily: 'system-ui, sans-serif',
        fontSize: 13,
        letterSpacing: '0.14em',
        textTransform: 'uppercase'
      }}
    >
      Loading studio…
    </div>
  );
}

export default function App() {
  const { pathname, search } = useLocation();
  const [pageReady, setPageReady] = useState(false);

  const normalizedPath = pathname || '/';
  const isEmbed =
    new URLSearchParams(search).get('embed') === '1' ||
    (typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('embed') === '1');
  const isWrapperRoute = !isEmbed && (normalizedPath === '/' || normalizedPath === '/admin');
  const isImmersiveRoute = !isEmbed && IMMERSIVE_ROUTES.has(normalizedPath);
  const effectiveReady = isEmbed ? true : pageReady;

  useEffect(() => {
    applyDocumentMetadata(loadSiteConfig());
    const unsubCfg = subscribeSiteConfig(applyDocumentMetadata);
    const unsubAds = initAds();
    return () => {
      unsubCfg();
      unsubAds();
    };
  }, []);

  useEffect(() => {
    setAdsCurrentRoute(normalizedPath);
    if (isWrapperRoute) {
      window.scrollTo(0, 0);
    }
  }, [normalizedPath, isWrapperRoute]);

  useEffect(() => {
    if (!isEmbed || typeof window === 'undefined' || window.parent === window) return undefined;

    const isScrollableOverlay = target =>
      Boolean(
        target?.closest?.('.zw-page-overlay, .zw-bag-body, .zw-list-view, .hina-panel, .aero-modal')
      );

    const onWheel = event => {
      if (isScrollableOverlay(event.target)) return;
      if (Math.abs(event.deltaY) >= Math.abs(event.deltaX) && event.deltaY !== 0) {
        event.preventDefault();
        event.stopImmediatePropagation();
        try {
          window.parent.scrollBy({ top: event.deltaY, left: 0, behavior: 'auto' });
        } catch {}
      }
    };

    let tStartX = 0;
    let tStartY = 0;
    let tLastY = 0;
    let verticalLock = false;

    const onTouchStart = event => {
      if (!event.touches || event.touches.length !== 1) return;
      tStartX = event.touches[0].clientX;
      tStartY = event.touches[0].clientY;
      tLastY = tStartY;
      verticalLock = false;
    };

    const onTouchMove = event => {
      if (isScrollableOverlay(event.target)) return;
      if (!event.touches || event.touches.length !== 1) return;
      const curX = event.touches[0].clientX;
      const curY = event.touches[0].clientY;
      if (!verticalLock) {
        const dx = Math.abs(curX - tStartX);
        const dy = Math.abs(curY - tStartY);
        if (dy > 12 && dy > dx * 1.25) {
          verticalLock = true;
        } else if (dx > 12 && dx > dy) {
          return;
        }
      }
      if (verticalLock) {
        const deltaY = tLastY - curY;
        tLastY = curY;
        if (deltaY !== 0) {
          try {
            window.parent.scrollBy({ top: deltaY, left: 0, behavior: 'auto' });
          } catch {}
        }
      }
    };

    window.addEventListener('wheel', onWheel, { capture: true, passive: false });
    window.addEventListener('touchstart', onTouchStart, { capture: true, passive: true });
    window.addEventListener('touchmove', onTouchMove, { capture: true, passive: true });

    return () => {
      window.removeEventListener('wheel', onWheel, { capture: true });
      window.removeEventListener('touchstart', onTouchStart, { capture: true });
      window.removeEventListener('touchmove', onTouchMove, { capture: true });
    };
  }, [isEmbed]);

  return (
    <>
      {!isEmbed && <Loader routePath={normalizedPath} onReadyChange={setPageReady} />}

      <div style={!effectiveReady ? { visibility: 'hidden' } : undefined}>
        {isWrapperRoute && <TopBar />}

        <Routes>
          <Route
            path="/"
            element={
              <ErrorBoundary label="Home">
                <Suspense fallback={<RouteFallback />}>
                  <Home pageReady={effectiveReady} />
                </Suspense>
              </ErrorBoundary>
            }
          />
          <Route
            path="/vestra"
            element={
              <ErrorBoundary label="VESTRA">
                <Suspense fallback={<RouteFallback />}>
                  <Vestra pageReady={effectiveReady} />
                </Suspense>
              </ErrorBoundary>
            }
          />
          <Route
            path="/hina"
            element={
              <ErrorBoundary label="HINA">
                <Suspense fallback={<RouteFallback />}>
                  <Hina pageReady={effectiveReady} />
                </Suspense>
              </ErrorBoundary>
            }
          />
          <Route
            path="/aero"
            element={
              <ErrorBoundary label="KYNE AERO.VISION">
                <Suspense fallback={<RouteFallback />}>
                  <Aero pageReady={effectiveReady} />
                </Suspense>
              </ErrorBoundary>
            }
          />
          <Route
            path="/zestwell"
            element={
              <ErrorBoundary label="Zestwell">
                <Suspense fallback={<RouteFallback />}>
                  <Zestwell pageReady={effectiveReady} />
                </Suspense>
              </ErrorBoundary>
            }
          />
          <Route
            path="/admin"
            element={
              <ErrorBoundary label="Admin Control Panel">
                <Suspense fallback={<RouteFallback />}>
                  <Admin />
                </Suspense>
              </ErrorBoundary>
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>

        {isImmersiveRoute && effectiveReady && <BackButton />}
      </div>
    </>
  );
}
