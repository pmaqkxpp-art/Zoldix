import { DEFAULT_SITE_CONFIG } from './defaults.js';

const STORAGE_KEY = 'siteConfig';
const AUTH_HASH_KEY = 'zoldix_admin_pw_hash_v2';
const SESSION_UNLOCK_KEY = 'zoldix_admin_unlocked_v2';
const DEFAULT_ADMIN_PW_HASH = '235634d932f59b6743356a787f1684444bdefd01388bb51622df3b89161a5523';
const CHANGE_EVENT = 'zoldix:config-changed';

const deepClone = value => JSON.parse(JSON.stringify(value));

const isPlainObject = value => Boolean(value) && typeof value === 'object' && !Array.isArray(value);

const mergeDeep = (base, override) => {
  if (!isPlainObject(base) || !isPlainObject(override)) {
    return override !== undefined ? override : deepClone(base);
  }
  const out = {};
  const keys = new Set([...Object.keys(base), ...Object.keys(override)]);
  keys.forEach(key => {
    if (!(key in override)) {
      out[key] = deepClone(base[key]);
    } else if (isPlainObject(base[key]) && isPlainObject(override[key])) {
      out[key] = mergeDeep(base[key], override[key]);
    } else if (Array.isArray(base[key]) && Array.isArray(override[key])) {
      out[key] = deepClone(override[key]);
    } else {
      out[key] = deepClone(override[key]);
    }
  });
  return out;
};

let cachedConfig = null;

export const loadSiteConfig = () => {
  if (cachedConfig) return cachedConfig;
  const base = deepClone(DEFAULT_SITE_CONFIG);
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      cachedConfig = mergeDeep(base, parsed);
    } else {
      cachedConfig = base;
    }
  } catch {
    cachedConfig = base;
  }
  return cachedConfig;
};

export const saveSiteConfig = nextConfig => {
  const merged = mergeDeep(DEFAULT_SITE_CONFIG, nextConfig);
  cachedConfig = merged;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
  } catch (err) {
    console.warn('Could not persist siteConfig to localStorage (storage quota may be exceeded).', err);
  }
  applyDocumentMetadata(merged);
  window.dispatchEvent(new CustomEvent(CHANGE_EVENT, { detail: merged }));
  return merged;
};

export const updateSiteConfig = updater => {
  const current = deepClone(loadSiteConfig());
  const next = typeof updater === 'function' ? updater(current) : mergeDeep(current, updater);
  return saveSiteConfig(next);
};

export const resetSiteConfig = () => {
  const fresh = deepClone(DEFAULT_SITE_CONFIG);
  cachedConfig = fresh;
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {}
  applyDocumentMetadata(fresh);
  window.dispatchEvent(new CustomEvent(CHANGE_EVENT, { detail: fresh }));
  return fresh;
};

export const getAsset = key => {
  const cfg = loadSiteConfig();
  const val = cfg?.assets?.[key];
  if (val !== undefined && val !== null && val !== '') {
    return val;
  }
  return DEFAULT_SITE_CONFIG.assets[key];
};

export const getDefaultAsset = key => DEFAULT_SITE_CONFIG.assets[key];

export const isValidMediaUrl = (url, allowDataUrl = true) => {
  if (typeof url !== 'string') return false;
  const trimmed = url.trim();
  if (!trimmed) return false;
  if (allowDataUrl && /^data:(image|video)\/[a-zA-Z0-9+.-]+;base64,/i.test(trimmed)) return true;
  if (/^blob:/i.test(trimmed)) return true;
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
};

export const isValidHttpUrl = url => {
  if (typeof url !== 'string') return false;
  try {
    const parsed = new URL(url.trim());
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
};

export const subscribeSiteConfig = listener => {
  const handler = event => listener(event.detail || loadSiteConfig());
  window.addEventListener(CHANGE_EVENT, handler);
  return () => window.removeEventListener(CHANGE_EVENT, handler);
};

export const applyDocumentMetadata = (cfg = loadSiteConfig()) => {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  if (cfg.theme?.bgColor) {
    root.style.setProperty('--wrapper-bg', cfg.theme.bgColor);
    root.style.setProperty('--zoldix-loader-bg', cfg.theme.bgColor);
  }
  if (cfg.theme?.accentColor) {
    root.style.setProperty('--wrapper-accent', cfg.theme.accentColor);
    root.style.setProperty('--zoldix-loader-accent', cfg.theme.accentColor);
  }
  if (cfg.brand?.pageTitle) {
    document.title = cfg.brand.pageTitle;
  }
  if (cfg.brand?.faviconUrl) {
    const fav = document.getElementById('zoldix-favicon');
    if (fav) fav.setAttribute('href', cfg.brand.faviconUrl);
  }
};

const sha256Js = ascii => {
  const rightRotate = (value, amount) => (value >>> amount) | (value << (32 - amount));
  const mathPow = Math.pow;
  const maxWord = mathPow(2, 32);
  let result = '';
  const words = [];
  const utf8 = unescape(encodeURIComponent(ascii));
  const asciiBitLength = utf8.length * 8;
  const hash = [];
  const k = [];
  let primeCounter = 0;
  const isComposite = {};
  for (let candidate = 2; primeCounter < 64; candidate += 1) {
    if (!isComposite[candidate]) {
      for (let i = 0; i < 313; i += candidate) isComposite[i] = candidate;
      hash[primeCounter] = (mathPow(candidate, 0.5) * maxWord) | 0;
      k[primeCounter] = (mathPow(candidate, 1 / 3) * maxWord) | 0;
      primeCounter += 1;
    }
  }
  const padded = utf8 + '\x80';
  let paddedStr = padded;
  while ((paddedStr.length % 64) - 56) paddedStr += '\x00';
  for (let i = 0; i < paddedStr.length; i += 1) {
    const j = paddedStr.charCodeAt(i);
    if (j >> 8) return '';
    words[i >> 2] |= j << (((3 - i) % 4) * 8);
  }
  words[words.length] = (asciiBitLength / maxWord) | 0;
  words[words.length] = asciiBitLength;
  for (let j = 0; j < words.length; j += 16) {
    const w = words.slice(j, j + 16);
    const oldHash = hash.slice(0);
    for (let i = 0; i < 64; i += 1) {
      const w15 = w[i - 15];
      const w2 = w[i - 2];
      const a = hash[0];
      const e = hash[4];
      const temp1 =
        hash[7] +
        (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25)) +
        ((e & hash[5]) ^ (~e & hash[6])) +
        k[i] +
        (w[i] =
          i < 16
            ? w[i]
            : (w[i - 16] +
                (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3)) +
                w[i - 7] +
                (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))) |
              0);
      const temp2 =
        (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22)) +
        ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
      hash.unshift((temp1 + temp2) | 0);
      hash[4] = (hash[4] + temp1) | 0;
      hash.pop();
    }
    for (let i = 0; i < 8; i += 1) hash[i] = (hash[i] + oldHash[i]) | 0;
  }
  for (let i = 0; i < 8; i += 1) {
    for (let j = 3; j + 1; j -= 1) {
      const b = (hash[i] >> (j * 8)) & 255;
      result += (b < 16 ? '0' : '') + b.toString(16);
    }
  }
  return result;
};

export const hashPassword = async plainText => {
  if (typeof crypto !== 'undefined' && crypto.subtle && typeof TextEncoder !== 'undefined') {
    const data = new TextEncoder().encode(plainText);
    const digest = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(digest))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }
  return sha256Js(plainText);
};

export const ensureDefaultPasswordHash = async () => {
  let stored = null;
  try {
    localStorage.removeItem('zoldix_admin_pw_hash');
    sessionStorage.removeItem('zoldix_admin_unlocked');
    stored = localStorage.getItem(AUTH_HASH_KEY);
  } catch {}
  if (!stored) {
    stored = DEFAULT_ADMIN_PW_HASH;
    try {
      localStorage.setItem(AUTH_HASH_KEY, stored);
    } catch {}
  }
  return stored;
};

export const verifyAdminPassword = async plainText => {
  const expected = await ensureDefaultPasswordHash();
  const actual = await hashPassword(plainText);
  return actual === expected;
};

export const updateAdminPassword = async newPlainText => {
  const hashed = await hashPassword(newPlainText);
  try {
    localStorage.setItem(AUTH_HASH_KEY, hashed);
  } catch {}
  return hashed;
};

export const isAdminSessionUnlocked = () => false;

export const setAdminSessionUnlocked = unlocked => {
  try {
    if (!unlocked) sessionStorage.removeItem(SESSION_UNLOCK_KEY);
  } catch {}
};

export const exportSiteConfigJson = () => JSON.stringify(loadSiteConfig(), null, 2);

export const importSiteConfigJson = jsonText => {
  const parsed = JSON.parse(jsonText);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error('Invalid JSON structure: expected a configuration object.');
  }
  return saveSiteConfig(parsed);
};
