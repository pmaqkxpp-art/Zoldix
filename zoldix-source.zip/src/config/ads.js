import { DEFAULT_ADS } from './defaults.js';
import { loadSiteConfig } from './siteConfig.js';

const LAST_SHOWN_KEY = 'zoldix_ad_last_shown';
const CLICK_COUNT_KEY = 'zoldix_ad_click_count';
const DRAG_THRESHOLD_PX = 5;

let initialized = false;
let currentRoute = '/';
let pointerDownPos = null;
let clickCount = 0;

try {
  clickCount = Math.max(0, Number(localStorage.getItem(CLICK_COUNT_KEY)) || 0);
} catch {
  clickCount = 0;
}

const getLastShown = () => {
  try {
    return Number(localStorage.getItem(LAST_SHOWN_KEY)) || 0;
  } catch {
    return 0;
  }
};

const setLastShown = ts => {
  try {
    localStorage.setItem(LAST_SHOWN_KEY, String(ts));
  } catch {}
};

const saveClickCount = count => {
  try {
    localStorage.setItem(CLICK_COUNT_KEY, String(count));
  } catch {}
};

const isExcludedTarget = target => {
  if (!(target instanceof Element)) return false;
  if (target.closest('#zoldix-boot-loader, [data-loader-overlay], [data-no-ad]')) {
    return true;
  }
  return false;
};

const isRouteExcluded = (route, excludeRoutes) => {
  const list = Array.isArray(excludeRoutes) ? excludeRoutes : DEFAULT_ADS.excludeRoutes;
  return list.some(pattern => {
    if (!pattern) return false;
    const clean = pattern.trim();
    if (!clean) return false;
    return route === clean || route.startsWith(`${clean}/`);
  });
};

const onPointerDown = event => {
  if (!event.isTrusted) return;
  if (event.button !== undefined && event.button !== 0) return;
  pointerDownPos = { x: event.clientX, y: event.clientY };
};

const onCaptureClick = event => {
  if (!event.isTrusted) return;
  if (isExcludedTarget(event.target)) {
    pointerDownPos = null;
    return;
  }

  if (pointerDownPos) {
    const dx = event.clientX - pointerDownPos.x;
    const dy = event.clientY - pointerDownPos.y;
    pointerDownPos = null;
    if (Math.hypot(dx, dy) > DRAG_THRESHOLD_PX) {
      return;
    }
  }

  const cfg = loadSiteConfig();
  const ads = { ...DEFAULT_ADS, ...(cfg.ads || {}) };

  if (!ads.enabled) return;
  if (!ads.url || typeof ads.url !== 'string') return;
  if (isRouteExcluded(currentRoute, ads.excludeRoutes)) return;

  const interval = Math.max(1, Number(ads.clickInterval) || 1);
  const cooldownMs = Math.max(0, Number(ads.cooldownSeconds) || 0) * 1000;

  clickCount += 1;
  saveClickCount(clickCount);

  if (clickCount < interval) return;

  const now = Date.now();
  const elapsed = now - getLastShown();
  if (elapsed < cooldownMs) return;

  clickCount = 0;
  saveClickCount(0);
  setLastShown(now);

  try {
    const opened = window.open(ads.url, '_blank', 'noopener,noreferrer');
    if (opened) {
      opened.opener = null;
    }
  } catch {
    // Fail silently when popups are blocked
  }
};

export const setAdsCurrentRoute = pathname => {
  currentRoute = pathname || '/';
};

export const initAds = () => {
  if (initialized || typeof document === 'undefined') return () => {};
  initialized = true;
  document.addEventListener('pointerdown', onPointerDown, true);
  document.addEventListener('click', onCaptureClick, true);
  return () => {
    initialized = false;
    document.removeEventListener('pointerdown', onPointerDown, true);
    document.removeEventListener('click', onCaptureClick, true);
  };
};
