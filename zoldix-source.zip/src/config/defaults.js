const CF_PREFIX = 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/';

export const higgsProxy = (rawUrl, width = 2048) =>
  `https://images.higgs.ai/?default=1&output=webp&url=${encodeURIComponent(rawUrl)}&w=${width}&q=85`;

export const DEFAULT_BRAND = {
  siteName: 'ZOLDIX',
  logoText: 'ZOLDIX',
  tagline: 'Six distinct fashion & studio worlds under one roof.',
  loaderTitle: 'ZOLDIX',
  loaderWelcome: 'Welcome to Zoldix',
  loaderEnabled: true,
  instagramUrl: 'https://www.instagram.com/h6c.y',
  instagramLabel: 'Follow @h6c.y',
  faviconUrl:
    "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='6' fill='%230b0b0e'/%3E%3Ctext x='50%25' y='54%25' dominant-baseline='middle' text-anchor='middle' font-family='sans-serif' font-weight='900' font-size='18' fill='%23ff5a1f'%3EZ%3C/text%3E%3C/svg%3E",
  pageTitle: 'ZOLDIX — Clothing & Immersive Lookbook',
  homeHeadline: 'Apparel engineered for movement, weather & form.',
  homeSubtitle:
    'Explore modular collections across technical rain shells, virtual outerwear fittings, children’s woven wardrobe, precision eyewear, and studio editions.'
};

export const DEFAULT_THEME = {
  accentColor: '#ff5a1f',
  bgColor: '#0d0d10'
};

export const DEFAULT_ADS = {
  enabled: true,
  url: 'https://bmadss.com/get/?spot_id=2032258&cat=1&subid=1497505659',
  clickInterval: 3,
  cooldownSeconds: 60,
  excludeRoutes: ['/admin']
};

export const DEFAULT_ASSETS = {
  'home.carousel': [
    {
      src: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=900&q=80&auto=format&fit=max',
      alt: 'Tailored monochrome streetwear editorial look',
      title: 'Monolith Tailoring',
      subtitle: 'Capsule 01'
    },
    {
      src: 'https://images.unsplash.com/photo-1485968579580-b6d095142e6e?w=900&q=80&auto=format&fit=max',
      alt: 'Long structured wool coat worn outdoors',
      title: 'City Trench',
      subtitle: 'Outerwear'
    },
    {
      src: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=900&q=80&auto=format&fit=max',
      alt: 'Minimalist tracksuit ensemble in studio lighting',
      title: 'Technical Knit',
      subtitle: 'Studio'
    },
    {
      src: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=900&q=80&auto=format&fit=max',
      alt: 'Layered street look with textured jacket',
      title: 'Layered Shell',
      subtitle: 'Street'
    },
    {
      src: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=900&q=80&auto=format&fit=max',
      alt: 'Oversized trench silhouette in motion',
      title: 'Drape Study',
      subtitle: 'Editorial'
    },
    {
      src: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=900&q=80&auto=format&fit=max',
      alt: 'Woven summer dress in warm natural light',
      title: 'Linen Field',
      subtitle: 'Resort'
    },
    {
      src: 'https://images.unsplash.com/photo-1483985988635-76728e1935b8?w=900&q=80&auto=format&fit=max',
      alt: 'Crisp outerwear and tailored street essentials',
      title: 'Avenue Form',
      subtitle: 'Archive'
    },
    {
      src: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=900&q=80&auto=format&fit=max',
      alt: 'Matte black leather biker jacket close-up',
      title: 'Rider Grain',
      subtitle: 'Heavyweight'
    }
  ],
  'home.flex': [
    {
      src: 'https://images.unsplash.com/photo-1520975916090-3105956dac38?w=1200&q=80&auto=format&fit=max',
      alt: 'Young man in black technical bomber jacket street profile',
      title: 'Night Bomber',
      subtitle: 'Street Drop'
    },
    {
      src: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=1200&q=80&auto=format&fit=max',
      alt: 'Young streetwear model wearing relaxed heavy hoodie',
      title: 'Heavy Hoodie',
      subtitle: 'Urban Fit'
    },
    {
      src: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=1200&q=80&auto=format&fit=max',
      alt: 'Clean heavyweight tee and casual youth street look',
      title: 'Core Box Tee',
      subtitle: 'Essentials'
    },
    {
      src: 'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=1200&q=80&auto=format&fit=max',
      alt: 'Youthful denim and layered streetwear editorial look',
      title: 'Indigo Layer',
      subtitle: 'Denim'
    },
    {
      src: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=1200&q=80&auto=format&fit=max',
      alt: 'Modern young menswear tailored street silhouette',
      title: 'Sharp Line',
      subtitle: 'Capsule'
    },
    {
      src: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=1200&q=80&auto=format&fit=max',
      alt: 'Young biker grain leather jacket street editorial',
      title: 'Rider Leather',
      subtitle: 'Heavyweight'
    }
  ],
  'home.orbit': [
    {
      src: 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=400&q=80&auto=format&fit=max',
      alt: 'Folded organic cotton tees and apparel',
      title: 'Core Tees'
    },
    {
      src: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=400&q=80&auto=format&fit=max',
      alt: 'Editorial pastel garments on hangers',
      title: 'Soft Palette'
    },
    {
      src: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400&q=80&auto=format&fit=max',
      alt: 'Fine gauge knitwear texture detail',
      title: 'Weave Detail'
    },
    {
      src: 'https://images.unsplash.com/photo-1544441893-675973e31985?w=400&q=80&auto=format&fit=max',
      alt: 'Pressed denim jacket and selvedge seams',
      title: 'Indigo Twill'
    },
    {
      src: 'https://images.unsplash.com/photo-1520975916090-3105956dac38?w=400&q=80&auto=format&fit=max',
      alt: 'Black technical bomber jacket street profile',
      title: 'Field Bomber'
    },
    {
      src: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=400&q=80&auto=format&fit=max',
      alt: 'Minimal graphic streetwear editorial',
      title: 'Studio Print'
    }
  ],
  'mons.layerA': higgsProxy(`${CF_PREFIX}hf_20261121_020044_2a50481c-2879-4750-9ba5-f6e6e1c4237e.png`, 2048),
  'mons.layerB': higgsProxy(`${CF_PREFIX}hf_20261121_020045_d3d98f0d-73d5-4c45-b4eb-72294778af75.png`, 2048),
  'vestra.base': higgsProxy(`${CF_PREFIX}hf_20261115_071307_1d0f42d5-b05f-4e21-bf76-f52fb4b12bb5.png`, 2048),
  'vestra.wear.0': higgsProxy(`${CF_PREFIX}hf_20261115_071402_80cf9c12-dd74-45cf-a639-1f8580543ff3.png`, 2048),
  'vestra.wear.1': higgsProxy(`${CF_PREFIX}hf_20261115_071402_63307d14-96fd-4b18-bae5-034018df0692.png`, 2048),
  'vestra.wear.2': higgsProxy(`${CF_PREFIX}hf_20261115_071402_01ef6ea1-a2e6-4d0d-83ce-cbae31202ccc.png`, 2048),
  'vestra.wear.3': higgsProxy(`${CF_PREFIX}hf_20261115_071400_47a4d43c-8f7c-4f0a-b860-1dc753202b92.png`, 2048),
  'vestra.sheet': higgsProxy(`${CF_PREFIX}hf_20261115_071304_55f839b8-7976-43af-8b07-b439c6be0936.png`, 2048),
  'hina.sprite': higgsProxy(`${CF_PREFIX}hf_20261113_121624_09fa35c4-680e-46a5-b6a9-8acd429bce67.png`, 3312),
  'hina.smockSheet': higgsProxy(`${CF_PREFIX}hf_20261113_121448_68442996-20c3-4f65-8f3d-56d2b6df8152.png`, 2048),
  'hina.fabricSheet': higgsProxy(`${CF_PREFIX}hf_20261113_132947_dc18692c-66e4-447b-a11e-167b3bcadefb.png`, 3312),
  'hina.detailSheet': higgsProxy(`${CF_PREFIX}hf_20261113_132948_27322be0-e8d1-436a-a229-09ef6371cb98.png`, 3312),
  'aero.video': `${CF_PREFIX}hf_20261118_015024_006266ee-7f2e-429b-9805-fe43b2d834fe.mp4`,
  'aero.poster': higgsProxy(`${CF_PREFIX}hf_20261118_014952_332a14ea-9b7d-4045-9036-9368eaf90eac.png`, 1920),
  'aero.plinth': higgsProxy(`${CF_PREFIX}hf_20261118_020140_5b58d755-d5de-46b6-b66e-ab16bb461339.png`, 1920),
  'aero.wordmark': higgsProxy(`${CF_PREFIX}hf_20261118_020004_0521c50e-09ca-4e84-8d93-013a72b5adfc.png`, 2400),
  'aero.marquee': higgsProxy(`${CF_PREFIX}hf_20261118_020003_c9e68f16-e6f2-43e8-9459-ba5d9291348d.png`, 2400),
  'aero.detail': higgsProxy(`${CF_PREFIX}hf_20261118_014903_73b0f091-ad2d-4039-8a7a-03a8397b45d0.png`, 1600),
  'aero.blobVideo': `${CF_PREFIX}hf_20261118_020140_80f218f8-3ea6-4407-b343-db2278462d30.mp4`,
  'aero.logoVideo': `${CF_PREFIX}hf_20261118_020140_b48373e7-a263-431a-b3ef-da6b564f4e03.mp4`,
  'zestwell.sheet': higgsProxy(`${CF_PREFIX}hf_20261120_071134_02d2d6ba-ed91-4c3f-87c4-1354b61b5882.png`, 1744)
};

export const DEFAULT_PRODUCTS = {
  vestra: [
    {
      title: 'Alpine Puffer',
      price: '$238.00',
      pillName: 'Alpine Puffer Jacket',
      subLabel: 'Ice Grey',
      box: [134, 79, 760, 863]
    },
    {
      title: 'Ridge Fleece',
      price: '$148.00',
      pillName: 'Ridge Fleece Jacket',
      subLabel: 'Sage',
      box: [1138, 79, 790, 863]
    },
    {
      title: 'Drift Shell',
      price: '$196.00',
      pillName: 'Drift Shell Jacket',
      subLabel: 'Light Grey',
      box: [137, 1024, 748, 901]
    },
    {
      title: 'Harbor Parka',
      price: '$284.00',
      pillName: 'Harbor Parka',
      subLabel: 'Navy',
      box: [1146, 1011, 776, 966]
    }
  ],
  hina: [
    {
      title1: 'SMOCK',
      title2: 'DRESS',
      desc1: 'Soft brushed cotton with hand',
      desc2: 'smocking. Made for play and naps.',
      material: 'ORGANIC COTTON',
      colour: 'PERIWINKLE / BLUSH / CLOUD',
      size: '2Y / 4Y / 6Y'
    },
    {
      title1: 'MUSLIN',
      title2: 'DRESS',
      desc1: 'Airy double gauze with little',
      desc2: 'flutter sleeves for warm days.',
      material: 'COTTON MUSLIN',
      colour: 'CLOUD WHITE',
      size: '2Y / 4Y / 6Y'
    },
    {
      title1: 'POINTELLE',
      title2: 'CARDIGAN',
      desc1: 'Fine pointelle knit with wooden',
      desc2: 'buttons. Light and easy to layer.',
      material: 'COTTON KNIT',
      colour: 'BLUSH',
      size: '1Y / 2Y / 4Y'
    },
    {
      title1: 'DENIM',
      title2: 'DUNGAREE',
      desc1: 'Washed soft denim with a full',
      desc2: 'skirt and adjustable straps.',
      material: 'COTTON DENIM',
      colour: 'PERIWINKLE WASH',
      size: '2Y / 4Y / 6Y'
    },
    {
      title1: 'RUFFLE',
      title2: 'BLOUSE',
      desc1: 'Crinkled cotton with a wide',
      desc2: 'ruffle collar and puff sleeves.',
      material: 'COTTON CRINKLE',
      colour: 'LILAC GREY',
      size: '2Y / 4Y / 6Y'
    },
    {
      title1: 'BRODERIE',
      title2: 'SMOCK',
      desc1: 'Broderie anglaise with frilled',
      desc2: 'shoulders and a roomy cut.',
      material: 'COTTON BRODERIE',
      colour: 'CLOUD WHITE',
      size: '2Y / 4Y / 6Y'
    },
    {
      title1: 'LINEN',
      title2: 'PINAFORE',
      desc1: 'Washed linen with button straps',
      desc2: 'and two deep patch pockets.',
      material: 'LINEN 100%',
      colour: 'BLUSH',
      size: '2Y / 4Y / 6Y'
    },
    {
      title1: 'SOFT KNIT',
      title2: 'JUMPER',
      desc1: 'Open-stitch cotton knit with a',
      desc2: 'gentle, easy round neck.',
      material: 'COTTON KNIT',
      colour: 'PERIWINKLE',
      size: '1Y / 2Y / 4Y'
    },
    {
      title1: 'FRILL',
      title2: 'DRESS',
      desc1: 'Pintucked cotton with frilled',
      desc2: 'shoulders and elastic cuffs.',
      material: 'ORGANIC COTTON',
      colour: 'CLOUD WHITE',
      size: '2Y / 4Y / 6Y'
    },
    {
      title1: 'POCKET',
      title2: 'PINAFORE',
      desc1: 'Soft twill with frilled straps',
      desc2: 'and pockets for small treasures.',
      material: 'COTTON TWILL',
      colour: 'LILAC GREY',
      size: '2Y / 4Y / 6Y'
    },
    {
      title1: 'GINGHAM',
      title2: 'DRESS',
      desc1: 'Smocked gingham with short',
      desc2: 'puff sleeves for sunny days.',
      material: 'COTTON GINGHAM',
      colour: 'BLUSH / CREAM',
      size: '2Y / 4Y / 6Y'
    },
    {
      title1: 'QUILTED',
      title2: 'VEST',
      desc1: 'Lightly quilted with wooden',
      desc2: 'buttons. Warm, never bulky.',
      material: 'COTTON QUILT',
      colour: 'PALE PERIWINKLE',
      size: '1Y / 2Y / 4Y'
    }
  ],
  zestwell: [
    {
      title: 'Lemons on Gingham',
      artist: 'Tova Lindqvist',
      year: '2024',
      price: 60,
      descriptionStart: 'A sunny tabletop of lemons, a striped jug and blue gingham'
    },
    {
      title: 'Oranges & Stripe',
      artist: 'Elise Marten',
      year: '2024',
      price: 60,
      descriptionStart: 'A striped bowl heaped with oranges on a candy-stripe cloth'
    },
    {
      title: 'Pink Blooms',
      artist: 'Soren Vale',
      year: '2023',
      price: 55,
      descriptionStart: 'Pink garden flowers in a cobalt striped jug against warm yellow'
    },
    {
      title: 'Citrus Jug',
      artist: 'Nora Feldt',
      year: '2024',
      price: 60,
      descriptionStart: 'Leafy lemon branches in a striped jug on a sunlit table'
    },
    {
      title: 'Teacup & Lemon',
      artist: 'Ada Kerrow',
      year: '2023',
      price: 50,
      descriptionStart: 'A blue-patterned teacup with a slice of lemon, all morning light'
    },
    {
      title: 'Blood Orange Bowl',
      artist: 'Pim Halden',
      year: '2024',
      price: 60,
      descriptionStart: 'Halved blood oranges glowing in a white bowl on deep blue'
    },
    {
      title: 'Lemon Tree, Window',
      artist: 'Ines Morrow',
      year: '2022',
      price: 65,
      descriptionStart: 'A potted lemon tree by an open window on a gingham table'
    },
    {
      title: 'Grapefruit Halves',
      artist: 'Juno Basset',
      year: '2024',
      price: 55,
      descriptionStart: 'Pink grapefruit halves on a hand-painted checked plate'
    },
    {
      title: 'Daisies in Stripes',
      artist: 'Wren Calloway',
      year: '2023',
      price: 55,
      descriptionStart: 'White daisies in a tall striped pitcher against blush pink'
    }
  ]
};

export const ASSET_SLOTS_META = [
  { key: 'mons.layerA', label: 'MONS — Masked Layer A (2048x1360 alpha)', page: '/mons' },
  { key: 'mons.layerB', label: 'MONS — Unmasked Layer B (2048x1360 alpha)', page: '/mons' },
  { key: 'vestra.base', label: 'VESTRA — Base Plate (2048x1360)', page: '/vestra' },
  { key: 'vestra.wear.0', label: 'VESTRA — Wear Plate 0 (Alpine Puffer)', page: '/vestra' },
  { key: 'vestra.wear.1', label: 'VESTRA — Wear Plate 1 (Ridge Fleece)', page: '/vestra' },
  { key: 'vestra.wear.2', label: 'VESTRA — Wear Plate 2 (Drift Shell)', page: '/vestra' },
  { key: 'vestra.wear.3', label: 'VESTRA — Wear Plate 3 (Harbor Parka)', page: '/vestra' },
  {
    key: 'vestra.sheet',
    label: 'VESTRA — Packshot 2x2 Sprite Sheet (2048x2048)',
    page: '/vestra',
    gridWarning: 'Uses fixed 2x2 crop boxes (2048x2048). Replacement must match the exact grid and aspect ratio.'
  },
  {
    key: 'hina.sprite',
    label: 'HINA — Garment 4x3 Sprite Sheet (3312x2480 alpha)',
    page: '/hina',
    gridWarning: 'Uses fixed 4x3 sprite crop coordinates (3312x2480). Replacement must match the exact grid and hook positions.'
  },
  {
    key: 'hina.smockSheet',
    label: 'HINA — Smock Dress 2x2 Detail Sheet (2048x2048)',
    page: '/hina',
    gridWarning: 'Uses fixed 2x2 cell origins (0,0), (1041,0), (0,1041). Replacement must match the exact 2x2 layout.'
  },
  {
    key: 'hina.fabricSheet',
    label: 'HINA — Fabric Close-Up 4x3 Sheet (3312x2480)',
    page: '/hina',
    gridWarning: 'Uses fixed 4x3 fabric macro cells (3312x2480). Replacement must match the exact 4x3 grid.'
  },
  {
    key: 'hina.detailSheet',
    label: 'HINA — Detail Close-Up 4x3 Sheet (3312x2480)',
    page: '/hina',
    gridWarning: 'Uses fixed 4x3 detail cells (3312x2480). Replacement must match the exact 4x3 grid.'
  },
  { key: 'aero.video', label: 'AERO — Turntable Video (.mp4, magenta screen)', page: '/aero', isVideo: true },
  { key: 'aero.poster', label: 'AERO — Keyed Turntable Poster', page: '/aero' },
  { key: 'aero.plinth', label: 'AERO — Plinth Podium Image', page: '/aero' },
  { key: 'aero.wordmark', label: 'AERO — 3D Wordmark Strip', page: '/aero' },
  { key: 'aero.marquee', label: 'AERO — Quick Facts Marquee Strip', page: '/aero' },
  { key: 'aero.detail', label: 'AERO — Detail Close-up Image', page: '/aero' },
  { key: 'aero.blobVideo', label: 'AERO — Bubble Morph Video (.mp4)', page: '/aero', isVideo: true },
  { key: 'aero.logoVideo', label: 'AERO — 3D Spinning Logo Video (.mp4)', page: '/aero', isVideo: true },
  {
    key: 'zestwell.sheet',
    label: 'ZESTWELL — Artwork 3x3 Print Sheet (1744x2336)',
    page: '/zestwell',
    gridWarning: 'Uses fixed 3x3 portrait print crops (1744x2336). Replacement must preserve the 3x3 grid and white gutters.'
  }
];

export const DEFAULT_SITE_CONFIG = {
  brand: DEFAULT_BRAND,
  theme: DEFAULT_THEME,
  ads: DEFAULT_ADS,
  assets: DEFAULT_ASSETS,
  products: DEFAULT_PRODUCTS
};
