import { getAsset, loadSiteConfig } from './siteConfig.js';

const loadedUrls = new Set();
const inFlightUrls = new Map();

export const preloadImage = url => {
  if (!url) return Promise.resolve();
  if (loadedUrls.has(url)) return Promise.resolve();
  if (inFlightUrls.has(url)) return inFlightUrls.get(url);

  const promise = new Promise(resolve => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.decoding = 'async';
    const done = () => {
      loadedUrls.add(url);
      inFlightUrls.delete(url);
      resolve();
    };
    img.onload = () => {
      if (typeof img.decode === 'function') {
        img.decode().then(done, done);
      } else {
        done();
      }
    };
    img.onerror = done;
    img.src = url;
  });

  inFlightUrls.set(url, promise);
  return promise;
};

export const preloadVideoPosterOrMeta = url => {
  if (!url) return Promise.resolve();
  if (loadedUrls.has(url)) return Promise.resolve();
  if (inFlightUrls.has(url)) return inFlightUrls.get(url);

  const promise = new Promise(resolve => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.crossOrigin = 'anonymous';
    const cleanup = () => {
      video.onloadedmetadata = null;
      video.onerror = null;
      video.removeAttribute('src');
      loadedUrls.add(url);
      inFlightUrls.delete(url);
      resolve();
    };
    video.onloadedmetadata = cleanup;
    video.onerror = cleanup;
    setTimeout(cleanup, 1800);
    video.src = url;
  });

  inFlightUrls.set(url, promise);
  return promise;
};

export const getRouteAssets = pathname => {
  const cfg = loadSiteConfig();
  switch (pathname) {
    case '/': {
      const flexFirst = (cfg.assets?.['home.flex'] || []).slice(0, 3).map(item => ({ type: 'image', url: item.src }));
      return [
        { type: 'image', url: getAsset('vestra.base') },
        { type: 'image', url: getAsset('vestra.wear.0') },
        ...flexFirst
      ];
    }
    case '/vestra':
      return [
        { type: 'image', url: getAsset('vestra.base') },
        { type: 'image', url: getAsset('vestra.wear.0') },
        { type: 'image', url: getAsset('vestra.sheet') }
      ];
    case '/hina':
      return [
        { type: 'image', url: getAsset('hina.sprite') },
        { type: 'image', url: getAsset('hina.smockSheet') }
      ];
    case '/aero':
      return [
        { type: 'image', url: getAsset('aero.poster') },
        { type: 'image', url: getAsset('aero.plinth') },
        { type: 'image', url: getAsset('aero.wordmark') }
      ];
    case '/zestwell':
      return [{ type: 'image', url: getAsset('zestwell.sheet') }];
    default:
      return [];
  }
};

export const getRouteLabel = pathname => {
  switch (pathname) {
    case '/':
      return '';
    case '/vestra':
      return 'VESTRA Outerwear';
    case '/hina':
      return 'HINA Little Wardrobe';
    case '/aero':
      return 'KYNE AERO.VISION';
    case '/zestwell':
      return 'Zestwell Gallery';
    case '/admin':
      return 'Admin Control Panel';
    default:
      return '';
  }
};

export const preloadRouteAssets = (pathname, onProgress) => {
  const items = getRouteAssets(pathname);
  const fontsTask = document.fonts && document.fonts.ready ? document.fonts.ready.catch(() => {}) : Promise.resolve();
  const tasks = [
    ...items.map(item => (item.type === 'video' ? preloadVideoPosterOrMeta(item.url) : preloadImage(item.url))),
    fontsTask
  ];

  const total = Math.max(1, tasks.length);
  let completed = 0;

  if (onProgress) onProgress(0, total);

  return Promise.all(
    tasks.map(task =>
      Promise.resolve(task)
        .catch(() => {})
        .finally(() => {
          completed += 1;
          if (onProgress) onProgress(completed, total);
        })
    )
  );
};

export const scheduleIdlePrefetch = currentPath => {
  const routes = ['/vestra', '/hina', '/aero', '/zestwell'].filter(r => r !== currentPath);
  const run = () => {
    routes.forEach((route, idx) => {
      setTimeout(() => {
        const items = getRouteAssets(route);
        if (items[0] && items[0].type === 'image') {
          preloadImage(items[0].url);
        }
      }, idx * 450);
    });
  };

  if (typeof window.requestIdleCallback === 'function') {
    window.requestIdleCallback(run, { timeout: 2500 });
  } else {
    setTimeout(run, 1200);
  }
};
