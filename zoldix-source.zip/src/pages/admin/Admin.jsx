import { useEffect, useState } from 'react';
import {
  importSiteConfigJson,
  loadSiteConfig,
  resetSiteConfig,
  setAdminSessionUnlocked,
  updateSiteConfig,
  verifyAdminPassword
} from '../../config/siteConfig.js';
import BrandTab from './tabs/BrandTab.jsx';
import MediaTab from './tabs/MediaTab.jsx';
import ProductsTab from './tabs/ProductsTab.jsx';
import ThemeTab from './tabs/ThemeTab.jsx';
import AdsTab from './tabs/AdsTab.jsx';
import BackupTab from './tabs/BackupTab.jsx';
import './admin.css';

const TABS = [
  { id: 'brand', label: 'Brand' },
  { id: 'media', label: 'Images & Media' },
  { id: 'products', label: 'Products & Text' },
  { id: 'theme', label: 'Theme' },
  { id: 'ads', label: 'Ads' },
  { id: 'backup', label: 'Backup' }
];

export default function Admin() {
  const [unlocked, setUnlocked] = useState(false);
  const [pwInput, setPwInput] = useState('');
  const [pwError, setPwError] = useState('');
  const [activeTab, setActiveTab] = useState('brand');
  const [config, setConfig] = useState(loadSiteConfig);

  useEffect(() => {
    setAdminSessionUnlocked(false);
    setConfig(loadSiteConfig());
  }, []);

  const handleLogin = async event => {
    event.preventDefault();
    if (!pwInput) {
      setPwError('اطلع يا احمار هذا لزولديكس');
      return;
    }
    const ok = await verifyAdminPassword(pwInput);
    if (ok) {
      setAdminSessionUnlocked(true);
      setUnlocked(true);
      setPwError('');
      setPwInput('');
    } else {
      setAdminSessionUnlocked(false);
      setPwError('اطلع يا احمار هذا لزولديكس');
    }
  };

  const handleUpdate = updater => {
    const next = updateSiteConfig(updater);
    setConfig(next);
  };

  const handleImport = raw => {
    const next = importSiteConfigJson(raw);
    setConfig(next);
  };

  const handleResetAll = () => {
    const fresh = resetSiteConfig();
    setConfig(fresh);
  };

  if (!unlocked) {
    return (
      <main className="admin-page">
        <div className="admin-gate-card">
          <h1 className="admin-title" style={{ fontSize: 24 }}>
            ZOLDIX Admin Panel
          </h1>
          <div className="admin-notice">
            Protected control panel. Password verification is required on every visit.
          </div>

          <form onSubmit={handleLogin}>
            <div className="admin-field">
              <label htmlFor="admin-pw">Enter Admin Password</label>
              <input
                id="admin-pw"
                type="password"
                className="admin-input"
                placeholder="••••••••"
                value={pwInput}
                onChange={e => setPwInput(e.target.value)}
                autoFocus
              />
            </div>
            {pwError && (
              <p className="admin-error" dir="rtl" style={{ fontWeight: 700, fontSize: 14 }}>
                {pwError}
              </p>
            )}
            <button type="submit" className="admin-btn admin-btn-primary" style={{ width: '100%', marginTop: 10 }}>
              Unlock Control Panel
            </button>
          </form>
        </div>
      </main>
    );
  }

  return (
    <main className="admin-page">
      <div className="admin-shell">
        <header className="admin-header">
          <div>
            <h1 className="admin-title">ZOLDIX Control Panel</h1>
            <p className="admin-subtitle">
              Every change saves automatically to <code>localStorage.siteConfig</code> and reflects across all pages.
            </p>
          </div>
          <div className="admin-actions-row">
            <a href="#/" className="admin-btn">
              Live Preview Shop →
            </a>
            <button
              type="button"
              className="admin-btn"
              onClick={() => {
                setAdminSessionUnlocked(false);
                setUnlocked(false);
              }}
            >
              Lock Panel
            </button>
          </div>
        </header>

        <nav className="admin-tabs" role="tablist" aria-label="Admin sections">
          {TABS.map(tab => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={activeTab === tab.id}
              className={`admin-tab ${activeTab === tab.id ? 'is-active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        {activeTab === 'brand' && <BrandTab config={config} onUpdate={handleUpdate} />}
        {activeTab === 'media' && <MediaTab config={config} onUpdate={handleUpdate} />}
        {activeTab === 'products' && <ProductsTab config={config} onUpdate={handleUpdate} />}
        {activeTab === 'theme' && <ThemeTab config={config} onUpdate={handleUpdate} />}
        {activeTab === 'ads' && <AdsTab config={config} onUpdate={handleUpdate} />}
        {activeTab === 'backup' && <BackupTab onImportJson={handleImport} onResetAll={handleResetAll} />}
      </div>
    </main>
  );
}
