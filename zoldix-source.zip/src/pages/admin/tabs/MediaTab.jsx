import { useState } from 'react';
import { ASSET_SLOTS_META, DEFAULT_ASSETS } from '../../../config/defaults.js';
import { isValidMediaUrl } from '../../../config/siteConfig.js';

const resizeImageToDataUrl = (file, maxDim = 2048) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read file.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image file.'));
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        const isPng = file.type === 'image/png';
        resolve(canvas.toDataURL(isPng ? 'image/png' : 'image/webp', 0.88));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });

const CAROUSEL_GROUPS = [
  { key: 'home.carousel', label: 'Home — Circular Showcase' },
  { key: 'home.flex', label: 'Home — Flex Outerwear Strip' },
  { key: 'home.orbit', label: 'Home — Orbit Capsule' }
];

export default function MediaTab({ config, onUpdate }) {
  const [searchTerm, setSearchTerm] = useState('streetwear jacket');
  const [errors, setErrors] = useState({});
  const assets = config.assets || {};

  const setSlotValue = (key, val) => {
    onUpdate(prev => ({
      ...prev,
      assets: {
        ...prev.assets,
        [key]: val
      }
    }));
  };

  const setCarouselItem = (groupKey, idx, field, val) => {
    onUpdate(prev => {
      const list = [...(prev.assets?.[groupKey] || [])];
      list[idx] = { ...list[idx], [field]: val };
      return {
        ...prev,
        assets: {
          ...prev.assets,
          [groupKey]: list
        }
      };
    });
  };

  const addCarouselItem = groupKey => {
    const fallbackImg = DEFAULT_ASSETS[groupKey]?.[0] || {
      src: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=900&q=80&auto=format&fit=max',
      alt: 'Apparel showcase item',
      title: 'New Piece',
      subtitle: 'Drop'
    };
    onUpdate(prev => ({
      ...prev,
      assets: {
        ...prev.assets,
        [groupKey]: [...(prev.assets?.[groupKey] || []), { ...fallbackImg }]
      }
    }));
  };

  const removeCarouselItem = (groupKey, idx) => {
    onUpdate(prev => {
      const list = [...(prev.assets?.[groupKey] || [])];
      if (list.length <= 2) return prev;
      list.splice(idx, 1);
      return {
        ...prev,
        assets: {
          ...prev.assets,
          [groupKey]: list
        }
      };
    });
  };

  const handleUploadSlot = async (key, file, isVideo) => {
    if (!file) return;
    if (isVideo) {
      const objUrl = URL.createObjectURL(file);
      setErrors(e => ({ ...e, [key]: '' }));
      setSlotValue(key, objUrl);
      return;
    }
    try {
      const dataUrl = await resizeImageToDataUrl(file, 2048);
      setErrors(e => ({ ...e, [key]: '' }));
      setSlotValue(key, dataUrl);
    } catch (err) {
      setErrors(e => ({ ...e, [key]: err?.message || 'Upload failed.' }));
    }
  };

  const handleUploadCarousel = async (groupKey, idx, file) => {
    if (!file) return;
    const errKey = `${groupKey}.${idx}`;
    try {
      const dataUrl = await resizeImageToDataUrl(file, 2048);
      setErrors(e => ({ ...e, [errKey]: '' }));
      setCarouselItem(groupKey, idx, 'src', dataUrl);
    } catch (err) {
      setErrors(e => ({ ...e, [errKey]: err?.message || 'Upload failed.' }));
    }
  };

  const q = encodeURIComponent(searchTerm.trim() || 'clothing fashion');

  return (
    <div className="admin-panel">
      {/* Find clothing photos helper */}
      <div className="admin-card">
        <h3>Find Clothing Photos Helper</h3>
        <p className="admin-subtitle" style={{ marginBottom: 12 }}>
          Search curated stock photography by keyword, copy any image URL, and paste it below.
        </p>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
          <input
            className="admin-input"
            style={{ maxWidth: 340 }}
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="e.g. streetwear jacket, kids dress"
          />
          <a
            href={`https://unsplash.com/s/photos/${q}`}
            target="_blank"
            rel="noopener noreferrer"
            className="admin-btn admin-btn-primary"
          >
            Search Unsplash ↗
          </a>
          <a
            href={`https://www.pexels.com/search/${q}/`}
            target="_blank"
            rel="noopener noreferrer"
            className="admin-btn"
          >
            Search Pexels ↗
          </a>
        </div>
      </div>

      {/* Home Carousel Media */}
      {CAROUSEL_GROUPS.map(group => {
        const list = assets[group.key] || [];
        return (
          <div key={group.key} className="admin-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, flexWrap: 'wrap', marginBottom: 14 }}>
              <h3 style={{ margin: 0 }}>{group.label}</h3>
              <div style={{ display: 'flex', gap: 8 }}>
                <button type="button" className="admin-btn" onClick={() => addCarouselItem(group.key)}>
                  + Add Slide
                </button>
                <button
                  type="button"
                  className="admin-btn"
                  onClick={() => setSlotValue(group.key, JSON.parse(JSON.stringify(DEFAULT_ASSETS[group.key])))}
                >
                  Reset Group
                </button>
                <a href="#/" className="admin-btn admin-btn-primary">
                  Preview /
                </a>
              </div>
            </div>

            {list.map((item, idx) => {
              const errKey = `${group.key}.${idx}`;
              return (
                <div key={idx} className="admin-media-row">
                  <img
                    src={item.src || DEFAULT_ASSETS[group.key]?.[0]?.src}
                    alt={item.alt || 'Preview'}
                    className="admin-thumb"
                    onError={e => {
                      const def = DEFAULT_ASSETS[group.key]?.[idx % DEFAULT_ASSETS[group.key].length]?.src;
                      if (def && e.currentTarget.src !== def) e.currentTarget.src = def;
                    }}
                  />
                  <div>
                    <div className="admin-grid-2">
                      <div className="admin-field">
                        <label>Slide {idx + 1} Title</label>
                        <input
                          className="admin-input"
                          value={item.title || ''}
                          onChange={e => setCarouselItem(group.key, idx, 'title', e.target.value)}
                        />
                      </div>
                      <div className="admin-field">
                        <label>Subtitle / Tag</label>
                        <input
                          className="admin-input"
                          value={item.subtitle || ''}
                          onChange={e => setCarouselItem(group.key, idx, 'subtitle', e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="admin-field">
                      <label>Image URL</label>
                      <input
                        className="admin-input"
                        value={item.src || ''}
                        onChange={e => {
                          const val = e.target.value;
                          setCarouselItem(group.key, idx, 'src', val);
                          if (!isValidMediaUrl(val, true)) {
                            setErrors(prev => ({ ...prev, [errKey]: 'Enter a valid http(s) or data URL.' }));
                          } else {
                            setErrors(prev => ({ ...prev, [errKey]: '' }));
                          }
                        }}
                      />
                      {errors[errKey] && <p className="admin-error">{errors[errKey]}</p>}
                    </div>

                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                      <label className="admin-file-label">
                        Upload Image (≤2048px)
                        <input
                          type="file"
                          accept="image/*"
                          onChange={e => {
                            handleUploadCarousel(group.key, idx, e.target.files?.[0]);
                            e.target.value = '';
                          }}
                        />
                      </label>
                      <button
                        type="button"
                        className="admin-btn admin-btn-danger"
                        disabled={list.length <= 2}
                        onClick={() => removeCarouselItem(group.key, idx)}
                      >
                        Remove Slide
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        );
      })}

      {/* All Page Asset Slots */}
      <div className="admin-card">
        <h3>Page & Brief Asset Slots (MONS, VESTRA, HINA, AERO, Zestwell)</h3>
        {ASSET_SLOTS_META.map(slot => {
          const val = assets[slot.key] ?? DEFAULT_ASSETS[slot.key];
          const err = errors[slot.key];
          return (
            <div key={slot.key} className="admin-media-row">
              {slot.isVideo ? (
                <video src={val} className="admin-thumb" muted playsInline preload="metadata" />
              ) : (
                <img
                  src={val}
                  alt={slot.label}
                  className="admin-thumb"
                  onError={e => {
                    const def = DEFAULT_ASSETS[slot.key];
                    if (def && e.currentTarget.src !== def) e.currentTarget.src = def;
                  }}
                />
              )}

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8, marginBottom: 8 }}>
                  <strong style={{ fontSize: 13.5 }}>{slot.label}</strong>
                  <a href={`#${slot.page}`} className="admin-btn" style={{ minHeight: 34, padding: '0 12px', fontSize: 12 }}>
                    Live Preview {slot.page} →
                  </a>
                </div>

                {slot.gridWarning && <div className="admin-warning">{slot.gridWarning}</div>}

                <div className="admin-field" style={{ marginTop: 10 }}>
                  <label htmlFor={`slot-${slot.key}`}>Asset URL ({slot.key})</label>
                  <input
                    id={`slot-${slot.key}`}
                    className="admin-input"
                    value={val || ''}
                    onChange={e => {
                      const next = e.target.value;
                      setSlotValue(slot.key, next);
                      if (!isValidMediaUrl(next, true)) {
                        setErrors(prev => ({ ...prev, [slot.key]: 'Enter a valid http(s) or data URL.' }));
                      } else {
                        setErrors(prev => ({ ...prev, [slot.key]: '' }));
                      }
                    }}
                  />
                  {err && <p className="admin-error">{err}</p>}
                </div>

                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                  <label className="admin-file-label">
                    {slot.isVideo ? 'Upload Video' : 'Upload Image (≤2048px)'}
                    <input
                      type="file"
                      accept={slot.isVideo ? 'video/*' : 'image/*'}
                      onChange={e => {
                        handleUploadSlot(slot.key, e.target.files?.[0], slot.isVideo);
                        e.target.value = '';
                      }}
                    />
                  </label>

                  <button
                    type="button"
                    className="admin-btn"
                    onClick={() => {
                      setErrors(prev => ({ ...prev, [slot.key]: '' }));
                      setSlotValue(slot.key, DEFAULT_ASSETS[slot.key]);
                    }}
                  >
                    Reset Slot
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
