import { useState } from 'react';
import { exportSiteConfigJson } from '../../../config/siteConfig.js';

export default function BackupTab({ onImportJson, onResetAll }) {
  const [pasteJson, setPasteJson] = useState('');
  const [statusMsg, setStatusMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleDownload = () => {
    const json = exportSiteConfigJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'zoldix-site-config.json';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setStatusMsg('Exported configuration JSON.');
    setErrorMsg('');
  };

  const handleImportText = raw => {
    try {
      onImportJson(raw);
      setStatusMsg('Imported configuration successfully.');
      setErrorMsg('');
      setPasteJson('');
    } catch (err) {
      setErrorMsg(err?.message || 'Invalid JSON configuration.');
      setStatusMsg('');
    }
  };

  const handleFileUpload = event => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => handleImportText(String(reader.result || ''));
    reader.readAsText(file);
    event.target.value = '';
  };

  return (
    <div className="admin-panel">
      <div className="admin-card">
        <h3>Download Full Website Source (.zip)</h3>
        <p className="admin-subtitle" style={{ marginBottom: 14 }}>
          Download all website files (<code>index.html</code>, <code>package.json</code>, <code>vite.config.ts</code>, and <code>src/</code>) as a ready-to-run ZIP archive. Unzip, then run <code>npm install &amp;&amp; npm run dev</code>.
        </p>
        <a
          href="zoldix-source.zip"
          download="zoldix-website.zip"
          className="admin-btn admin-btn-primary"
          data-no-ad="true"
        >
          Download Full Website (.zip)
        </a>
      </div>

      <div className="admin-card">
        <h3>Export Configuration</h3>
        <p className="admin-subtitle" style={{ marginBottom: 14 }}>
          Download a complete JSON backup of brand settings, images, videos, products, theme, and ads.
        </p>
        <button type="button" className="admin-btn" onClick={handleDownload}>
          Download siteConfig.json
        </button>
      </div>

      <div className="admin-card">
        <h3>Import JSON Backup</h3>
        <div style={{ marginBottom: 14 }}>
          <label className="admin-file-label">
            Upload .json File
            <input type="file" accept=".json,application/json" onChange={handleFileUpload} />
          </label>
        </div>

        <div className="admin-field">
          <label htmlFor="backup-paste">Or paste JSON directly</label>
          <textarea
            id="backup-paste"
            className="admin-textarea"
            placeholder='{"brand": ...}'
            value={pasteJson}
            onChange={e => setPasteJson(e.target.value)}
          />
        </div>

        <button
          type="button"
          className="admin-btn"
          onClick={() => handleImportText(pasteJson)}
        >
          Apply Pasted JSON
        </button>

        {errorMsg && <p className="admin-error">{errorMsg}</p>}
        {statusMsg && <p className="admin-success">{statusMsg}</p>}
      </div>

      <div className="admin-card">
        <h3>Factory Reset</h3>
        <p className="admin-subtitle" style={{ marginBottom: 14 }}>
          Restore all URLs, titles, products, ads, and wrapper colors to their original source values.
        </p>
        <button
          type="button"
          className="admin-btn admin-btn-danger"
          onClick={() => {
            onResetAll();
            setStatusMsg('All settings restored to factory defaults.');
            setErrorMsg('');
          }}
        >
          Reset Everything to Defaults
        </button>
      </div>
    </div>
  );
}
