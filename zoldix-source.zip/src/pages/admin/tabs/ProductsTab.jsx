import { DEFAULT_PRODUCTS } from '../../../config/defaults.js';

export default function ProductsTab({ config, onUpdate }) {
  const products = config.products || DEFAULT_PRODUCTS;

  const setItemField = (collectionKey, idx, field, value) => {
    onUpdate(prev => {
      const nextList = [...(prev.products?.[collectionKey] || DEFAULT_PRODUCTS[collectionKey])];
      nextList[idx] = { ...nextList[idx], [field]: value };
      return {
        ...prev,
        products: {
          ...prev.products,
          [collectionKey]: nextList
        }
      };
    });
  };

  return (
    <div className="admin-panel">
      {/* VESTRA (4) */}
      <div className="admin-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, flexWrap: 'wrap', marginBottom: 14 }}>
          <h3 style={{ margin: 0 }}>VESTRA Outerwear (4 Products)</h3>
          <a href="#/vestra" className="admin-btn admin-btn-primary">
            Preview /vestra →
          </a>
        </div>

        {(products.vestra || []).map((item, idx) => (
          <div key={idx} className="admin-card" style={{ background: 'rgba(0,0,0,0.22)' }}>
            <strong style={{ display: 'block', marginBottom: 10, fontSize: 13 }}>VESTRA #{idx + 1}</strong>
            <div className="admin-grid-2">
              <div className="admin-field">
                <label>Hero Title</label>
                <input
                  className="admin-input"
                  value={item.title || ''}
                  onChange={e => setItemField('vestra', idx, 'title', e.target.value)}
                />
              </div>
              <div className="admin-field">
                <label>Price String</label>
                <input
                  className="admin-input"
                  value={item.price || ''}
                  onChange={e => setItemField('vestra', idx, 'price', e.target.value)}
                />
              </div>
              <div className="admin-field">
                <label>Cart Pill Name</label>
                <input
                  className="admin-input"
                  value={item.pillName || ''}
                  onChange={e => setItemField('vestra', idx, 'pillName', e.target.value)}
                />
              </div>
              <div className="admin-field">
                <label>Colour / Sub Label</label>
                <input
                  className="admin-input"
                  value={item.subLabel || ''}
                  onChange={e => setItemField('vestra', idx, 'subLabel', e.target.value)}
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* HINA (12) */}
      <div className="admin-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, flexWrap: 'wrap', marginBottom: 14 }}>
          <h3 style={{ margin: 0 }}>HINA Little Wardrobe (12 Pieces)</h3>
          <a href="#/hina" className="admin-btn admin-btn-primary">
            Preview /hina →
          </a>
        </div>

        {(products.hina || []).map((item, idx) => (
          <div key={idx} className="admin-card" style={{ background: 'rgba(0,0,0,0.22)' }}>
            <strong style={{ display: 'block', marginBottom: 10, fontSize: 13 }}>HINA Piece #{idx + 1}</strong>
            <div className="admin-grid-2">
              <div className="admin-field">
                <label>Title Line 1</label>
                <input
                  className="admin-input"
                  value={item.title1 || ''}
                  onChange={e => setItemField('hina', idx, 'title1', e.target.value)}
                />
              </div>
              <div className="admin-field">
                <label>Title Line 2</label>
                <input
                  className="admin-input"
                  value={item.title2 || ''}
                  onChange={e => setItemField('hina', idx, 'title2', e.target.value)}
                />
              </div>
              <div className="admin-field">
                <label>Description Line 1</label>
                <input
                  className="admin-input"
                  value={item.desc1 || ''}
                  onChange={e => setItemField('hina', idx, 'desc1', e.target.value)}
                />
              </div>
              <div className="admin-field">
                <label>Description Line 2</label>
                <input
                  className="admin-input"
                  value={item.desc2 || ''}
                  onChange={e => setItemField('hina', idx, 'desc2', e.target.value)}
                />
              </div>
              <div className="admin-field">
                <label>Material</label>
                <input
                  className="admin-input"
                  value={item.material || ''}
                  onChange={e => setItemField('hina', idx, 'material', e.target.value)}
                />
              </div>
              <div className="admin-field">
                <label>Colour</label>
                <input
                  className="admin-input"
                  value={item.colour || ''}
                  onChange={e => setItemField('hina', idx, 'colour', e.target.value)}
                />
              </div>
              <div className="admin-field">
                <label>Sizes</label>
                <input
                  className="admin-input"
                  value={item.size || ''}
                  onChange={e => setItemField('hina', idx, 'size', e.target.value)}
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ZESTWELL (9) */}
      <div className="admin-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, flexWrap: 'wrap', marginBottom: 14 }}>
          <h3 style={{ margin: 0 }}>Zestwell Prints (9 Editions)</h3>
          <a href="#/zestwell" className="admin-btn admin-btn-primary">
            Preview /zestwell →
          </a>
        </div>

        {(products.zestwell || []).map((item, idx) => (
          <div key={idx} className="admin-card" style={{ background: 'rgba(0,0,0,0.22)' }}>
            <strong style={{ display: 'block', marginBottom: 10, fontSize: 13 }}>Print #{idx + 1}</strong>
            <div className="admin-grid-2">
              <div className="admin-field">
                <label>Print Title</label>
                <input
                  className="admin-input"
                  value={item.title || ''}
                  onChange={e => setItemField('zestwell', idx, 'title', e.target.value)}
                />
              </div>
              <div className="admin-field">
                <label>Artist</label>
                <input
                  className="admin-input"
                  value={item.artist || ''}
                  onChange={e => setItemField('zestwell', idx, 'artist', e.target.value)}
                />
              </div>
              <div className="admin-field">
                <label>Year</label>
                <input
                  className="admin-input"
                  value={item.year || ''}
                  onChange={e => setItemField('zestwell', idx, 'year', e.target.value)}
                />
              </div>
              <div className="admin-field">
                <label>Price (USD number)</label>
                <input
                  type="number"
                  min="1"
                  className="admin-input"
                  value={item.price ?? 60}
                  onChange={e => setItemField('zestwell', idx, 'price', Math.max(1, Number(e.target.value) || 60))}
                />
              </div>
            </div>
            <div className="admin-field">
              <label>Description Opening</label>
              <input
                className="admin-input"
                value={item.descriptionStart || ''}
                onChange={e => setItemField('zestwell', idx, 'descriptionStart', e.target.value)}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
