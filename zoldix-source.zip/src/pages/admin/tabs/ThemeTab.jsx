import { DEFAULT_THEME } from '../../../config/defaults.js';

export default function ThemeTab({ config, onUpdate }) {
  const theme = config.theme || DEFAULT_THEME;

  const setColor = (key, value) => {
    onUpdate(prev => ({
      ...prev,
      theme: {
        ...prev.theme,
        [key]: value
      }
    }));
  };

  return (
    <div className="admin-panel">
      <div className="admin-card">
        <h3>Wrapper Theme (Home, Admin & Loader)</h3>
        <p className="admin-subtitle" style={{ marginBottom: 18 }}>
          Controls the wrapper colours for <code>/</code>, <code>/admin</code>, and the ZOLDIX loading screen. Individual showcase briefs preserve their own studio palettes.
        </p>

        <div className="admin-grid-2">
          <div className="admin-field">
            <label htmlFor="t-accent">Accent Colour</label>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <input
                id="t-accent"
                type="color"
                value={theme.accentColor || '#ff5a1f'}
                onChange={e => setColor('accentColor', e.target.value)}
                style={{ width: 52, height: 42, border: 0, background: 'none', cursor: 'pointer' }}
              />
              <input
                className="admin-input"
                value={theme.accentColor || ''}
                onChange={e => setColor('accentColor', e.target.value)}
              />
            </div>
          </div>

          <div className="admin-field">
            <label htmlFor="t-bg">Background Colour</label>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <input
                id="t-bg"
                type="color"
                value={theme.bgColor || '#0d0d10'}
                onChange={e => setColor('bgColor', e.target.value)}
                style={{ width: 52, height: 42, border: 0, background: 'none', cursor: 'pointer' }}
              />
              <input
                className="admin-input"
                value={theme.bgColor || ''}
                onChange={e => setColor('bgColor', e.target.value)}
              />
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 12, marginTop: 12, flexWrap: 'wrap' }}>
          <button
            type="button"
            className="admin-btn"
            onClick={() =>
              onUpdate(prev => ({
                ...prev,
                theme: { ...DEFAULT_THEME }
              }))
            }
          >
            Reset Theme to Defaults
          </button>
          <a href="#/" className="admin-btn admin-btn-primary">
            Live Preview Home →
          </a>
        </div>
      </div>
    </div>
  );
}
