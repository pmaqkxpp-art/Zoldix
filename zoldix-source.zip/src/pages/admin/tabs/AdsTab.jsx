import { useState } from 'react';
import { DEFAULT_ADS } from '../../../config/defaults.js';
import { isValidHttpUrl } from '../../../config/siteConfig.js';

export default function AdsTab({ config, onUpdate }) {
  const ads = config.ads || DEFAULT_ADS;
  const [urlInput, setUrlInput] = useState(ads.url || '');
  const [urlError, setUrlError] = useState('');

  const updateAds = patch => {
    onUpdate(prev => ({
      ...prev,
      ads: {
        ...prev.ads,
        ...patch
      }
    }));
  };

  return (
    <div className="admin-panel">
      <div className="admin-card">
        <h3>Smart Ad Module Configuration</h3>
        <div className="admin-warning">
          Setting very aggressive triggers (such as interval <strong>1</strong> and cooldown <strong>0</strong> seconds) can annoy visitors and cause ad networks to suspend publisher accounts.
        </div>

        <div className="admin-switch-row" style={{ marginTop: 18, marginBottom: 16 }}>
          <label htmlFor="ads-enabled" style={{ fontSize: 14, fontWeight: 600 }}>
            Enable Ads Integration
          </label>
          <input
            id="ads-enabled"
            type="checkbox"
            checked={ads.enabled !== false}
            onChange={e => updateAds({ enabled: e.target.checked })}
            style={{ width: 22, height: 22 }}
          />
        </div>

        <div className="admin-field">
          <label htmlFor="ads-url">Destination Ad URL</label>
          <input
            id="ads-url"
            className="admin-input"
            value={urlInput}
            onChange={e => {
              const val = e.target.value;
              setUrlInput(val);
              if (!isValidHttpUrl(val)) {
                setUrlError('Invalid URL: must begin with http:// or https://');
              } else {
                setUrlError('');
                updateAds({ url: val.trim() });
              }
            }}
          />
          {urlError && <p className="admin-error">{urlError}</p>}
        </div>

        <div className="admin-grid-2">
          <div className="admin-field">
            <label htmlFor="ads-interval">Trigger Every N Clicks</label>
            <input
              id="ads-interval"
              type="number"
              min="1"
              max="50"
              className="admin-input"
              value={ads.clickInterval ?? 3}
              onChange={e => updateAds({ clickInterval: Math.max(1, Number(e.target.value) || 1) })}
            />
          </div>

          <div className="admin-field">
            <label htmlFor="ads-cooldown">Cooldown Between Popups (Seconds)</label>
            <input
              id="ads-cooldown"
              type="number"
              min="0"
              max="3600"
              className="admin-input"
              value={ads.cooldownSeconds ?? 60}
              onChange={e => updateAds({ cooldownSeconds: Math.max(0, Number(e.target.value) || 0) })}
            />
          </div>
        </div>

        <div className="admin-field">
          <label htmlFor="ads-exclude">Excluded Routes (comma-separated)</label>
          <input
            id="ads-exclude"
            className="admin-input"
            value={(ads.excludeRoutes || ['/admin']).join(', ')}
            onChange={e => {
              const list = e.target.value
                .split(',')
                .map(s => s.trim())
                .filter(Boolean);
              updateAds({ excludeRoutes: list.length ? list : ['/admin'] });
            }}
          />
        </div>

        <button
          type="button"
          className="admin-btn"
          onClick={() => {
            setUrlInput(DEFAULT_ADS.url);
            setUrlError('');
            updateAds({ ...DEFAULT_ADS });
          }}
        >
          Reset Ad Settings to Defaults
        </button>
      </div>
    </div>
  );
}
