import { useState } from 'react';
import { isValidMediaUrl, updateAdminPassword } from '../../../config/siteConfig.js';

export default function BrandTab({ config, onUpdate }) {
  const brand = config.brand || {};
  const [favErr, setFavErr] = useState('');
  const [igErr, setIgErr] = useState('');
  const [newPass, setNewPass] = useState('');
  const [passMsg, setPassMsg] = useState('');

  const setBrandField = (key, value) => {
    onUpdate(prev => ({
      ...prev,
      brand: {
        ...prev.brand,
        [key]: value
      }
    }));
  };

  const handlePasswordChange = async event => {
    event.preventDefault();
    if (newPass.trim().length < 4) {
      setPassMsg('Password must be at least 4 characters.');
      return;
    }
    await updateAdminPassword(newPass.trim());
    setNewPass('');
    setPassMsg('Admin password updated (SHA-256 hashed in browser storage).');
  };

  return (
    <div className="admin-panel">
      <div className="admin-grid-2">
        <div className="admin-card">
          <h3>Site Identity & Metadata</h3>
          <div className="admin-field">
            <label htmlFor="b-site-name">Site Name</label>
            <input
              id="b-site-name"
              className="admin-input"
              value={brand.siteName || ''}
              onChange={e => setBrandField('siteName', e.target.value)}
            />
          </div>

          <div className="admin-field">
            <label htmlFor="b-logo-text">TopBar Logo Text</label>
            <input
              id="b-logo-text"
              className="admin-input"
              value={brand.logoText || ''}
              onChange={e => setBrandField('logoText', e.target.value)}
            />
          </div>

          <div className="admin-field">
            <label htmlFor="b-page-title">Browser Page Title</label>
            <input
              id="b-page-title"
              className="admin-input"
              value={brand.pageTitle || ''}
              onChange={e => setBrandField('pageTitle', e.target.value)}
            />
          </div>

          <div className="admin-field">
            <label htmlFor="b-tagline">Tagline</label>
            <input
              id="b-tagline"
              className="admin-input"
              value={brand.tagline || ''}
              onChange={e => setBrandField('tagline', e.target.value)}
            />
          </div>

          <div className="admin-field">
            <label htmlFor="b-favicon">Favicon URL (http/https/data URL)</label>
            <input
              id="b-favicon"
              className="admin-input"
              value={brand.faviconUrl || ''}
              onChange={e => {
                const val = e.target.value;
                if (!val.trim() || !isValidMediaUrl(val, true)) {
                  setFavErr('Please enter a valid http(s) or data URL.');
                } else {
                  setFavErr('');
                  setBrandField('faviconUrl', val);
                }
              }}
            />
            {favErr && <p className="admin-error">{favErr}</p>}
          </div>
        </div>

        <div className="admin-card">
          <h3>Home Copy, Preloader & Instagram</h3>
          <div className="admin-field">
            <label htmlFor="b-headline">Home Headline</label>
            <input
              id="b-headline"
              className="admin-input"
              value={brand.homeHeadline || ''}
              onChange={e => setBrandField('homeHeadline', e.target.value)}
            />
          </div>

          <div className="admin-field">
            <label htmlFor="b-subtitle">Home Subtitle</label>
            <input
              id="b-subtitle"
              className="admin-input"
              value={brand.homeSubtitle || ''}
              onChange={e => setBrandField('homeSubtitle', e.target.value)}
            />
          </div>

          <div className="admin-switch-row" style={{ marginBottom: 14 }}>
            <label htmlFor="b-loader-on" style={{ fontSize: 13, fontWeight: 600 }}>
              Enable ZOLDIX Entry Preloader
            </label>
            <input
              id="b-loader-on"
              type="checkbox"
              checked={brand.loaderEnabled !== false}
              onChange={e => setBrandField('loaderEnabled', e.target.checked)}
              style={{ width: 22, height: 22 }}
            />
          </div>

          <div className="admin-field">
            <label htmlFor="b-loader-title">Loader Display Title</label>
            <input
              id="b-loader-title"
              className="admin-input"
              value={brand.loaderTitle || ''}
              onChange={e => setBrandField('loaderTitle', e.target.value)}
            />
          </div>

          <div className="admin-field">
            <label htmlFor="b-loader-welcome">Loader Greeting Line</label>
            <input
              id="b-loader-welcome"
              className="admin-input"
              value={brand.loaderWelcome || ''}
              onChange={e => setBrandField('loaderWelcome', e.target.value)}
            />
          </div>

          <div className="admin-field">
            <label htmlFor="b-ig-label">Footer Instagram Label</label>
            <input
              id="b-ig-label"
              className="admin-input"
              value={brand.instagramLabel || ''}
              onChange={e => setBrandField('instagramLabel', e.target.value)}
            />
          </div>

          <div className="admin-field">
            <label htmlFor="b-ig-url">Footer Instagram URL</label>
            <input
              id="b-ig-url"
              className="admin-input"
              value={brand.instagramUrl || ''}
              onChange={e => {
                const val = e.target.value;
                if (!/^https?:\/\//i.test(val.trim())) {
                  setIgErr('URL must start with http:// or https://');
                } else {
                  setIgErr('');
                  setBrandField('instagramUrl', val.trim());
                }
              }}
            />
            {igErr && <p className="admin-error">{igErr}</p>}
          </div>
        </div>
      </div>

      <div className="admin-card">
        <h3>Change Admin Access Password</h3>
        <form onSubmit={handlePasswordChange} style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
          <input
            type="password"
            className="admin-input"
            style={{ maxWidth: 320 }}
            placeholder="New password (min 4 chars)"
            value={newPass}
            onChange={e => setNewPass(e.target.value)}
          />
          <button type="submit" className="admin-btn admin-btn-primary">
            Update Password
          </button>
        </form>
        {passMsg && <p className="admin-success">{passMsg}</p>}
      </div>
    </div>
  );
}
