import { getAsset, getDefaultAsset, loadSiteConfig } from '../../config/siteConfig.js';

export const HINA_SPRITE_NATIVE_W = 3312;
export const HINA_SPRITE_NATIVE_H = 2480;
export const HINA_SMOCK_NATIVE_W = 2048;
export const HINA_SMOCK_NATIVE_H = 2048;

export const HINA_SPRITES = [
  { x: 120, y: 54, w: 560, h: 742, hookX: 404 },
  { x: 982, y: 56, w: 508, h: 708, hookX: 1244 },
  { x: 1792, y: 62, w: 558, h: 588, hookX: 2067 },
  { x: 2638, y: 54, w: 514, h: 726, hookX: 2893 },
  { x: 110, y: 865, w: 596, h: 652, hookX: 406 },
  { x: 938, y: 869, w: 610, h: 650, hookX: 1234 },
  { x: 1844, y: 855, w: 456, h: 718, hookX: 2067 },
  { x: 2614, y: 861, w: 570, h: 630, hookX: 2895 },
  { x: 112, y: 1661, w: 592, h: 712, hookX: 407 },
  { x: 996, y: 1661, w: 492, h: 716, hookX: 1237 },
  { x: 1832, y: 1663, w: 478, h: 714, hookX: 2067 },
  { x: 2682, y: 1673, w: 434, h: 630, hookX: 2894 }
];

export const FABRIC_COLS = [
  [0, 805],
  [836, 1638],
  [1668, 2476],
  [2506, 3311]
];

export const FABRIC_ROWS = [
  [0, 803],
  [834, 1633],
  [1664, 2479]
];

export const DETAIL_COLS = [
  [0, 811],
  [842, 1640],
  [1671, 2470],
  [2501, 3311]
];

export const DETAIL_ROWS = [
  [0, 804],
  [835, 1635],
  [1668, 2479]
];

export const SMOCK_CELLS = {
  back: { x: 0, y: 0, w: 1007, h: 1007 },
  detail: { x: 1041, y: 0, w: 1007, h: 1007 },
  fabric: { x: 0, y: 1041, w: 1007, h: 1007 }
};

export const RAIL_SLOTS_X = [352, 440, 505, 565, 620, 670, 716, 758, 796, 831, 863, 893];

export const SCALE_LUT = [
  [352, 0.94],
  [435, 0.905],
  [545, 0.83],
  [670, 0.70],
  [778, 0.57],
  [878, 0.445],
  [958, 0.33],
  [1045, 0.19]
];

export const HINA_TABS = [
  { id: 0, key: '01 / ON HANGER', name: 'ON HANGER', caption: 'Hung on a little wooden hanger.' },
  { id: 1, key: '02 / FABRIC', name: 'FABRIC', caption: 'Soft to the touch, washed for comfort.' },
  { id: 2, key: '03 / DETAIL', name: 'DETAIL', caption: 'Small touches, sewn to last.' }
];

export const railY = x => 5 + 0.641 * (x - 330);

export const getHinaAssets = () => ({
  sprite: getAsset('hina.sprite') || getDefaultAsset('hina.sprite'),
  smockSheet: getAsset('hina.smockSheet') || getDefaultAsset('hina.smockSheet'),
  fabricSheet: getAsset('hina.fabricSheet') || getDefaultAsset('hina.fabricSheet'),
  detailSheet: getAsset('hina.detailSheet') || getDefaultAsset('hina.detailSheet')
});

export const getHinaProducts = () => {
  const cfg = loadSiteConfig();
  return cfg.products?.hina || [];
};

export const pad2 = n => String(n).padStart(2, '0');
