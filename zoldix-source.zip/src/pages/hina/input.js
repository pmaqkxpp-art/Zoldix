import { computePiecePlacement } from './rail.js';

export const hitTestHinaStage = (frameX, frameY, cur, total = 12) => {
  const frontSlot = computePiecePlacement({ index: cur, slot: 0, isDetail: false }).span;
  if (
    frameX >= frontSlot.left + 30 &&
    frameX <= frontSlot.right - 20 &&
    frameY >= frontSlot.top + 60 &&
    frameY <= frontSlot.bottom
  ) {
    return { type: 'front', slot: 0, index: cur };
  }

  for (let slot = 1; slot < total; slot += 1) {
    const idx = (cur + slot) % total;
    const span = computePiecePlacement({ index: idx, slot, isDetail: false }).span;
    if (frameX <= span.right - 6) {
      if (
        frameY >= span.top + 40 &&
        frameY <= span.bottom - 10 &&
        frameX >= frontSlot.right - 20
      ) {
        return { type: 'rail', slot, index: idx };
      }
      return { type: 'none', slot: -1, index: -1 };
    }
  }

  return { type: 'none', slot: -1, index: -1 };
};

export const attachHinaInput = ({
  stageEl,
  getFrameMetrics,
  getState,
  onStep,
  onHoverSlot,
  onClickFront,
  onClickRailSlot,
  onCloseDetail
}) => {
  let wheelAcc = 0;
  let lastStepAt = 0;
  let touchStartX = 0;
  let touchStartY = 0;
  let touchMoved = false;
  let lastTouchEndAt = 0;

  const canHover = typeof window !== 'undefined' && window.matchMedia?.('(hover: hover)').matches;

  const toFrame = (clientX, clientY) => {
    const { left, top, scale } = getFrameMetrics();
    return [(clientX - left) / scale, (clientY - top) / scale];
  };

  const throttledStep = dir => {
    const now = performance.now();
    if (now - lastStepAt < 95) return;
    lastStepAt = now;
    onStep(dir);
  };

  const onWheel = event => {
    const { isPhone } = getState();
    if (isPhone) return;
    event.preventDefault();
    wheelAcc += event.deltaY + event.deltaX;
    if (Math.abs(wheelAcc) >= 40) {
      const dir = wheelAcc > 0 ? 1 : -1;
      wheelAcc = 0;
      throttledStep(dir);
    }
  };

  const onKeyDown = event => {
    if (event.target.closest('input, textarea, select')) return;
    if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
      event.preventDefault();
      throttledStep(1);
    } else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
      event.preventDefault();
      throttledStep(-1);
    } else if (event.key === 'Escape') {
      if (getState().detailOpen) {
        event.preventDefault();
        onCloseDetail();
      }
    }
  };

  const onMouseMove = event => {
    if (!canHover) return;
    const { detailOpen, cur } = getState();
    if (detailOpen) {
      onHoverSlot(-1, false);
      return;
    }
    const [fx, fy] = toFrame(event.clientX, event.clientY);
    const hit = hitTestHinaStage(fx, fy, cur);
    if (hit.type === 'front') {
      onHoverSlot(-1, true);
    } else if (hit.type === 'rail') {
      onHoverSlot(hit.slot, true);
    } else {
      onHoverSlot(-1, false);
    }
  };

  const onMouseLeave = () => {
    onHoverSlot(-1, false);
  };

  const onClick = event => {
    if (performance.now() - lastTouchEndAt < 400) return;
    if (event.target.closest('button, a, .hina-panel')) return;
    const [fx, fy] = toFrame(event.clientX, event.clientY);
    const { detailOpen, cur } = getState();
    const hit = hitTestHinaStage(fx, fy, cur);
    if (hit.type === 'front') {
      onClickFront();
    } else if (hit.type === 'rail' && !detailOpen) {
      onClickRailSlot(hit.slot);
    }
  };

  const onTouchStart = event => {
    if (!event.touches || event.touches.length === 0) return;
    touchStartX = event.touches[0].clientX;
    touchStartY = event.touches[0].clientY;
    touchMoved = false;
  };

  const onTouchMove = event => {
    if (!event.touches || event.touches.length === 0) return;
    const dx = event.touches[0].clientX - touchStartX;
    const dy = event.touches[0].clientY - touchStartY;
    if (Math.hypot(dx, dy) > 10) touchMoved = true;
  };

  const onTouchEnd = event => {
    lastTouchEndAt = performance.now();
    const t = event.changedTouches?.[0];
    if (!t) return;
    const dx = t.clientX - touchStartX;
    const dy = t.clientY - touchStartY;

    if (Math.abs(dx) > 36 && Math.abs(dx) > Math.abs(dy)) {
      throttledStep(dx < 0 ? 1 : -1);
      return;
    }

    if (!touchMoved && !event.target.closest('button, a, .hina-panel')) {
      const [fx, fy] = toFrame(t.clientX, t.clientY);
      const { detailOpen, cur } = getState();
      const hit = hitTestHinaStage(fx, fy, cur);
      if (hit.type === 'front') {
        onClickFront();
      } else if (hit.type === 'rail' && !detailOpen) {
        onClickRailSlot(hit.slot);
      }
    }
  };

  stageEl.addEventListener('wheel', onWheel, { passive: false });
  stageEl.addEventListener('mousemove', onMouseMove);
  stageEl.addEventListener('mouseleave', onMouseLeave);
  stageEl.addEventListener('click', onClick);
  stageEl.addEventListener('touchstart', onTouchStart, { passive: true });
  stageEl.addEventListener('touchmove', onTouchMove, { passive: true });
  stageEl.addEventListener('touchend', onTouchEnd, { passive: true });
  window.addEventListener('keydown', onKeyDown);

  return () => {
    stageEl.removeEventListener('wheel', onWheel);
    stageEl.removeEventListener('mousemove', onMouseMove);
    stageEl.removeEventListener('mouseleave', onMouseLeave);
    stageEl.removeEventListener('click', onClick);
    stageEl.removeEventListener('touchstart', onTouchStart);
    stageEl.removeEventListener('touchmove', onTouchMove);
    stageEl.removeEventListener('touchend', onTouchEnd);
    window.removeEventListener('keydown', onKeyDown);
  };
};
