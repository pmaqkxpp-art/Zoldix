import { HINA_SPRITES, RAIL_SLOTS_X, SCALE_LUT, railY } from './data.js';

export const slotToHookX = slot => {
  if (slot < 0) {
    return 352 + slot * 120;
  }
  const maxIdx = RAIL_SLOTS_X.length - 1;
  if (slot >= maxIdx) {
    return RAIL_SLOTS_X[maxIdx] + (slot - maxIdx) * 28;
  }
  const lo = Math.floor(slot);
  const hi = Math.ceil(slot);
  if (lo === hi) return RAIL_SLOTS_X[lo];
  const t = slot - lo;
  return RAIL_SLOTS_X[lo] + (RAIL_SLOTS_X[hi] - RAIL_SLOTS_X[lo]) * t;
};

export const behindScaleForX = x => {
  if (x <= SCALE_LUT[0][0]) return SCALE_LUT[0][1];
  const last = SCALE_LUT[SCALE_LUT.length - 1];
  if (x >= last[0]) return last[1];
  for (let i = 0; i < SCALE_LUT.length - 1; i += 1) {
    const [x0, s0] = SCALE_LUT[i];
    const [x1, s1] = SCALE_LUT[i + 1];
    if (x >= x0 && x <= x1) {
      const t = (x - x0) / (x1 - x0);
      return s0 + (s1 - s0) * t;
    }
  }
  return last[1];
};

export const computePiecePlacement = ({
  index,
  slot,
  isDetail,
  hoveredSlot = -1,
  overrideSlot = null,
  overrideZ = null
}) => {
  const sprite = HINA_SPRITES[index];
  const effSlot = overrideSlot !== null ? overrideSlot : slot;
  const hookLocalX = sprite.hookX - sprite.x;

  let X = slotToHookX(effSlot);
  let S = effSlot <= 0.001 && effSlot >= -0.001 ? 0.93 : behindScaleForX(X);

  let dx = 0;
  let dy = 0;
  let rot = 0;
  let opacity = 1;
  let filter = 'none';
  let zIndex = overrideZ !== null ? overrideZ : Math.round(100 - effSlot);

  if (overrideSlot !== null && overrideSlot < 0) {
    // Exiting / entering off top-left of rail
    opacity = 0;
  } else if (isDetail && effSlot > 0) {
    X = 352 + (X - 352) * 0.36;
    S = behindScaleForX(X);
    opacity = 0.62;
    filter = 'blur(7px) saturate(0.55) brightness(1.04)';
  } else if (!isDetail && hoveredSlot > 0) {
    if (effSlot === hoveredSlot) {
      dx = 38 * S;
      dy = 6;
      rot = -6;
      S *= 1.035;
    } else if (effSlot > hoveredSlot) {
      dx = 18 * S;
    }
  }

  const tx = X - hookLocalX + dx;
  const ty = railY(X) - 9 * S + dy;

  return {
    transform: `translate(${tx.toFixed(2)}px, ${ty.toFixed(2)}px) rotate(${rot}deg) scale(${S.toFixed(4)})`,
    opacity,
    filter,
    zIndex,
    span: {
      left: X - hookLocalX * S,
      right: X + (sprite.x + sprite.w - sprite.hookX) * S,
      top: railY(X) - 9 * S,
      bottom: railY(X) - 9 * S + sprite.h * S
    }
  };
};

export const getFloorShadowTop = frontIndex => {
  const sprite = HINA_SPRITES[frontIndex] || HINA_SPRITES[0];
  return railY(352) + sprite.h * 0.93 - 26;
};

export const getRailPolygonPoints = () => {
  const x0 = 250;
  const x1 = 1062;
  const y0 = railY(x0);
  const y1 = railY(x1);
  return `${x0},${(y0 - 9).toFixed(1)} ${x1},${(y1 - 2.6).toFixed(1)} 1065,${(y1 + 2.8).toFixed(1)} ${x0},${(y0 + 9).toFixed(1)}`;
};
