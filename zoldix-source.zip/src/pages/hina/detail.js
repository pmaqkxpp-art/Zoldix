import {
  DETAIL_COLS,
  DETAIL_ROWS,
  FABRIC_COLS,
  FABRIC_ROWS,
  HINA_SMOCK_NATIVE_H,
  HINA_SMOCK_NATIVE_W,
  HINA_SPRITES,
  HINA_SPRITE_NATIVE_H,
  HINA_SPRITE_NATIVE_W,
  SMOCK_CELLS
} from './data.js';

export const computeDetailLayerStyle = ({ pieceIndex, tabIndex, boxW, boxH, assets }) => {
  const safeW = Math.max(120, boxW || 270);
  const safeH = Math.max(150, boxH || 470);

  if (pieceIndex === 0) {
    if (tabIndex === 0) {
      // Piece 1, ON HANGER: back view cell fitted to box width, centred vertically
      const cell = SMOCK_CELLS.back;
      const s = safeW / 990;
      const layerH = cell.h * s;
      const top = (safeH - layerH) / 2;
      return {
        width: `${safeW.toFixed(2)}px`,
        height: `${layerH.toFixed(2)}px`,
        left: '0px',
        top: `${top.toFixed(2)}px`,
        backgroundImage: `url("${assets.smockSheet}")`,
        backgroundRepeat: 'no-repeat',
        backgroundSize: `${(HINA_SMOCK_NATIVE_W * s).toFixed(2)}px ${(HINA_SMOCK_NATIVE_H * s).toFixed(2)}px`,
        backgroundPosition: `${(-cell.x * s).toFixed(2)}px ${(-cell.y * s).toFixed(2)}px`
      };
    }

    // Piece 1, FABRIC (tab 1) or DETAIL (tab 2): cover box starting 6px inside cell
    const cell = tabIndex === 1 ? SMOCK_CELLS.fabric : SMOCK_CELLS.detail;
    const inset = 6;
    const innerSize = 995;
    const s = Math.max(safeW, safeH) / innerSize;
    const drawSize = innerSize * s;
    const offsetX = (safeW - drawSize) / 2;
    const offsetY = (safeH - drawSize) / 2;

    return {
      width: `${safeW.toFixed(2)}px`,
      height: `${safeH.toFixed(2)}px`,
      left: '0px',
      top: '0px',
      backgroundImage: `url("${assets.smockSheet}")`,
      backgroundRepeat: 'no-repeat',
      backgroundSize: `${(HINA_SMOCK_NATIVE_W * s).toFixed(2)}px ${(HINA_SMOCK_NATIVE_H * s).toFixed(2)}px`,
      backgroundPosition: `${(offsetX - (cell.x + inset) * s).toFixed(2)}px ${(offsetY - (cell.y + inset) * s).toFixed(2)}px`
    };
  }

  // Pieces 2–12 (index 1..11)
  if (tabIndex === 0) {
    const sp = HINA_SPRITES[pieceIndex] || HINA_SPRITES[0];
    const s = Math.min((safeW * 0.9) / sp.w, (safeH * 0.88) / sp.h);
    const drawW = sp.w * s;
    const drawH = sp.h * s;
    const left = (safeW - drawW) / 2;
    const top = (safeH - drawH) / 2;
    return {
      width: `${drawW.toFixed(2)}px`,
      height: `${drawH.toFixed(2)}px`,
      left: `${left.toFixed(2)}px`,
      top: `${top.toFixed(2)}px`,
      backgroundImage: `url("${assets.sprite}")`,
      backgroundRepeat: 'no-repeat',
      backgroundSize: `${(HINA_SPRITE_NATIVE_W * s).toFixed(2)}px ${(HINA_SPRITE_NATIVE_H * s).toFixed(2)}px`,
      backgroundPosition: `${(-sp.x * s).toFixed(2)}px ${(-sp.y * s).toFixed(2)}px`
    };
  }

  const colIdx = pieceIndex % 4;
  const rowIdx = Math.floor(pieceIndex / 4);
  const cols = tabIndex === 1 ? FABRIC_COLS : DETAIL_COLS;
  const rows = tabIndex === 1 ? FABRIC_ROWS : DETAIL_ROWS;
  const sheetUrl = tabIndex === 1 ? assets.fabricSheet : assets.detailSheet;

  const x0 = cols[colIdx][0] + 6;
  const x1 = cols[colIdx][1] - 6;
  const y0 = rows[rowIdx][0] + 6;
  const y1 = rows[rowIdx][1] - 6;
  const cellW = x1 - x0;
  const cellH = y1 - y0;

  const s = Math.max(safeW / cellW, safeH / cellH);
  const drawW = cellW * s;
  const drawH = cellH * s;
  const offsetX = (safeW - drawW) / 2;
  const offsetY = (safeH - drawH) / 2;

  return {
    width: `${safeW.toFixed(2)}px`,
    height: `${safeH.toFixed(2)}px`,
    left: '0px',
    top: '0px',
    backgroundImage: `url("${sheetUrl}")`,
    backgroundRepeat: 'no-repeat',
    backgroundSize: `${(HINA_SPRITE_NATIVE_W * s).toFixed(2)}px ${(HINA_SPRITE_NATIVE_H * s).toFixed(2)}px`,
    backgroundPosition: `${(offsetX - x0 * s).toFixed(2)}px ${(offsetY - y0 * s).toFixed(2)}px`
  };
};
