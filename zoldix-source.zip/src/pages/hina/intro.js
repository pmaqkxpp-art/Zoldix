const EASING = 'cubic-bezier(.2,.75,.2,1)';

export const runHinaIntro = ({
  rootEl,
  tubeEl,
  navEl,
  garmentEls,
  lineEls,
  chromeEls,
  reducedMotion
}) => {
  if (!rootEl) return () => {};
  const animations = [];
  let finished = false;

  const revealImmediate = () => {
    if (finished) return;
    finished = true;
    rootEl.classList.remove('hina-pre');
  };

  if (reducedMotion) {
    revealImmediate();
    return () => {};
  }

  rootEl.classList.remove('hina-pre');

  try {
    if (tubeEl) {
      animations.push(
        tubeEl.animate(
          [
            { opacity: 0, clipPath: 'inset(0 100% 0 0)' },
            { opacity: 1, clipPath: 'inset(0 0% 0 0)' }
          ],
          { duration: 1000, delay: 100, easing: EASING, fill: 'backwards' }
        )
      );
    }

    if (navEl) {
      animations.push(
        navEl.animate([{ opacity: 0 }, { opacity: 1 }], {
          duration: 900,
          delay: 200,
          easing: EASING,
          fill: 'backwards'
        })
      );
    }

    garmentEls.forEach((el, slot) => {
      if (!el) return;
      animations.push(
        el.animate(
          [
            { opacity: 0, translate: '0 -14px' },
            { opacity: 1, translate: '0 0px' }
          ],
          {
            duration: 900,
            delay: 250 + slot * 35,
            easing: EASING,
            fill: 'backwards'
          }
        )
      );
    });

    lineEls.forEach((el, idx) => {
      if (!el) return;
      animations.push(
        el.animate(
          [
            { transform: 'translateY(105%)', opacity: 0 },
            { transform: 'translateY(0%)', opacity: 1 }
          ],
          {
            duration: 1000,
            delay: 650 + idx * 70,
            easing: EASING,
            fill: 'backwards'
          }
        )
      );
    });

    chromeEls.forEach((el, idx) => {
      if (!el) return;
      animations.push(
        el.animate([{ opacity: 0 }, { opacity: 1 }], {
          duration: 900,
          delay: 900 + idx * 70,
          easing: EASING,
          fill: 'backwards'
        })
      );
    });
  } catch {
    revealImmediate();
  }

  const failsafe = setTimeout(revealImmediate, 4000);

  return () => {
    clearTimeout(failsafe);
    animations.forEach(a => {
      try {
        a.cancel();
      } catch {}
    });
  };
};
