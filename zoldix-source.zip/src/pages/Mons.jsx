import { useEffect, useMemo, useRef, useState } from 'react';
import { getContourDataUri, getMonsMedia, hitTestKit } from './mons/data.js';
import { createTrailBuffer } from './mons/trail.js';
import { createMonsWebGL } from './mons/webgl.js';
import { createMonsParallax } from './mons/parallax.js';
import { runMonsIntro } from './mons/loader.js';
import './mons.css';

export default function Mons({ pageReady }) {
  const media = useMemo(() => getMonsMedia(), []);
  const contourUri = useMemo(() => getContourDataUri(), []);
  const [imgSrc, setImgSrc] = useState(media.layerA);
  const [tip, setTip] = useState({ show: false, x: 0, y: 0, name: '' });
  const [spec, setSpec] = useState(null);
  const [isPointer, setIsPointer] = useState(false);
  const [glReady, setGlReady] = useState(false);

  const pageRef = useRef(null);
  const stageRef = useRef(null);
  const frameRef = useRef(null);
  const canvasRef = useRef(null);
  const modelRef = useRef(null);
  const loaderRef = useRef(null);
  const barRef = useRef(null);
  const stripRefs = useRef([]);
  const sliceRefs = useRef([]);
  const bandRef = useRef(null);
  const chevLeftRef = useRef(null);
  const chevRightRef = useRef(null);
  const tagsRef = useRef(null);
  const decoRef = useRef(null);
  const wmRef = useRef(null);
  const g1Ref = useRef(null);
  const g2Ref = useRef(null);
  const texRef = useRef(null);
  const cardRef = useRef(null);
  const hintRef = useRef(null);
  const logoRef = useRef(null);
  const navRef = useRef(null);
  const brkRefs = useRef([]);

  const metricsRef = useRef({ s: 1, fx: 0, fy: 0, k: 1 });
  const glPromiseRef = useRef(null);

  // Body overflow lock & restore on unmount
  useEffect(() => {
    const prevHtmlOverflow = document.documentElement.style.overflow;
    const prevBodyOverflow = document.body.style.overflow;
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';
    return () => {
      document.documentElement.style.overflow = prevHtmlOverflow;
      document.body.style.overflow = prevBodyOverflow;
    };
  }, []);

  // Responsive 3-tier scaling engine (L, S, P)
  useEffect(() => {
    const page = pageRef.current;
    if (!page) return undefined;

    const computeLayout = () => {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const aspect = vw / Math.max(1, vh);
      let s = 1;
      let fx = 0;
      let fy = 0;
      let k = 1;
      let tier = 'L';

      if (aspect >= 1.05 && vh >= 560) {
        tier = 'L';
        s = vw / 1440;
        fx = 0;
        fy = aspect > 1.6 ? 0 : vh - 900 * s;
        k = Math.min(vw / 1440, vh / 900);
      } else if (aspect >= 1.05 && vh < 560) {
        tier = 'S';
        s = vh / 900;
        fx = 0.64 * vw - 700 * s;
        fy = 0;
        k = s;
      } else {
        tier = 'P';
        const cardH = cardRef.current ? cardRef.current.offsetHeight : 120;
        const hintH = hintRef.current ? hintRef.current.offsetHeight : 72;
        const stackBottom = 64 + cardH + 10 + hintH + 12;
        s = Math.min(vw / 420, Math.max(0.25, (vh - stackBottom) / 780), (vw / 900) * 1.9);
        fx = vw / 2 - 705 * s;
        fy = vh - 900 * s;
        k = Math.min(1, vw / 900);
        page.style.setProperty('--p-hint-top', `${64 + cardH + 10}px`);
      }

      const colw = Math.min(330, Math.max(190, fx + 300 * s - 32));
      const colR = tier === 'S' ? 16 + colw : 0;
      const winL = Math.max(0, (colR - fx) / s);
      const winR = (vw - fx) / s;
      const avail = Math.max(180, (winR - winL) * s - 40);

      page.classList.remove('tier-L', 'tier-S', 'tier-P');
      page.classList.add(`tier-${tier}`);
      page.classList.toggle('mons-tags-hidden', (tier === 'P' && vw < 640) || (tier === 'S' && vw < 700));

      page.style.setProperty('--s', s.toFixed(5));
      page.style.setProperty('--fx', `${fx.toFixed(2)}px`);
      page.style.setProperty('--fy', `${fy.toFixed(2)}px`);
      page.style.setProperty('--k', k.toFixed(5));
      page.style.setProperty('--colw', `${colw.toFixed(1)}px`);

      if (tier === 'S' || tier === 'P') {
        const wmFont = 326 * Math.min(1, avail / (1280 * s));
        const wmLeft = (winL + winR) / 2 - (wmFont * 2.02) - 0.0755 * wmFont;
        const wmTop = 131 - 0.107 * wmFont;
        if (wmRef.current) {
          wmRef.current.style.fontSize = `${wmFont.toFixed(1)}px`;
          wmRef.current.style.left = `${wmLeft.toFixed(1)}px`;
          wmRef.current.style.top = `${wmTop.toFixed(1)}px`;
        }
        page.style.setProperty('--clx', (-fx / s).toFixed(2));
        page.style.setProperty('--crx', (winR - 1440).toFixed(2));
        const tagShift = Math.max(0, (colR - fx) / s + 16 / s - 255);
        page.style.setProperty('--tagx', tagShift.toFixed(2));
      } else {
        if (wmRef.current) {
          wmRef.current.style.fontSize = '';
          wmRef.current.style.left = '';
          wmRef.current.style.top = '';
        }
        page.style.setProperty('--clx', '0');
        page.style.setProperty('--crx', '0');
        page.style.setProperty('--tagx', '0');
      }

      metricsRef.current = { s, fx, fy, k };
      return { s, k };
    };

    computeLayout();
    window.addEventListener('resize', computeLayout);
    return () => window.removeEventListener('resize', computeLayout);
  }, []);

  // WebGL trail + Parallax + Pointer interaction
  useEffect(() => {
    const stage = stageRef.current;
    const canvas = canvasRef.current;
    if (!stage || !canvas) return undefined;

    const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    const trail = createTrailBuffer();

    const parallax = reducedMotion
      ? null
      : createMonsParallax({
          chevrons: [chevLeftRef.current, chevRightRef.current],
          tags: tagsRef.current,
          deco: decoRef.current,
          wordmark: wmRef.current,
          glasses: [g1Ref.current, g2Ref.current],
          texture: texRef.current,
          card: cardRef.current,
          hint: hintRef.current
        });

    let webgl = null;
    let glRaf = 0;
    let lastTick = 0;
    let alive = true;
    let draggingTouch = false;

    const glInit = createMonsWebGL(canvas, media.layerA, media.layerB, trail.canvas).then(instance => {
      if (!alive) {
        instance?.destroy();
        return null;
      }
      if (instance) {
        webgl = instance;
        webgl.setSize(metricsRef.current.s);
        webgl.render(0, true);
        setGlReady(true);
      }
      return instance;
    });
    glPromiseRef.current = glInit;

    const loop = now => {
      glRaf = 0;
      if (!alive || !webgl) return;
      const dt = lastTick ? Math.min(50, now - lastTick) : 16;
      lastTick = now;
      const stillActive = trail.decay(dt);
      webgl.render(now * 0.001, true);
      if (stillActive && !document.hidden) {
        glRaf = requestAnimationFrame(loop);
      } else {
        lastTick = 0;
      }
    };

    const wakeGL = () => {
      if (!glRaf && webgl && !document.hidden && alive) {
        lastTick = 0;
        glRaf = requestAnimationFrame(loop);
      }
    };

    const toFrameCoords = (clientX, clientY) => {
      const { s, fx, fy } = metricsRef.current;
      return [(clientX - fx) / s, (clientY - fy) / s];
    };

    const onPointerMove = event => {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      if (parallax) {
        parallax.setUnit(metricsRef.current.k);
        parallax.setTarget((event.clientX / vw) * 2 - 1, (event.clientY / vh) * 2 - 1);
      }

      const [fx, fy] = toFrameCoords(event.clientX, event.clientY);
      if (!reducedMotion && (event.pointerType === 'mouse' || draggingTouch)) {
        trail.pushFramePoint(fx, fy);
        wakeGL();
      }

      if (event.pointerType === 'mouse') {
        const piece = hitTestKit(fx, fy);
        if (piece) {
          setIsPointer(true);
          const flipX = event.clientX + 200 > vw;
          const flipY = event.clientY + 80 > vh;
          setTip({
            show: true,
            x: flipX ? event.clientX - 180 : event.clientX + 18,
            y: flipY ? event.clientY - 56 : event.clientY + 16,
            name: piece.name
          });
        } else {
          setIsPointer(false);
          setTip(prev => (prev.show ? { ...prev, show: false } : prev));
        }
      }
    };

    const onPointerDown = event => {
      if (event.pointerType !== 'mouse') {
        draggingTouch = true;
        const [fx, fy] = toFrameCoords(event.clientX, event.clientY);
        if (!reducedMotion) {
          trail.pushFramePoint(fx, fy);
          wakeGL();
        }
      }
    };

    const onPointerUp = event => {
      if (event.pointerType !== 'mouse') {
        draggingTouch = false;
        trail.resetPointer();
        parallax?.reset();
      }
    };

    const onPointerLeave = () => {
      trail.resetPointer();
      parallax?.reset();
      setIsPointer(false);
      setTip(prev => (prev.show ? { ...prev, show: false } : prev));
    };

    const onClick = event => {
      if (event.target.closest('.mons-spec, .mons-nav, .mons-logo')) return;
      const [fx, fy] = toFrameCoords(event.clientX, event.clientY);
      const piece = hitTestKit(fx, fy);
      if (!piece) {
        setSpec(null);
        return;
      }
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      if (vw < 640) {
        setSpec({ piece, mobile: true, x: 0, y: 0 });
      } else {
        const x = Math.min(vw - 276, Math.max(16, event.clientX + 20));
        const y = Math.min(vh - 200, Math.max(16, event.clientY - 80));
        setSpec({ piece, mobile: false, x, y });
      }
    };

    const onKeyDown = event => {
      if (event.key === 'Escape') setSpec(null);
    };

    const onResize = () => {
      webgl?.setSize(metricsRef.current.s);
      webgl?.render(performance.now() * 0.001, false);
    };

    const onVisibility = () => {
      if (!document.hidden && trail.isActive()) wakeGL();
    };

    stage.addEventListener('pointermove', onPointerMove);
    stage.addEventListener('pointerdown', onPointerDown);
    stage.addEventListener('pointerup', onPointerUp);
    stage.addEventListener('pointercancel', onPointerUp);
    stage.addEventListener('pointerleave', onPointerLeave);
    stage.addEventListener('click', onClick);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('resize', onResize);
    document.addEventListener('visibilitychange', onVisibility);

    return () => {
      alive = false;
      cancelAnimationFrame(glRaf);
      stage.removeEventListener('pointermove', onPointerMove);
      stage.removeEventListener('pointerdown', onPointerDown);
      stage.removeEventListener('pointerup', onPointerUp);
      stage.removeEventListener('pointercancel', onPointerUp);
      stage.removeEventListener('pointerleave', onPointerLeave);
      stage.removeEventListener('click', onClick);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('resize', onResize);
      document.removeEventListener('visibilitychange', onVisibility);
      parallax?.destroy();
      webgl?.destroy();
    };
  }, [media.layerA, media.layerB]);

  // Trigger MONS intro only once pageReady (after global Zoldix Loader finishes)
  useEffect(() => {
    if (!pageReady) return undefined;
    const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    const hudEls = [
      logoRef.current,
      navRef.current,
      decoRef.current,
      g1Ref.current,
      g2Ref.current,
      tagsRef.current,
      ...brkRefs.current,
      cardRef.current,
      hintRef.current
    ].filter(Boolean);

    const waitAssetsPromise = Promise.race([
      Promise.all([
        glPromiseRef.current || Promise.resolve(),
        document.fonts?.ready || Promise.resolve()
      ]),
      new Promise(r => setTimeout(r, 1500))
    ]);

    return runMonsIntro({
      root: pageRef.current,
      loaderEl: loaderRef.current,
      barEl: barRef.current,
      strips: stripRefs.current,
      sliceEls: sliceRefs.current,
      bandEl: bandRef.current,
      modelEl: modelRef.current,
      chevLeft: chevLeftRef.current,
      chevRight: chevRightRef.current,
      hudEls,
      reducedMotion,
      waitAssetsPromise
    });
  }, [pageReady]);

  const slices = [0, 1, 2, 3, 4, 5];

  return (
    <div ref={pageRef} className="mons-page js-anim">
      <div
        ref={stageRef}
        className={`mons-stage ${isPointer ? 'is-pointer' : ''}`}
        aria-label="MONS rain shell hero"
      >
        <div
          ref={texRef}
          className="mons-tex"
          style={{ backgroundImage: `url("${contourUri}")` }}
          aria-hidden="true"
        />

        <div ref={frameRef} className="mons-frame">
          {/* Chevrons behind wordmark */}
          <svg
            ref={chevRightRef}
            className="mons-chev mons-chev-tr"
            viewBox="0 0 1440 900"
            style={{ transform: 'translateX(calc(var(--crx) * 1px))' }}
            aria-hidden="true"
          >
            <polygon points="560,-400 723,-400 1515,195 1352,195" />
          </svg>
          <svg
            ref={chevLeftRef}
            className="mons-chev"
            viewBox="0 0 1440 900"
            style={{ transform: 'translateX(calc(var(--clx) * 1px))' }}
            aria-hidden="true"
          >
            <polygon points="-54,462 101,462 281,642 281,660 -60,926 -60,792 134,636" />
          </svg>

          {/* Wordmark + 6 intro slices + frosted panels */}
          <div ref={wmRef} className="mons-wm" aria-hidden="true">
            <span ref={bandRef} className="mons-wm-band rv">
              MONS
            </span>
            {slices.map(i => (
              <span
                key={i}
                ref={el => {
                  sliceRefs.current[i] = el;
                }}
                className="mons-wm-slice"
                style={{
                  clipPath: `inset(${(i / 6) * 100}% 0 ${(1 - (i + 1) / 6) * 100}% 0)`
                }}
              >
                MONS
              </span>
            ))}
            <div ref={g1Ref} className="mons-glass mons-g1 rv" />
            <div ref={g2Ref} className="mons-glass mons-g2 rv">
              <span className="mons-g2-hatch" />
            </div>
          </div>

          {/* Model + WebGL unmask canvas */}
          <div ref={modelRef} className={`mons-model rv ${glReady ? 'gl' : ''}`}>
            <img
              src={imgSrc}
              alt={media.alt}
              crossOrigin="anonymous"
              className="mons-model-img"
              onError={() => {
                if (imgSrc !== media.fallbackA) setImgSrc(media.fallbackA);
              }}
            />
            <canvas ref={canvasRef} className="mons-model-gl" />
          </div>

          {/* Decorative SVG */}
          <svg ref={decoRef} className="mons-deco rv" viewBox="0 0 1440 900" aria-hidden="true">
            <g
              className="mons-tag-leaders"
              stroke="#4D4A4E"
              strokeWidth="1"
              strokeOpacity="0.75"
              fill="none"
              vectorEffect="non-scaling-stroke"
              style={{ transform: 'translateX(calc(var(--tagx) * 1px))' }}
            >
              <path d="M403 411 H447 L527 448" />
              <path d="M430 465 H462 L498 486" />
            </g>
            <line
              x1="282"
              y1="626"
              x2="462"
              y2="497"
              stroke="#4D4A4E"
              strokeWidth="1"
              strokeOpacity="0.55"
              vectorEffect="non-scaling-stroke"
            />
            {[
              [265, 83],
              [980, 433],
              [1188, 578]
            ].map(([cx, cy], idx) => (
              <g key={idx} stroke="#4D4A4E" strokeWidth="1.2" strokeOpacity="0.8" fill="none">
                <circle cx={cx} cy={cy} r="7" />
                <line x1={cx - 13} y1={cy} x2={cx + 13} y2={cy} />
                <line x1={cx} y1={cy - 13} x2={cx} y2={cy + 13} />
              </g>
            ))}
          </svg>

          {/* Kit tags & brackets */}
          <div ref={tagsRef} className="mons-tags rv">
            <div className="mons-tag mons-tag-1">TRK 01 / HOOD</div>
            <div className="mons-tag mons-tag-2">TRK 02 / SHELL + SLING</div>
            <span
              ref={el => {
                brkRefs.current[0] = el;
              }}
              className="mons-brk tl"
              style={{ left: 281, top: 393 }}
            />
            <span
              ref={el => {
                brkRefs.current[1] = el;
              }}
              className="mons-brk br"
              style={{ left: 396, top: 419 }}
            />
            <span
              ref={el => {
                brkRefs.current[2] = el;
              }}
              className="mons-brk tl"
              style={{ left: 255, top: 447 }}
            />
            <span
              ref={el => {
                brkRefs.current[3] = el;
              }}
              className="mons-brk br"
              style={{ left: 423, top: 473 }}
            />
          </div>
        </div>

        {/* Viewport HUD */}
        <a ref={logoRef} href="#/mons" className="mons-logo rv" aria-label="MONS home">
          <span />
          <span />
          <span />
        </a>

        <nav ref={navRef} className="mons-nav rv" aria-label="MONS navigation">
          <a href="#/mons" onClick={e => e.preventDefault()}>
            Shop
          </a>
          <a href="#/mons" onClick={e => e.preventDefault()}>
            Tech
          </a>
          <a href="#/mons" onClick={e => e.preventDefault()}>
            Journal
          </a>
        </nav>

        <div ref={cardRef} className="mons-card rv">
          <svg className="mons-card-cross" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" aria-hidden="true">
            <circle cx="12" cy="12" r="6.5" />
            <line x1="12" y1="2" x2="12" y2="22" />
            <line x1="2" y1="12" x2="22" y2="12" />
          </svg>
          <div className="mons-card-eyebrow">Monsoon Commuter</div>
          <h2 className="mons-card-head">
            Built for the downpour.
            <br />
            Worn every day.
          </h2>
        </div>

        <div ref={hintRef} className="mons-hint rv">
          <div className="mons-hint-hatch" aria-hidden="true" />
          <p>Hover to unmask / click a piece to view</p>
          <p>Scroll ↓</p>
        </div>

        {/* Hover Tip */}
        <div
          className={`mons-tip ${tip.show ? 'on' : ''}`}
          style={{ left: `${tip.x}px`, top: `${tip.y}px` }}
          aria-hidden="true"
        >
          <div className="mons-tip-name">{tip.name}</div>
          <div className="mons-tip-sub">
            CLICK TO VIEW <b>[SPECS]</b>
          </div>
        </div>

        {/* Spec Card */}
        {spec && (
          <div
            className="mons-spec on"
            style={
              spec.mobile
                ? { left: '50%', bottom: 16, transform: 'translateX(-50%)' }
                : { left: `${spec.x}px`, top: `${spec.y}px` }
            }
            role="dialog"
            aria-label={spec.piece.name}
          >
            <div className="mons-spec-head">
              <span className="mons-spec-sq" />
              <h3 className="mons-spec-title">{spec.piece.name}</h3>
              <button type="button" className="mons-spec-close" aria-label="Close specs" onClick={() => setSpec(null)}>
                ×
              </button>
            </div>
            <ul className="mons-spec-list">
              {spec.piece.specs.map((line, i) => (
                <li key={i}>{line}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Slice-Glitch Loader */}
        <div ref={loaderRef} className="mons-ld" aria-hidden="true">
          {Array.from({ length: 10 }, (_, idx) => (
            <div
              key={idx}
              ref={el => {
                stripRefs.current[idx] = el;
              }}
              data-strip-idx={idx}
              className="mons-ld-strip"
            />
          ))}
          <div className="mons-ld-word">
            {'MONS'.split('').map((ch, idx) => (
              <span key={idx} className="mons-ld-ch" style={{ animationDelay: `${40 + idx * 70}ms` }}>
                {idx === 0 && <span className="mons-ld-ghost">{ch}</span>}
                {ch}
              </span>
            ))}
          </div>
          <div ref={barRef} className="mons-ld-bar" />
        </div>
      </div>
    </div>
  );
}
