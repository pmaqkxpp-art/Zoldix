import { getPackshotCssStyle } from './data.js';

export const runVestraSwap = ({
  fromIndex,
  toIndex,
  products,
  layout,
  sheetUrl,
  wearEls,
  flyLayerEl,
  titleMaskEl,
  priceMaskEl,
  pillContentEl,
  railEl,
  slot0Index,
  reducedMotion,
  onPillSwap,
  onMidSwap,
  onDone
}) => {
  const animations = [];
  const timers = [];

  if (reducedMotion) {
    wearEls.forEach((el, idx) => {
      if (!el) return;
      el.classList.toggle('on', idx === toIndex);
      el.style.zIndex = idx === toIndex ? '2' : '0';
      el.style.opacity = idx === toIndex ? '1' : '0';
    });
    onMidSwap?.(toIndex);
    onPillSwap?.(toIndex);
    onDone?.(toIndex);
    return () => {};
  }

  const fromEl = wearEls[fromIndex];
  const toEl = wearEls[toIndex];

  if (fromEl) {
    fromEl.style.zIndex = '1';
    fromEl.style.opacity = '1';
    fromEl.classList.add('on');
  }
  if (toEl) {
    toEl.style.zIndex = '2';
    toEl.style.opacity = '0';
    toEl.classList.add('on');
  }

  // t=100..350ms: old title and price exit up behind masks; t=350..800ms: new title and price rise in
  const swapMaskedText = (maskEl, newText) => {
    if (!maskEl) return;
    const oldSpan = maskEl.querySelector('.vestra-mask-cur');
    if (oldSpan) {
      const clone = document.createElement('span');
      clone.className = 'vestra-mask-old';
      clone.textContent = oldSpan.textContent;
      maskEl.appendChild(clone);
      const a1 = clone.animate(
        [{ transform: 'translateY(0%)' }, { transform: 'translateY(-105%)' }],
        { duration: 250, delay: 100, easing: 'cubic-bezier(.55,0,.8,.3)', fill: 'forwards' }
      );
      animations.push(a1);
      a1.onfinish = () => clone.remove();

      oldSpan.textContent = newText;
      oldSpan.style.transform = 'translateY(105%)';
      const a2 = oldSpan.animate(
        [{ transform: 'translateY(105%)' }, { transform: 'translateY(0%)' }],
        { duration: 450, delay: 350, easing: 'cubic-bezier(.22,.61,.36,1)', fill: 'forwards' }
      );
      animations.push(a2);
    }
  };

  swapMaskedText(titleMaskEl, products[toIndex].title);
  swapMaskedText(priceMaskEl, products[toIndex].price);

  // t=100..300ms: fade existing rail packshots except flyer
  if (railEl) {
    railEl.querySelectorAll('.vestra-packshot').forEach(node => {
      if (Number(node.dataset.idx) !== toIndex) {
        const anim = node.animate([{ opacity: 1 }, { opacity: 0 }], {
          duration: 200,
          delay: 100,
          easing: 'linear',
          fill: 'forwards'
        });
        animations.push(anim);
      }
    });
  }

  // t=60..1070ms: flyer packshot glides from slot onto torso
  if (flyLayerEl) {
    const prod = products[toIndex];
    const [x, y, w, h] = prod.box;
    const s = layout.packScale;
    const inRailAtSlot0 = toIndex === slot0Index;
    const startSlot = inRailAtSlot0 ? layout.slots[0] : toIndex === (fromIndex + 2) % 4 ? layout.slots[1] : layout.slots[0];

    const boxW = w * s;
    const boxH = h * s;
    const startCx = startSlot.left + boxW / 2;
    const startCy = startSlot.cy;

    const flyer = document.createElement('div');
    flyer.className = 'vestra-flyer';
    Object.assign(flyer.style, getPackshotCssStyle(toIndex, s, sheetUrl), {
      position: 'absolute',
      left: `${(startSlot.left).toFixed(2)}px`,
      top: `${(startCy - boxH / 2).toFixed(2)}px`,
      transformOrigin: 'center center',
      zIndex: 4,
      pointerEvents: 'none'
    });
    flyLayerEl.appendChild(flyer);

    const dx = layout.torsoCenterX - startCx;
    const dy = layout.torsoCenterY - startCy;
    const k = (0.86 * 600 * layout.ps) / (w * s);

    const glideAnim = flyer.animate(
      [
        { transform: 'translate(0px, 0px) scale(1)' },
        { transform: `translate(${dx.toFixed(2)}px, ${dy.toFixed(2)}px) scale(${k.toFixed(4)})` }
      ],
      {
        duration: 950,
        delay: 60,
        easing: 'cubic-bezier(.22,.9,.3,1)',
        fill: 'forwards'
      }
    );
    animations.push(glideAnim);

    const opacityKeyframes = inRailAtSlot0 || toIndex === (fromIndex + 2) % 4
      ? [
          { opacity: 1, offset: 0 },
          { opacity: 1, offset: 0.45 },
          { opacity: 0.6, offset: 0.72 },
          { opacity: 0, offset: 1 }
        ]
      : [
          { opacity: 0, offset: 0 },
          { opacity: 1, offset: 0.18 },
          { opacity: 1, offset: 0.45 },
          { opacity: 0.6, offset: 0.72 },
          { opacity: 0, offset: 1 }
        ];

    const fadeAnim = flyer.animate(opacityKeyframes, {
      duration: 1010,
      delay: 60,
      easing: 'ease-in-out',
      fill: 'forwards'
    });
    animations.push(fadeAnim);
    fadeAnim.onfinish = () => flyer.remove();
  }

  // t=420..1180ms: wear plate T fades from 0 to 1 on top of A
  if (toEl) {
    const wearAnim = toEl.animate([{ opacity: 0 }, { opacity: 1 }], {
      duration: 760,
      delay: 420,
      easing: 'cubic-bezier(.45,0,.25,1)',
      fill: 'forwards'
    });
    animations.push(wearAnim);
    wearAnim.onfinish = () => {
      toEl.style.opacity = '1';
      if (fromEl && fromEl !== toEl) {
        fromEl.classList.remove('on');
        fromEl.style.opacity = '0';
        fromEl.style.zIndex = '0';
      }
    };
  }

  // t=600ms: rail rebuild + pagination dash + pill crossfade
  const midTimer = setTimeout(() => {
    onMidSwap?.(toIndex);
    if (pillContentEl) {
      const outAnim = pillContentEl.animate([{ opacity: 1 }, { opacity: 0 }], {
        duration: 150,
        easing: 'linear',
        fill: 'forwards'
      });
      animations.push(outAnim);
      outAnim.onfinish = () => {
        onPillSwap?.(toIndex);
        const inAnim = pillContentEl.animate([{ opacity: 0 }, { opacity: 1 }], {
          duration: 150,
          easing: 'linear',
          fill: 'forwards'
        });
        animations.push(inAnim);
      };
    } else {
      onPillSwap?.(toIndex);
    }
  }, 600);
  timers.push(midTimer);

  // t=1200ms: complete
  const doneTimer = setTimeout(() => {
    onDone?.(toIndex);
  }, 1200);
  timers.push(doneTimer);

  return () => {
    timers.forEach(clearTimeout);
    animations.forEach(a => {
      try {
        a.cancel();
      } catch {}
    });
  };
};
