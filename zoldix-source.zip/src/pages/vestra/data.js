import { DEFAULT_ASSETS, DEFAULT_PRODUCTS, higgsProxy } from '../../config/defaults.js';
import { getAsset, loadSiteConfig } from '../../config/siteConfig.js';

const CF_PREFIX = 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/';

const RAW_PLATE_NAMES = {
  'vestra.base': 'hf_20261115_071307_1d0f42d5-b05f-4e21-bf76-f52fb4b12bb5.png',
  'vestra.wear.0': 'hf_20261115_071402_80cf9c12-dd74-45cf-a639-1f8580543ff3.png',
  'vestra.wear.1': 'hf_20261115_071402_63307d14-96fd-4b18-bae5-034018df0692.png',
  'vestra.wear.2': 'hf_20261115_071402_01ef6ea1-a2e6-4d0d-83ce-cbae31202ccc.png',
  'vestra.wear.3': 'hf_20261115_071400_47a4d43c-8f7c-4f0a-b860-1dc753202b92.png',
  'vestra.sheet': 'hf_20261115_071304_55f839b8-7976-43af-8b07-b439c6be0936.png'
};

export const PACKSHOT_BOXES = [
  [134, 79, 760, 863],
  [1138, 79, 790, 863],
  [137, 1024, 748, 901],
  [1146, 1011, 776, 966]
];

export const getVestraProducts = () => {
  const cfg = loadSiteConfig();
  const list = cfg.products?.vestra;
  if (!Array.isArray(list) || list.length < 4) return DEFAULT_PRODUCTS.vestra;
  return list.map((item, idx) => ({
    ...DEFAULT_PRODUCTS.vestra[idx],
    ...item,
    box: PACKSHOT_BOXES[idx]
  }));
};

export const getVestraAssetUrl = (key, isPhone) => {
  const configured = getAsset(key);
  const defaultVal = DEFAULT_ASSETS[key];
  if (configured !== defaultVal) {
    return configured;
  }
  const file = RAW_PLATE_NAMES[key];
  if (!file) return defaultVal;
  const width = key === 'vestra.sheet' ? (isPhone ? 1024 : 2048) : isPhone ? 1280 : 2048;
  return higgsProxy(`${CF_PREFIX}${file}`, width);
};

export const getPackshotCssStyle = (index, k, sheetUrl) => {
  const [x, y, w, h] = PACKSHOT_BOXES[index] || PACKSHOT_BOXES[0];
  return {
    width: `${(w * k).toFixed(2)}px`,
    height: `${(h * k).toFixed(2)}px`,
    backgroundImage: `url("${sheetUrl}")`,
    backgroundSize: `${(2048 * k).toFixed(2)}px ${(2048 * k).toFixed(2)}px`,
    backgroundPosition: `${(-x * k).toFixed(2)}px ${(-y * k).toFixed(2)}px`,
    backgroundRepeat: 'no-repeat'
  };
};
