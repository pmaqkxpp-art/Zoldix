const shuffle = array => {
  for (let i = array.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
};

export const runVestraTilesReveal = ({
  overlayEl,
  isPhone,
  reducedMotion,
  baseUrl,
  wear0Url,
  onRevealed
}) => {
  if (!overlayEl || reducedMotion) {
    if (overlayEl) overlayEl.style.display = 'none';
    onRevealed?.();
    return () => {};
  }

  overlayEl.innerHTML = '';
  const cols = isPhone ? 5 : 10;
  const rows = isPhone ? 9 : 6;
  overlayEl.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
  overlayEl.style.gridTemplateRows = `repeat(${rows}, 1fr)`;
  overlayEl.style.display = 'grid';

  const count = cols * rows;
  const tiles = [];
  for (let i = 0; i < count; i += 1) {
    const tile = document.createElement('div');
    tile.className = 'vestra-tile';
    overlayEl.appendChild(tile);
    tiles.push(tile);
  }

  const order = shuffle(Array.from({ length: count }, (_, i) => i));
  let raf = 0;
  let started = false;
  let cancelled = false;

  const finish = () => {
    if (cancelled) return;
    overlayEl.style.display = 'none';
    overlayEl.innerHTML = '';
    onRevealed?.();
  };

  const beginClear = () => {
    if (started || cancelled) return;
    started = true;
    const t0 = performance.now();
    let hiddenCount = 0;

    const tick = now => {
      if (cancelled) return;
      const elapsed = now - t0;
      const target = Math.min(count, Math.floor((elapsed / 600) * count));
      while (hiddenCount < target) {
        tiles[order[hiddenCount]].style.visibility = 'hidden';
        hiddenCount += 1;
      }
      if (hiddenCount < count) {
        raf = requestAnimationFrame(tick);
      } else {
        finish();
      }
    };
    raf = requestAnimationFrame(tick);
  };

  const decode = src =>
    new Promise(resolve => {
      const img = new Image();
      img.decoding = 'async';
      img.onload = () => (img.decode ? img.decode().then(resolve, resolve) : resolve());
      img.onerror = resolve;
      img.src = src;
    });

  Promise.race([
    Promise.all([decode(baseUrl), decode(wear0Url)]),
    new Promise(r => setTimeout(r, 1800))
  ]).then(beginClear);

  const safetyTimer = setTimeout(finish, 1800 + 1000);

  return () => {
    cancelled = true;
    cancelAnimationFrame(raf);
    clearTimeout(safetyTimer);
  };
};
