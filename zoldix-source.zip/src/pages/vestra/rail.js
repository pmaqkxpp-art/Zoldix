export const computeVestraLayout = (vw, vh, shopBottom = 0) => {
  const isPhone = vw < 820;
  const u = isPhone ? vw / 390 : Math.min(vw / 1440, vh / 900);

  if (!isPhone) {
    const navH = Math.max(44 * u, 40);
    const ps = Math.max(vw / 2048, vh / 1360);
    const ox = (vw - 2048 * ps) / 2;
    let oy = (vh - 1360 * ps) / 2;
    oy = Math.min(0, Math.max(oy, navH + 18 * u - 150 * ps));

    const packScale = 0.335 * u;
    const cy = vh * 0.5 - 13 * u;
    const slots = [
      { left: vw - 393 * u, cy },
      { left: vw - 120 * u, cy }
    ];

    return {
      isPhone: false,
      u,
      ps,
      ox,
      oy,
      packScale,
      slots,
      torsoCenterX: ox + 1012 * ps,
      torsoCenterY: oy + 710 * ps,
      flyEndScale: (0.86 * 600 * ps) / (760 * packScale),
      stageMask: false
    };
  }

  const stageTop = Math.max(210, shopBottom + 8);
  const stageBottom = vh - 82;
  const stageHeight = Math.max(240, stageBottom - stageTop);
  const ps = Math.min(stageHeight / 1080, (0.64 * vw) / 600);
  const ox = vw * 0.39 - 1012 * ps;
  const oy = stageTop - 120 * ps;
  const packScale = 0.29 * ps;
  const railCy = stageTop + 0.4 * stageHeight;

  const slots = [
    { left: vw - 102 * u, cy: railCy },
    { left: vw - 10 * u, cy: railCy }
  ];

  return {
    isPhone: true,
    u,
    ps,
    ox,
    oy,
    packScale,
    stageTop,
    stageHeight,
    railCy,
    dashesTop: railCy + 500 * packScale,
    slots,
    torsoCenterX: ox + 1012 * ps,
    torsoCenterY: oy + 710 * ps,
    flyEndScale: (0.86 * 600 * ps) / (760 * packScale),
    stageMask: true
  };
};
