export const attachVestraInput = ({
  heroEl,
  onStep,
  onPauseChange
}) => {
  let accum = 0;
  let lastDir = 0;
  let resetTimer = 0;
  let lastStepAt = 0;
  let touchStart = null;
  let suppressedClick = false;
  let hoveringPauseEl = false;
  let pressingHero = false;

  const updatePause = () => {
    onPauseChange?.(hoveringPauseEl || pressingHero || document.hidden);
  };

  const onWheel = event => {
    event.preventDefault();
    let dy = event.deltaY;
    if (event.deltaMode === 1) dy *= 16;
    else if (event.deltaMode === 2) dy *= window.innerHeight;
    if (!dy) return;

    const dir = dy > 0 ? 1 : -1;
    if (lastDir && dir !== lastDir) accum = 0;
    lastDir = dir;
    accum += dy;

    clearTimeout(resetTimer);
    resetTimer = setTimeout(() => {
      accum = 0;
      lastDir = 0;
    }, 250);

    const now = performance.now();
    if (Math.abs(accum) >= 50 && now - lastStepAt >= 140) {
      lastStepAt = now;
      accum = 0;
      onStep(dir, true);
    }
  };

  const onKeyDown = event => {
    if (event.key === 'ArrowRight' || event.key === 'ArrowDown' || event.key === 'PageDown') {
      event.preventDefault();
      onStep(1, true);
    } else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp' || event.key === 'PageUp') {
      event.preventDefault();
      onStep(-1, true);
    }
  };

  const onPointerDown = event => {
    if (event.button !== undefined && event.button > 0) return;
    pressingHero = true;
    suppressedClick = false;
    touchStart = { x: event.clientX, y: event.clientY };
    updatePause();
  };

  const onPointerUp = event => {
    pressingHero = false;
    updatePause();
    if (!touchStart) return;
    const dx = event.clientX - touchStart.x;
    const dy = event.clientY - touchStart.y;
    touchStart = null;
    if (Math.hypot(dx, dy) > 40) {
      suppressedClick = true;
      if (Math.abs(dx) >= Math.abs(dy)) {
        onStep(dx < 0 ? 1 : -1, true);
      } else {
        onStep(dy < 0 ? 1 : -1, true);
      }
    }
  };

  const onPointerCancel = () => {
    pressingHero = false;
    touchStart = null;
    updatePause();
  };

  const onPointerOver = event => {
    const target = event.target instanceof Element ? event.target : null;
    const overPause = Boolean(target?.closest('.vestra-packshot, .vestra-pill, .vestra-shop-btn'));
    if (overPause !== hoveringPauseEl) {
      hoveringPauseEl = overPause;
      updatePause();
    }
  };

  const onWindowLeave = () => {
    hoveringPauseEl = false;
    pressingHero = false;
    updatePause();
  };

  const onVisibility = () => updatePause();

  window.addEventListener('wheel', onWheel, { passive: false });
  window.addEventListener('keydown', onKeyDown);
  heroEl.addEventListener('pointerdown', onPointerDown);
  window.addEventListener('pointerup', onPointerUp);
  window.addEventListener('pointercancel', onPointerCancel);
  heroEl.addEventListener('pointerover', onPointerOver);
  window.addEventListener('blur', onWindowLeave);
  document.addEventListener('visibilitychange', onVisibility);

  return {
    wasDragClick: () => suppressedClick,
    destroy: () => {
      clearTimeout(resetTimer);
      window.removeEventListener('wheel', onWheel);
      window.removeEventListener('keydown', onKeyDown);
      heroEl.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('pointercancel', onPointerCancel);
      heroEl.removeEventListener('pointerover', onPointerOver);
      window.removeEventListener('blur', onWindowLeave);
      document.removeEventListener('visibilitychange', onVisibility);
    }
  };
};
