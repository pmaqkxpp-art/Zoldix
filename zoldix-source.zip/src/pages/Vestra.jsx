import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { getPackshotCssStyle, getVestraAssetUrl, getVestraProducts } from './vestra/data.js';
import { computeVestraLayout } from './vestra/rail.js';
import { runVestraSwap } from './vestra/swap.js';
import { attachVestraInput } from './vestra/input.js';
import { runVestraTilesReveal } from './vestra/loader.js';
import './vestra.css';

export default function Vestra({ pageReady }) {
  const products = useMemo(() => getVestraProducts(), []);
  const [vw, setVw] = useState(() => (typeof window !== 'undefined' ? window.innerWidth : 1440));
  const [vh, setVh] = useState(() => (typeof window !== 'undefined' ? window.innerHeight : 900));
  const [shopBottom, setShopBottom] = useState(190);
  const [active, setActive] = useState(0);
  const [railBase, setRailBase] = useState(0);
  const [pillIdx, setPillIdx] = useState(0);
  const [cartCount, setCartCount] = useState(2);

  const heroRef = useRef(null);
  const shopBtnRef = useRef(null);
  const wearRefs = useRef([]);
  const flyLayerRef = useRef(null);
  const titleMaskRef = useRef(null);
  const priceMaskRef = useRef(null);
  const pillContentRef = useRef(null);
  const railRef = useRef(null);
  const tilesRef = useRef(null);

  const isPhone = vw < 820;
  const layout = useMemo(() => computeVestraLayout(vw, vh, shopBottom), [vw, vh, shopBottom]);

  const baseUrl = useMemo(() => getVestraAssetUrl('vestra.base', isPhone), [isPhone]);
  const sheetUrl = useMemo(() => getVestraAssetUrl('vestra.sheet', isPhone), [isPhone]);
  const wearUrls = useMemo(
    () => [0, 1, 2, 3].map(i => getVestraAssetUrl(`vestra.wear.${i}`, isPhone)),
    [isPhone]
  );

  const stateRef = useRef({
    current: 0,
    swapping: false,
    queued: null,
    paused: false,
    userHoldUntil: 0,
    revealed: false,
    autoplayTimer: 0,
    cancelSwap: null
  });

  // Body overflow lock
  useEffect(() => {
    const prevHtml = document.documentElement.style.overflow;
    const prevBody = document.body.style.overflow;
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';
    return () => {
      document.documentElement.style.overflow = prevHtml;
      document.body.style.overflow = prevBody;
    };
  }, []);

  // Measure viewport & shopBottom for phone mask placement
  useEffect(() => {
    const onResize = () => {
      setVw(window.innerWidth);
      setVh(window.innerHeight);
      if (shopBtnRef.current) {
        const rect = shopBtnRef.current.getBoundingClientRect();
        if (rect.bottom) setShopBottom(rect.bottom);
      }
    };
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const scheduleAutoplay = useCallback(delayMs => {
    const st = stateRef.current;
    clearTimeout(st.autoplayTimer);
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    if (reduced || !st.revealed || st.paused) return;
    const now = performance.now();
    const wait = Math.max(delayMs, st.userHoldUntil - now);
    st.autoplayTimer = setTimeout(() => {
      if (!st.paused && !st.swapping && st.revealed) {
        triggerSwap((st.current + 1) % 4);
      }
    }, wait);
  }, []);

  const triggerSwap = useCallback(
    targetIdx => {
      const st = stateRef.current;
      const normalized = ((targetIdx % 4) + 4) % 4;
      if (st.swapping) {
        st.queued = normalized === st.current ? null : normalized;
        return;
      }
      if (normalized === st.current) return;

      st.swapping = true;
      clearTimeout(st.autoplayTimer);
      const fromIdx = st.current;
      const slot0Idx = (fromIdx + 1) % 4;
      const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;

      st.cancelSwap = runVestraSwap({
        fromIndex: fromIdx,
        toIndex: normalized,
        products,
        layout,
        sheetUrl,
        wearEls: wearRefs.current,
        flyLayerEl: flyLayerRef.current,
        titleMaskEl: titleMaskRef.current,
        priceMaskEl: priceMaskRef.current,
        pillContentEl: pillContentRef.current,
        railEl: railRef.current,
        slot0Index: slot0Idx,
        reducedMotion: reduced,
        onMidSwap: idx => {
          setActive(idx);
          setRailBase(idx);
        },
        onPillSwap: idx => {
          setPillIdx(idx);
        },
        onDone: idx => {
          st.current = idx;
          st.swapping = false;
          setActive(idx);
          setRailBase(idx);
          if (st.queued !== null && st.queued !== idx) {
            const nextQ = st.queued;
            st.queued = null;
            triggerSwap(nextQ);
          } else {
            st.queued = null;
            scheduleAutoplay(2000);
          }
        }
      });
    },
    [layout, products, scheduleAutoplay, sheetUrl]
  );

  // Tile reveal when global Zoldix Loader finishes
  useEffect(() => {
    if (!pageReady) return undefined;
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    const st = stateRef.current;
    const cancelReveal = runVestraTilesReveal({
      overlayEl: tilesRef.current,
      isPhone: window.innerWidth < 820,
      reducedMotion: reduced,
      baseUrl,
      wear0Url: wearUrls[0],
      onRevealed: () => {
        st.revealed = true;
        scheduleAutoplay(2000);
      }
    });
    return () => {
      cancelReveal();
      clearTimeout(st.autoplayTimer);
      st.cancelSwap?.();
    };
  }, [pageReady, baseUrl, wearUrls, scheduleAutoplay]);

  // Input listeners
  useEffect(() => {
    const hero = heroRef.current;
    if (!hero) return undefined;
    const st = stateRef.current;
    const input = attachVestraInput({
      heroEl: hero,
      onStep: (dir, isUser) => {
        if (isUser) st.userHoldUntil = performance.now() + 6000;
        const base = st.queued !== null ? st.queued : st.current;
        triggerSwap(base + dir);
      },
      onPauseChange: paused => {
        st.paused = paused;
        if (paused) clearTimeout(st.autoplayTimer);
        else scheduleAutoplay(2000);
      }
    });
    hero._vestraInput = input;
    return () => {
      input.destroy();
    };
  }, [scheduleAutoplay, triggerSwap]);

  // Animate new rail packshots on railBase change
  useEffect(() => {
    const rail = railRef.current;
    if (!rail) return;
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    if (reduced) return;
    rail.querySelectorAll('.vestra-packshot').forEach(node => {
      node.animate(
        [
          { opacity: 0, transform: `translateX(${(45 * layout.u).toFixed(1)}px)` },
          { opacity: 1, transform: 'translateX(0px)' }
        ],
        { duration: 350, easing: 'cubic-bezier(.22,.61,.36,1)', fill: 'forwards' }
      );
    });
  }, [railBase, layout.u]);

  const slotItems = [
    { prodIdx: (railBase + 1) % 4, slot: layout.slots[0] },
    { prodIdx: (railBase + 2) % 4, slot: layout.slots[1] }
  ];

  const pillProd = products[pillIdx] || products[0];
  const pillThumbScale = Math.min(38 / pillProd.box[2], 38 / pillProd.box[3]) * 0.92;

  return (
    <div ref={heroRef} className="vestra-page">
      {/* Nav */}
      <header className="vestra-nav">
        <button
          type="button"
          className="vestra-coll-btn"
          onClick={() => {
            stateRef.current.userHoldUntil = performance.now() + 6000;
            triggerSwap(stateRef.current.current + 1);
          }}
        >
          <span>Collections</span>
          <svg viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true">
            <path d="M2 3.5 l3 3 3-3" />
          </svg>
        </button>

        <h1 className="vestra-wordmark">VESTRA</h1>

        <div className="vestra-nav-icons">
          <button type="button" className="vestra-icon-btn" aria-label="Account">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <circle cx="12" cy="8" r="4" />
              <path d="M4.5 20.5 c1.2-3.8 4-5.5 7.5-5.5 s6.3 1.7 7.5 5.5 z" />
            </svg>
          </button>
          <button type="button" className="vestra-icon-btn" aria-label="Shopping bag">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M5 8 h14 l-1 12.5 H6 z" />
              <path d="M8.5 10 V6.8 a3.5 3.5 0 0 1 7 0 V10" />
            </svg>
            <span className="vestra-badge">{cartCount}</span>
          </button>
        </div>
      </header>

      {/* Stacked Plates */}
      <div
        className={`vestra-plates ${layout.stageMask ? 'masked' : ''}`}
        style={{
          transform: `translate(${layout.ox.toFixed(2)}px, ${layout.oy.toFixed(2)}px) scale(${layout.ps.toFixed(5)})`
        }}
      >
        <img src={baseUrl} alt="VESTRA model base" className="vestra-plate base" decoding="async" />
        {wearUrls.map((src, idx) => (
          <img
            key={idx}
            ref={el => {
              wearRefs.current[idx] = el;
            }}
            src={src}
            alt={products[idx].title}
            className={`vestra-plate ${idx === 0 ? 'on' : ''}`}
            decoding="async"
          />
        ))}
      </div>

      {/* Flyer layer */}
      <div ref={flyLayerRef} className="vestra-fly-layer" />

      {/* Product Rail */}
      <div ref={railRef} className="vestra-rail">
        {slotItems.map(({ prodIdx, slot }, slotNumber) => {
          const box = products[prodIdx].box;
          const top = slot.cy - (box[3] * layout.packScale) / 2;
          return (
            <div
              key={`${railBase}-${slotNumber}-${prodIdx}`}
              data-idx={prodIdx}
              className="vestra-packshot"
              role="button"
              tabIndex={0}
              aria-label={`Try on ${products[prodIdx].title}`}
              style={{
                ...getPackshotCssStyle(prodIdx, layout.packScale, sheetUrl),
                left: `${slot.left.toFixed(2)}px`,
                top: `${top.toFixed(2)}px`
              }}
              onClick={() => {
                if (heroRef.current?._vestraInput?.wasDragClick()) return;
                stateRef.current.userHoldUntil = performance.now() + 6000;
                triggerSwap(prodIdx);
              }}
            />
          );
        })}
      </div>

      {/* Left Copy Column */}
      <div className="vestra-copy">
        <p className="vestra-eyebrow">NEW SEASON</p>
        <div ref={titleMaskRef} className="vestra-title-mask">
          <span className="vestra-mask-cur">{products[0].title}</span>
        </div>
        <div ref={priceMaskRef} className="vestra-price-mask">
          <span className="vestra-mask-cur">{products[0].price}</span>
        </div>
        <button
          ref={shopBtnRef}
          type="button"
          className="vestra-shop-btn"
          onClick={() => setCartCount(c => c + 1)}
        >
          <span>Shop Now</span>
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true">
            <path d="M2 8 h11" />
            <path d="M9 4 l4 4-4 4" />
          </svg>
        </button>
      </div>

      {/* Pagination Dashes */}
      <div
        className="vestra-dashes"
        style={isPhone ? { left: '20px', top: `${layout.dashesTop?.toFixed(1)}px` } : undefined}
      >
        {[0, 1, 2, 3].map(idx => (
          <button
            key={idx}
            type="button"
            className={`vestra-dash ${active === idx ? 'active' : ''}`}
            aria-label={`Show ${products[idx].title}`}
            onClick={() => {
              stateRef.current.userHoldUntil = performance.now() + 6000;
              triggerSwap(idx);
            }}
          />
        ))}
      </div>

      {/* Right Edge Indicator */}
      <div className="vestra-edge-track" aria-hidden="true">
        <div className="vestra-edge-fill" />
      </div>

      {/* Bottom Cart Pill */}
      <div className="vestra-pill">
        <div ref={pillContentRef} className="vestra-pill-content">
          <div className="vestra-pill-thumb">
            <div style={getPackshotCssStyle(pillIdx, pillThumbScale, sheetUrl)} />
          </div>
          <div className="vestra-pill-meta">
            <div className="vestra-pill-name">{pillProd.pillName}</div>
            <div className="vestra-pill-sub">{pillProd.subLabel}</div>
          </div>
          <div className="vestra-pill-price">{pillProd.price}</div>
        </div>
        <button type="button" className="vestra-add-btn" onClick={() => setCartCount(c => c + 1)}>
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.3" aria-hidden="true">
            <path d="M3.5 5.5 h9 l-.7 8 h-7.6 z" />
            <path d="M6 7 V4.6 a2 2 0 0 1 4 0 V7" />
          </svg>
          <span>Add to cart</span>
        </button>
      </div>

      {/* Drag to explore */}
      <div className="vestra-drag-hint">
        <span>Drag to explore</span>
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true">
          <path d="M2 8 h11" />
          <path d="M9 4 l4 4-4 4" />
        </svg>
      </div>

      {/* Loading Reveal Tiles */}
      <div ref={tilesRef} className="vestra-tiles" aria-hidden="true" />
    </div>
  );
}
