import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AERO_CORNERS, AERO_FITS, AERO_HOTSPOTS, AERO_LENSES, getAeroAssets } from './aero/data.js';
import { createMagentaKeyer } from './aero/keyer.js';
import { createSceneController } from './aero/scenes.js';
import { attachAeroCursor, formatAeroDate, formatPragueClock } from './aero/panel.js';
import './aero.css';

const GRAIN_URI =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E";

export default function Aero({ pageReady }) {
  const assets = useMemo(() => getAeroAssets(), []);
  const recMode = useMemo(
    () => (typeof window !== 'undefined' ? window.location.search.includes('rec') : false),
    []
  );

  const [scene, setScene] = useState(0);
  const [exitingQuickFacts, setExitingQuickFacts] = useState(false);
  const [lobesPopped, setLobesPopped] = useState([false, false, false]);
  const [lensIdx, setLensIdx] = useState(0);
  const [fitIdx, setFitIdx] = useState(1);
  const [poppingLens, setPoppingLens] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalOrigin, setModalOrigin] = useState({ x: 50, y: 50 });
  const [toastMsg, setToastMsg] = useState('');
  const [toastShow, setToastShow] = useState(false);
  const [clock, setClock] = useState(formatPragueClock);
  const [hoverGlasses, setHoverGlasses] = useState(false);
  const [openHotspot, setOpenHotspot] = useState(null);
  const [posterFallback, setPosterFallback] = useState(false);
  const [introDone, setIntroDone] = useState(false);

  const stageRef = useRef(null);
  const headerRef = useRef(null);
  const footerRef = useRef(null);
  const wordmarkWrapRef = useRef(null);
  const wordmarkTrackRef = useRef(null);
  const marqueeTrackRef = useRef(null);
  const plinthWrapRef = useRef(null);
  const glassesWrapRef = useRef(null);
  const glassesLeanRef = useRef(null);
  const canvasRef = useRef(null);
  const turnVideoRef = useRef(null);
  const blobVideoRef = useRef(null);
  const logoVideoRef = useRef(null);
  const cursorRef = useRef(null);
  const sliceRefs = useRef([]);
  const cornerLeft1Ref = useRef(null);
  const cornerLeft2Ref = useRef(null);
  const cornerRight1Ref = useRef(null);
  const cornerRight2Ref = useRef(null);

  const controllerRef = useRef(null);
  const fastScrollRef = useRef(false);
  const toastTimerRef = useRef(0);
  const prevSceneRef = useRef(0);

  const showToast = useCallback(msg => {
    setToastMsg(msg);
    setToastShow(true);
    clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setToastShow(false), 2200);
  }, []);

  // Lock body overflow cleanly
  useEffect(() => {
    const prevHtml = document.documentElement.style.overflow;
    const prevBody = document.body.style.overflow;
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';
    return () => {
      document.documentElement.style.overflow = prevHtml;
      document.body.style.overflow = prevBody;
    };
  }, []);

  // Prague live clock
  useEffect(() => {
    const id = setInterval(() => setClock(formatPragueClock()), 15000);
    return () => clearInterval(id);
  }, []);

  // Custom cursor
  useEffect(() => {
    return attachAeroCursor({ cursorEl: cursorRef.current, recMode });
  }, [recMode]);

  // Intro timeline after Zoldix Loader exits
  useEffect(() => {
    if (!pageReady) return undefined;
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    if (reduced) {
      setIntroDone(true);
      return undefined;
    }

    const anims = [];
    const easeOut = 'cubic-bezier(.16,1,.3,1)';

    if (headerRef.current) {
      anims.push(
        headerRef.current.animate(
          [
            { opacity: 0, transform: 'translateY(-18px)' },
            { opacity: 1, transform: 'translateY(0)' }
          ],
          { duration: 750, easing: easeOut, fill: 'backwards' }
        )
      );
    }
    if (footerRef.current) {
      anims.push(
        footerRef.current.animate(
          [
            { opacity: 0, transform: 'translateY(18px)' },
            { opacity: 1, transform: 'translateY(0)' }
          ],
          { duration: 750, delay: 80, easing: easeOut, fill: 'backwards' }
        )
      );
    }
    if (wordmarkWrapRef.current) {
      anims.push(
        wordmarkWrapRef.current.animate(
          [
            { clipPath: 'inset(50% 0 50% 0)', opacity: 0 },
            { clipPath: 'inset(0% 0 0% 0)', opacity: 1 }
          ],
          { duration: 900, delay: 140, easing: easeOut, fill: 'backwards' }
        )
      );
    }
    if (plinthWrapRef.current) {
      anims.push(
        plinthWrapRef.current.animate(
          [
            { opacity: 0, transform: 'translate(-50%, 40vh)' },
            { opacity: 1, transform: 'translate(-50%, 0)' }
          ],
          { duration: 1000, delay: 220, easing: easeOut, fill: 'backwards' }
        )
      );
    }
    if (glassesWrapRef.current) {
      anims.push(
        glassesWrapRef.current.animate(
          [
            {
              opacity: 0,
              transform: 'translate(-50%, calc(-50% - 30vh)) scale(0.6) rotate(-14deg)',
              filter: 'blur(20px)'
            },
            {
              opacity: 1,
              transform: 'translate(-50%, -50%) scale(1) rotate(0deg)',
              filter: 'blur(0px)'
            }
          ],
          { duration: 1050, delay: 320, easing: easeOut, fill: 'backwards' }
        )
      );
    }

    const doneTimer = setTimeout(() => setIntroDone(true), 1400);
    return () => {
      clearTimeout(doneTimer);
      anims.forEach(a => {
        try {
          a.cancel();
        } catch {}
      });
    };
  }, [pageReady]);

  // Swap corner headlines safely when scene changes
  useEffect(() => {
    const els = [cornerLeft1Ref.current, cornerLeft2Ref.current, cornerRight1Ref.current, cornerRight2Ref.current].filter(
      Boolean
    );
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    if (reduced) return;
    els.forEach((el, idx) => {
      el.getAnimations?.().forEach(a => a.cancel());
      el.animate(
        [
          { transform: 'translateY(115%)', opacity: 0 },
          { transform: 'translateY(0%)', opacity: 1 }
        ],
        { duration: 680, delay: idx * 55, easing: 'cubic-bezier(.16,1,.3,1)', fill: 'backwards' }
      );
    });
  }, [scene]);

  // Trigger Scene 3 Blob playback & Scene 4 Outro 12 slice bars on scene change
  useEffect(() => {
    const prev = prevSceneRef.current;
    prevSceneRef.current = scene;

    if (prev === 2 && scene !== 2) {
      setExitingQuickFacts(true);
      setTimeout(() => setExitingQuickFacts(false), 820);
    }

    if (scene === 2) {
      setLobesPopped([false, false, false]);
      const bv = blobVideoRef.current;
      if (bv) {
        try {
          bv.currentTime = 0;
          bv.play().catch(() => {});
        } catch {}
      }
    }

    if (scene === 3) {
      const lv = logoVideoRef.current;
      if (lv) {
        try {
          lv.currentTime = 0;
          lv.play().catch(() => {});
        } catch {}
      }
      const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
      if (!reduced) {
        sliceRefs.current.forEach((bar, idx) => {
          if (!bar) return;
          bar.getAnimations?.().forEach(a => a.cancel());
          const distFromCenter = Math.abs(idx - 5.5);
          bar.animate(
            [{ transform: 'scaleY(1)' }, { transform: 'scaleY(0)' }],
            {
              duration: 720,
              delay: distFromCenter * 55,
              easing: 'cubic-bezier(.77,0,.18,1)',
              fill: 'both'
            }
          );
        });
      }
    }
  }, [scene]);

  // Monitor Blob currentTime >= 3.7s -> pop 3 RGB-split lobes staggered by 0.15s
  useEffect(() => {
    if (scene !== 2) return undefined;
    const bv = blobVideoRef.current;
    let triggered = false;
    const fireLobes = () => {
      if (triggered) return;
      triggered = true;
      setTimeout(() => setLobesPopped([true, false, false]), 0);
      setTimeout(() => setLobesPopped([true, true, false]), 150);
      setTimeout(() => setLobesPopped([true, true, true]), 300);
    };

    const onTimeUpdate = () => {
      if (bv && bv.currentTime >= 3.7) {
        fireLobes();
      }
    };
    const onEnded = () => {
      if (bv) bv.pause();
      fireLobes();
    };
    const fallbackTimer = setTimeout(fireLobes, 4100);

    bv?.addEventListener('timeupdate', onTimeUpdate);
    bv?.addEventListener('ended', onEnded);
    return () => {
      clearTimeout(fallbackTimer);
      bv?.removeEventListener('timeupdate', onTimeUpdate);
      bv?.removeEventListener('ended', onEnded);
    };
  }, [scene]);

  // WebGL turntable chroma keyer + continuous marquees
  useEffect(() => {
    const canvas = canvasRef.current;
    const video = turnVideoRef.current;
    let keyer = null;
    if (canvas && !posterFallback) {
      keyer = createMagentaKeyer({
        canvas,
        posterUrl: assets.poster,
        onFallback: () => setPosterFallback(true)
      });
    }

    if (video) {
      video.play().catch(() => {});
    }

    let rafId = 0;
    let alive = true;
    let lastNow = performance.now();
    let wmX = 0;
    let mqX = 0;
    let currentRate = 1;

    const tick = now => {
      if (!alive) return;
      const dt = Math.min(0.05, (now - lastNow) * 0.001);
      lastNow = now;

      if (!document.hidden) {
        if (recMode) {
          if (video && video.duration) video.currentTime = ((now * 0.001) % video.duration);
        } else if (video) {
          const targetRate = hoverGlasses ? 2.6 : 1.0;
          currentRate += (targetRate - currentRate) * 0.08;
          if (Math.abs(video.playbackRate - currentRate) > 0.02) {
            video.playbackRate = currentRate;
          }
        }

        if (keyer && scene <= 1) {
          keyer.renderFrame(video);
        }

        const speedMult = fastScrollRef.current ? 4.2 : 1;
        if (wordmarkTrackRef.current) {
          const singleW = wordmarkTrackRef.current.scrollWidth / 4 || 1200;
          wmX = (wmX - 65 * speedMult * dt) % singleW;
          wordmarkTrackRef.current.style.transform = `translate3d(${wmX.toFixed(1)}px, 0, 0)`;
        }

        if (marqueeTrackRef.current && scene === 2) {
          const singleW = marqueeTrackRef.current.scrollWidth / 4 || 1000;
          mqX = (mqX - 80 * speedMult * dt) % singleW;
          marqueeTrackRef.current.style.transform = `translate3d(${mqX.toFixed(1)}px, 0, 0)`;
        }
      }

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => {
      alive = false;
      cancelAnimationFrame(rafId);
      keyer?.destroy();
    };
  }, [assets.poster, hoverGlasses, posterFallback, recMode, scene]);

  // Scene controller + Wheel / Key / Touch input
  useEffect(() => {
    const stageEl = stageRef.current;
    if (!stageEl) return undefined;

    const ctrl = createSceneController({
      onProgress: () => {},
      onSceneChange: nextScene => setScene(nextScene),
      onTransitionChange: transitioning => {
        fastScrollRef.current = transitioning;
      }
    });
    controllerRef.current = ctrl;

    let wheelAcc = 0;
    let touchStartY = 0;
    let touchStartX = 0;

    const onWheel = event => {
      event.preventDefault();
      if (ctrl.isLocked()) return;
      wheelAcc += event.deltaY;
      if (Math.abs(wheelAcc) > 40) {
        const dir = wheelAcc > 0 ? 1 : -1;
        wheelAcc = 0;
        ctrl.step(dir);
      }
    };

    const onKeyDown = event => {
      if (event.target.closest('input, textarea')) return;
      if (event.key === 'Escape' && modalOpen) {
        setModalOpen(false);
        return;
      }
      if (event.key === 'ArrowDown' || event.key === 'PageDown' || event.key === ' ') {
        event.preventDefault();
        ctrl.step(1);
      } else if (event.key === 'ArrowUp' || event.key === 'PageUp') {
        event.preventDefault();
        ctrl.step(-1);
      }
    };

    const onTouchStart = event => {
      if (!event.touches?.[0]) return;
      touchStartY = event.touches[0].clientY;
      touchStartX = event.touches[0].clientX;
    };

    const onTouchEnd = event => {
      if (!event.changedTouches?.[0]) return;
      const dy = event.changedTouches[0].clientY - touchStartY;
      const dx = event.changedTouches[0].clientX - touchStartX;
      if (Math.abs(dy) > 40 && Math.abs(dy) >= Math.abs(dx)) {
        ctrl.step(dy < 0 ? 1 : -1);
      } else if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) {
        ctrl.step(dx < 0 ? 1 : -1);
      }
    };

    const onPointerMove = event => {
      if (!introDone || scene !== 0) return;
      const sx = (event.clientX / Math.max(1, window.innerWidth)) * 2 - 1;
      const sy = (event.clientY / Math.max(1, window.innerHeight)) * 2 - 1;
      if (glassesLeanRef.current) {
        glassesLeanRef.current.style.transform = `translate(${(sx * -26).toFixed(1)}px, ${(sy * -16).toFixed(1)}px) rotate(${(sx * 2).toFixed(2)}deg)`;
      }
      if (wordmarkWrapRef.current) {
        wordmarkWrapRef.current.style.transform = `translate3d(${(sx * 18).toFixed(1)}px, ${(sy * 8).toFixed(1)}px, 0)`;
      }
    };

    stageEl.addEventListener('wheel', onWheel, { passive: false });
    stageEl.addEventListener('touchstart', onTouchStart, { passive: true });
    stageEl.addEventListener('touchend', onTouchEnd, { passive: true });
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('pointermove', onPointerMove, { passive: true });

    return () => {
      ctrl.destroy();
      stageEl.removeEventListener('wheel', onWheel);
      stageEl.removeEventListener('touchstart', onTouchStart);
      stageEl.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('pointermove', onPointerMove);
    };
  }, [introDone, modalOpen, scene]);

  const selectLens = idx => {
    setLensIdx(idx);
    setPoppingLens(false);
    requestAnimationFrame(() => setPoppingLens(true));
    showToast(`Lens switched to ${AERO_LENSES[idx].name}`);
  };

  const openModalFromEvent = event => {
    const rect = event?.currentTarget?.getBoundingClientRect?.();
    const cx = rect ? rect.left + rect.width / 2 : window.innerWidth / 2;
    const cy = rect ? rect.top + rect.height / 2 : window.innerHeight / 2;
    setModalOrigin({
      x: (cx / Math.max(1, window.innerWidth)) * 100,
      y: (cy / Math.max(1, window.innerHeight)) * 100
    });
    setModalOpen(true);
  };

  const activeLens = AERO_LENSES[lensIdx];
  const corner = AERO_CORNERS[scene];

  // Hero leave transforms when scene > 0
  const leaveHero = scene > 0;

  return (
    <div
      ref={stageRef}
      className="aero-page"
      style={{
        '--hue': `${activeLens.deg}deg`,
        '--half-hue': `${(activeLens.deg * 0.5).toFixed(1)}deg`
      }}
    >
      <div className="aero-glow" aria-hidden="true" />
      <div className="aero-grain" style={{ backgroundImage: `url("${GRAIN_URI}")` }} aria-hidden="true" />

      {/* Persistent Header */}
      <header ref={headerRef} className="aero-header">
        <div className="aero-brand">
          <svg viewBox="0 0 24 20" fill="none" aria-hidden="true">
            <path d="M2 18 L7.5 2 H12 L8 10 H5.5 L4.5 12 H7.5 L5 18 Z" fill="#f1f3ee" />
            <path d="M12.5 18 L18 2 H22.5 L17 18 Z" fill="#c6ff3d" />
          </svg>
          <span>KYNE AERO.VISION</span>
        </div>

        <span className="aero-welcome">N.1 • WELCOME TO THE FUTURE</span>

        <nav className="aero-nav" aria-label="KYNE navigation">
          <button type="button" onClick={() => controllerRef.current?.goTo(1)}>
            .shop
          </button>
          <button type="button" onClick={() => controllerRef.current?.goTo(2)}>
            .about
          </button>
          <button type="button" onClick={() => controllerRef.current?.goTo(0)}>
            .collection
          </button>
          <button type="button" onClick={() => controllerRef.current?.goTo(3)}>
            .info
          </button>
        </nav>

        <div className="aero-clock">
          <span>[PRG]</span>
          <span>{clock}</span>
        </div>

        <span className="aero-ping-dot" aria-hidden="true" />

        <button type="button" className="aero-preorder-pill" onClick={openModalFromEvent}>
          <span>PRE-ORDER</span>
          <span className="aero-arrow-chip" aria-hidden="true">
            →
          </span>
        </button>
      </header>

      {/* Top Corners */}
      <div className="aero-corners">
        <div>
          <span className="aero-ln aero-corner-title">
            <span ref={cornerLeft1Ref} className="aero-ln-inner">
              {corner.leftTitle}
            </span>
          </span>
          <span className="aero-ln aero-corner-sub">
            <span ref={cornerLeft2Ref} className="aero-ln-inner">
              {corner.leftSub}
            </span>
          </span>
        </div>
        <div className="aero-corner-right">
          <span className="aero-ln aero-corner-title">
            <span ref={cornerRight1Ref} className="aero-ln-inner">
              {corner.rightTitle}
            </span>
          </span>
          <span className="aero-ln aero-corner-sub">
            <span ref={cornerRight2Ref} className="aero-ln-inner">
              {corner.rightSub}
            </span>
          </span>
        </div>
      </div>

      {/* SCENE 1 — HERO */}
      <section className={`aero-scene-1 ${scene === 0 ? 'is-active' : ''}`} aria-label="Hero scene">
        <div
          ref={wordmarkWrapRef}
          className="aero-wordmark-wrap"
          style={
            leaveHero
              ? {
                  transform: 'translate3d(0, -18vh, 0)',
                  clipPath: 'inset(0 0 100% 0)',
                  opacity: 0
                }
              : undefined
          }
        >
          <div ref={wordmarkTrackRef} className="aero-wordmark-track">
            {[0, 1, 2, 3].map(i => (
              <img key={i} src={assets.wordmark} alt="" decoding="async" />
            ))}
          </div>
        </div>

        <div
          ref={plinthWrapRef}
          className="aero-plinth-wrap"
          style={
            leaveHero
              ? {
                  transform: 'translate(-50%, 55vh)',
                  opacity: 0
                }
              : undefined
          }
        >
          <img src={assets.plinth} alt="" decoding="async" />
        </div>

        <div
          ref={glassesWrapRef}
          className="aero-glasses-wrap"
          style={
            leaveHero
              ? {
                  transform: 'translate(22vw, -50%) scale(1.22)',
                  clipPath: 'inset(0 0 0 100%)',
                  opacity: 0
                }
              : { clipPath: 'inset(0 0 0 0)' }
          }
          onMouseEnter={() => setHoverGlasses(true)}
          onMouseLeave={() => setHoverGlasses(false)}
          onClick={() => controllerRef.current?.goTo(1)}
        >
          <div ref={glassesLeanRef} className={`aero-glasses-lean ${poppingLens ? 'is-pop' : ''}`}>
            <video
              ref={turnVideoRef}
              src={assets.video}
              poster={assets.poster}
              crossOrigin="anonymous"
              muted
              loop
              playsInline
              preload="metadata"
              style={{ display: 'none' }}
            />
            {!posterFallback ? (
              <canvas ref={canvasRef} className="aero-glasses-canvas" />
            ) : (
              <img
                src={assets.poster}
                alt="KYNE AERO.VISION liquid-chrome sunglasses"
                className="aero-glasses-poster-fallback"
                onError={e => {
                  e.currentTarget.src = assets.fallbackPoster;
                }}
              />
            )}
          </div>
        </div>

        {scene === 0 && (
          <div className="aero-hero-caption">
            {hoverGlasses ? 'SPINNING · 2.6×' : '● HOVER TO SPIN · SCROLL TO EXPLORE'}
          </div>
        )}
      </section>

      {/* SCENE 2 — DETAIL */}
      <section className={`aero-scene-2 ${scene === 1 ? 'is-active' : ''}`} aria-label="Detail close-up">
        <div className="aero-detail-copy">
          <div className="aero-swatch" aria-hidden="true" />
          <h2 className="aero-lens-heading">
            lens.<span className="aero-lens-brace">{`{${activeLens.name.toLowerCase()}}`}</span>
          </h2>
          <p>LIQUID-CHROME NYLON MONOCOQUE ENGINEERED FOR ZERO-DRAG PERIPHERAL CLARITY.</p>
          <p>HYDRO-LOCKED TEMPLES + PHOTOCHROMIC SHIELD TUNED FOR HIGH-OUTPUT RIDES.</p>
        </div>

        <div className="aero-detail-media-wrap">
          <img src={assets.detail} alt="KYNE AERO.VISION frame close-up" decoding="async" />
          {AERO_HOTSPOTS.map(hs => (
            <button
              key={hs.id}
              type="button"
              className={`aero-hotspot ${openHotspot === hs.id ? 'is-open' : ''}`}
              style={{ left: `${hs.x}%`, top: `${hs.y}%` }}
              aria-label={hs.title}
              onClick={() => setOpenHotspot(cur => (cur === hs.id ? null : hs.id))}
            >
              +
              <div className="aero-hotspot-card">
                <h4>{hs.title}</h4>
                <p>{hs.body}</p>
              </div>
            </button>
          ))}
        </div>

        <div className="aero-detail-meta">
          <span>MASS · 24.0G TOTAL</span>
          <span>OPTICS · CAT 1–3 SHIELD</span>
        </div>
      </section>

      {/* SCENE 3 — QUICK FACTS */}
      <section
        className={`aero-scene-3 ${scene === 2 ? 'is-active' : ''} ${exitingQuickFacts ? 'is-exiting' : ''}`}
        aria-label="Quick facts"
      >
        <div className="aero-blob-wrap">
          <video
            ref={blobVideoRef}
            src={assets.blobVideo}
            className="aero-blob-video"
            muted
            playsInline
            preload="metadata"
          />

          {/* Three RGB-split icons */}
          <div className={`aero-lobe ${lobesPopped[0] ? 'is-popped' : ''}`}>
            <svg className="aero-lobe-icon" viewBox="0 0 40 40" fill="none" stroke="currentColor" strokeWidth="1.8">
              <circle cx="20" cy="20" r="3" />
              <ellipse cx="20" cy="10" rx="3" ry="6" />
              <ellipse cx="20" cy="30" rx="3" ry="6" />
              <ellipse cx="11.3" cy="15" rx="6" ry="3" transform="rotate(30 11.3 15)" />
              <ellipse cx="28.7" cy="25" rx="6" ry="3" transform="rotate(30 28.7 25)" />
              <ellipse cx="11.3" cy="25" rx="6" ry="3" transform="rotate(-30 11.3 25)" />
              <ellipse cx="28.7" cy="15" rx="6" ry="3" transform="rotate(-30 28.7 15)" />
            </svg>
            <div className="aero-lobe-label">
              <span className="aero-lobe-key">WEIGHT</span>
              <span className="aero-lobe-val">.24g</span>
            </div>
          </div>

          <div className={`aero-lobe ${lobesPopped[1] ? 'is-popped' : ''}`}>
            <svg className="aero-lobe-icon" viewBox="0 0 40 40" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M20 4 L31 21 L20 36 L9 21 Z" />
              <path d="M9 21 L31 21 M20 4 L20 36" />
            </svg>
            <div className="aero-lobe-label">
              <span className="aero-lobe-key">LENS</span>
              <span className="aero-lobe-val">.photochromic</span>
            </div>
          </div>

          <div className={`aero-lobe ${lobesPopped[2] ? 'is-popped' : ''}`}>
            <svg className="aero-lobe-icon" viewBox="0 0 40 40" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M5 13 Q12.5 8 20 13 T35 13" />
              <path d="M5 20 Q12.5 15 20 20 T35 20" />
              <path d="M5 27 Q12.5 22 20 27 T35 27" />
            </svg>
            <div className="aero-lobe-label">
              <span className="aero-lobe-key">FIT</span>
              <span className="aero-lobe-val">.wrap</span>
            </div>
          </div>
        </div>

        <div className="aero-marquee-wrap">
          <div ref={marqueeTrackRef} className="aero-marquee-track">
            {[0, 1, 2, 3].map(i => (
              <img key={i} src={assets.marquee} alt="" decoding="async" />
            ))}
          </div>
        </div>
      </section>

      {/* SCENE 4 — OUTRO */}
      <section className={`aero-scene-4 ${scene === 3 ? 'is-active' : ''}`} aria-label="Outro drop call to action">
        <div className="aero-slices" aria-hidden="true">
          {Array.from({ length: 12 }, (_, idx) => (
            <div
              key={idx}
              ref={el => {
                sliceRefs.current[idx] = el;
              }}
              className="aero-slice-bar"
            />
          ))}
        </div>

        <div className="aero-logo-vid-wrap">
          <video src={assets.logoVideo} ref={logoVideoRef} muted loop playsInline preload="metadata" />
        </div>

        <div className="aero-outro-cta">
          <h2 className="aero-outro-title">SEE IT BEFORE IT HAPPENS.</h2>
          <button type="button" className="aero-outro-btn" onClick={openModalFromEvent}>
            PRE-ORDER · $289
          </button>
        </div>
      </section>

      {/* Lens Color Picker */}
      {(scene === 0 || scene === 1) && (
        <div className="aero-lens-picker" role="group" aria-label="Lens colourway">
          <span className="aero-lens-label">LENS</span>
          {AERO_LENSES.map((l, idx) => (
            <button
              key={l.id}
              type="button"
              className={`aero-orb ${lensIdx === idx ? 'is-active' : ''}`}
              aria-label={`${l.name} lens`}
              title={l.name}
              onClick={() => selectLens(idx)}
            >
              <span className="aero-orb-dot" style={{ background: l.color }} />
            </button>
          ))}
        </div>
      )}

      {/* Scroll Next Hint */}
      {scene < 3 && (
        <button type="button" className="aero-scroll-hint" onClick={() => controllerRef.current?.step(1)}>
          <span>SCROLL · NEXT</span>
        </button>
      )}

      {/* Persistent Footer */}
      <footer ref={footerRef} className="aero-footer">
        <span className="aero-foot-item">
          <span>✦</span>
          <span>{formatAeroDate()}</span>
        </span>
        <span className="aero-foot-plus">+</span>
        <span className="aero-foot-item">
          <div className="aero-dashes">
            {[0, 1, 2, 3].map(idx => (
              <button
                key={idx}
                type="button"
                className={`aero-dash-btn ${scene === idx ? 'is-active' : ''}`}
                aria-label={`Scene ${idx + 1}`}
                onClick={() => controllerRef.current?.goTo(idx)}
              />
            ))}
          </div>
          <span>©2026 KYNE AERO.VISION</span>
        </span>
        <span className="aero-foot-plus">+</span>
        <span className="aero-foot-item">
          <span>⌜⌝</span>
          <span>50°05′36.2″N 14°26′51.5″E</span>
        </span>
      </footer>

      {/* Pre-order Modal with Circular clip-path */}
      {modalOpen && (
        <div
          className="aero-modal-backdrop"
          style={{
            clipPath: `circle(150% at ${modalOrigin.x.toFixed(1)}% ${modalOrigin.y.toFixed(1)}%)`
          }}
          role="dialog"
          aria-modal="true"
          aria-label="Pre-order AERO.VISION"
          onClick={e => {
            if (e.target === e.currentTarget) setModalOpen(false);
          }}
        >
          <div className="aero-modal-card">
            <button
              type="button"
              className="aero-modal-close"
              aria-label="Close modal"
              onClick={() => setModalOpen(false)}
            >
              ×
            </button>
            <h3 className="aero-modal-title">AERO.VISION</h3>

            <div className="aero-chip-group">
              <span className="aero-chip-label">LENS</span>
              <div className="aero-chips">
                {AERO_LENSES.map((l, idx) => (
                  <button
                    key={l.id}
                    type="button"
                    className={`aero-chip ${lensIdx === idx ? 'is-active' : ''}`}
                    onClick={() => selectLens(idx)}
                  >
                    {l.name}
                  </button>
                ))}
              </div>
            </div>

            <div className="aero-chip-group">
              <span className="aero-chip-label">FIT</span>
              <div className="aero-chips">
                {AERO_FITS.map((fitName, idx) => (
                  <button
                    key={fitName}
                    type="button"
                    className={`aero-chip ${fitIdx === idx ? 'is-active' : ''}`}
                    onClick={() => setFitIdx(idx)}
                  >
                    {fitName}
                  </button>
                ))}
              </div>
            </div>

            <div className="aero-modal-foot">
              <span className="aero-modal-price">$289</span>
              <button
                type="button"
                className="aero-reserve-btn"
                onClick={() => {
                  setModalOpen(false);
                  showToast(
                    `Reserved AERO.VISION · ${AERO_LENSES[lensIdx].name} · ${AERO_FITS[fitIdx]}`
                  );
                }}
              >
                Reserve pair →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      <div className={`aero-toast ${toastShow ? 'is-show' : ''}`} role="status" aria-live="polite">
        {toastMsg}
      </div>

      {/* Custom Cursor */}
      <div ref={cursorRef} className={`aero-cursor ${recMode ? 'is-rec' : ''}`} aria-hidden="true" />
    </div>
  );
}
