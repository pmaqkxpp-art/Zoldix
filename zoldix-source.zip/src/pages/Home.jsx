import { lazy, Suspense, useEffect, useState } from 'react';
import CircularCarousel from '../carousels/CircularCarousel.jsx';
import OrbitImages from '../carousels/OrbitImages.jsx';
import ErrorBoundary from '../components/ErrorBoundary.jsx';
import Footer from '../components/Footer.jsx';
import { DEFAULT_ASSETS } from '../config/defaults.js';
import { getAsset, loadSiteConfig, subscribeSiteConfig } from '../config/siteConfig.js';
import './home.css';

const LazyFlexCarousel = lazy(() => import('../carousels/FlexCarousel.jsx'));

function EmbeddedExperience({ id, title, route, isLead = false }) {
  return (
    <section
      id={id}
      className={`home-fullbleed-chapter ${isLead ? 'is-lead' : ''}`.trim()}
      aria-label={title}
    >
      <iframe
        src={`#${route}?embed=1`}
        title={title}
        className="home-chapter-iframe"
        loading="eager"
      />
    </section>
  );
}

export default function Home({ pageReady }) {
  const [cfg, setCfg] = useState(() => loadSiteConfig());

  useEffect(() => {
    return subscribeSiteConfig(nextCfg => setCfg(nextCfg));
  }, []);

  const theme = cfg.theme || {};
  const carouselItems = getAsset('home.carousel') || DEFAULT_ASSETS['home.carousel'];
  const flexItems = getAsset('home.flex') || DEFAULT_ASSETS['home.flex'];
  const orbitItems = getAsset('home.orbit') || DEFAULT_ASSETS['home.orbit'];

  return (
    <div
      className={`home-page ${pageReady ? 'is-entered' : ''}`}
      style={{
        '--wrapper-bg': theme.bgColor || '#0d0d10',
        '--wrapper-accent': theme.accentColor || '#ff5a1f'
      }}
    >
      <main className="home-flow">
        {/* 1st (ex-#5): VESTRA — Open full-screen from the start */}
        <EmbeddedExperience
          id="sec-vestra"
          title="VESTRA Outerwear"
          route="/vestra"
          isLead
        />

        {/* 2nd (ex-#2): FlexCarousel — Youthful streetwear fashion strip (صور شبابيه) */}
        <section
          id="sec-flex"
          className="home-backdrop-band"
          aria-label="Youth Streetwear Lookbook Strip"
        >
          <ErrorBoundary label="Youth Lookbook Strip">
            <Suspense fallback={<div className="home-backdrop-loading" />}>
              <LazyFlexCarousel
                items={flexItems}
                preset="liquid"
                intro="rise"
                cardHeight={0.54}
                gap={12}
                squeeze={0.2}
                focusOnClick
                captions
                fit="natural"
                radius={0}
                lensWidth={0.74}
                lensHeight={1.18}
                tilt={62}
                roundness={1}
                bend={0.34}
                reach={0.38}
                curl="twist"
                dispersion={0.45}
                liquid={0}
                followCursor={false}
                autoplay={false}
                interval={4}
                captureWheel={false}
              />
            </Suspense>
          </ErrorBoundary>
        </section>

        {/* 3rd (ex-#6): HINA — Open full-screen from the start */}
        <EmbeddedExperience
          id="sec-hina"
          title="HINA Little Wardrobe"
          route="/hina"
        />

        {/* 4th (ex-#1): CircularCarousel — 3D silhouette cylinder */}
        <section
          id="sec-circular"
          className="home-backdrop-band"
          aria-label="Silhouette Ring"
        >
          <ErrorBoundary label="Silhouette Ring">
            <CircularCarousel
              items={carouselItems}
              preset="cylinder"
              intro="rise"
              cardWidth={240}
              aspectRatio={1}
              speed={14}
              captions={false}
              gap={26}
              tilt={-5}
              curve={1}
              perspective={2500}
              autoplay="drift"
              interval={3}
              direction="left"
              momentum={0.6}
              snap
              pauseOnHover
              focusOnClick
              draggable
              parallax={0.3}
              stretch={0.5}
              fadeColor={theme.bgColor || '#0d0d10'}
              depthFade={0.45}
              innerShade={0.45}
              cornerRadius={14}
            />
          </ErrorBoundary>
        </section>

        {/* 5th (ex-#7): KYNE AERO.VISION — Open full-screen from the start */}
        <EmbeddedExperience
          id="sec-aero"
          title="KYNE AERO.VISION"
          route="/aero"
        />

        {/* 6th (ex-#3): OrbitImages — Atelier archive orbit */}
        <section
          id="sec-orbit"
          className="home-backdrop-band"
          aria-label="Atelier Archive Orbit"
        >
          <ErrorBoundary label="Archive Orbit">
            <OrbitImages
              images={orbitItems}
              shape="ellipse"
              radiusX={380}
              radiusY={86}
              rotation={-8}
              duration={30}
              itemSize={96}
              depth={0.6}
              showPath
              centerContent={<h2 className="home-orbit-center">Moments</h2>}
              radius={160}
              itemRadius={14}
              shadow={0.3}
              hoverScale={1.08}
              hoverSpeed={0.3}
              pathDash={0}
              direction="normal"
              easing="linear"
              fill
              alignToPath={false}
              draggable
              clickToFront
              paused={false}
              intro
            />
          </ErrorBoundary>
        </section>

        {/* 7th (ex-#8): Zestwell — Open full-screen 3D gallery from the start */}
        <EmbeddedExperience
          id="sec-zestwell"
          title="Zestwell Gallery"
          route="/zestwell"
        />
      </main>

      <Footer />
    </div>
  );
}
