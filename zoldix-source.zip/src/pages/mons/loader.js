export const runMonsIntro = ({
  root,
  loaderEl,
  barEl,
  strips,
  sliceEls,
  bandEl,
  modelEl,
  chevLeft,
  chevRight,
  hudEls,
  reducedMotion,
  waitAssetsPromise
}) => {
  const timers = [];
  const addTimer = (fn, ms) => {
    const id = setTimeout(fn, ms);
    timers.push(id);
    return id;
  };

  if (reducedMotion) {
    root.classList.add('done');
    if (loaderEl) loaderEl.style.display = 'none';
    sliceEls.forEach(s => {
      if (s) s.style.display = 'none';
    });
    return () => timers.forEach(clearTimeout);
  }

  let finished = false;
  const startTime = performance.now();

  if (barEl) {
    barEl.style.transition = 'transform 420ms cubic-bezier(.3,.6,.3,1)';
    requestAnimationFrame(() => {
      barEl.style.transform = 'scaleX(0.8)';
    });
  }

  const reveal = () => {
    if (finished) return;
    finished = true;

    if (barEl) {
      barEl.style.transition = 'transform 90ms linear';
      barEl.style.transform = 'scaleX(1)';
    }

    addTimer(() => {
      if (loaderEl) loaderEl.classList.add('is-fading-word');
      strips.forEach(strip => {
        if (!strip) return;
        const idx = Number(strip.dataset.stripIdx || 0);
        const dir = idx % 2 === 0 ? '-104%' : '104%';
        const delay = Math.round(Math.random() * 170);
        strip.style.transition = `transform 260ms cubic-bezier(.7,0,.3,1) ${delay}ms`;
        strip.style.transform = `translateX(${dir})`;
      });
    }, 90);

    addTimer(() => {
      sliceEls.forEach((slice, idx) => {
        if (!slice) return;
        const offset = (idx % 2 === 0 ? -1 : 1) * (40 + idx * 15);
        slice.animate(
          [
            { opacity: 0, transform: `translateX(${offset}px)` },
            { opacity: 1, transform: `translateX(${-offset * 0.25}px)`, offset: 0.6 },
            { opacity: 1, transform: 'translateX(0px)' }
          ],
          {
            duration: 360,
            delay: idx * 30,
            easing: 'steps(5)',
            fill: 'forwards'
          }
        );
      });
    }, 150);

    addTimer(() => {
      root.classList.add('done');
      if (modelEl) {
        modelEl.animate(
          [{ filter: 'brightness(1.9) contrast(.6)' }, { filter: 'brightness(1) contrast(1)' }],
          { duration: 420, easing: 'cubic-bezier(.2,.7,.2,1)', fill: 'forwards' }
        );
      }
    }, 210);

    addTimer(() => {
      if (chevLeft) {
        chevLeft.animate([{ transform: 'translateX(-420px)' }, { transform: 'translateX(0px)' }], {
          duration: 520,
          easing: 'cubic-bezier(.2,.8,.2,1)',
          fill: 'forwards'
        });
      }
      if (chevRight) {
        chevRight.animate([{ transform: 'translateX(420px)' }, { transform: 'translateX(0px)' }], {
          duration: 520,
          delay: 60,
          easing: 'cubic-bezier(.2,.8,.2,1)',
          fill: 'forwards'
        });
      }
    }, 270);

    addTimer(() => {
      hudEls.forEach((el, idx) => {
        if (!el) return;
        const isCardOrHint = el.classList.contains('mons-card') || el.classList.contains('mons-hint');
        const yFrom = el.classList.contains('mons-nav') ? 0 : isCardOrHint ? 14 : 8;
        el.animate(
          [
            { opacity: 0, transform: `translateY(${yFrom}px)` },
            { opacity: 1, transform: 'translateY(0px)' }
          ],
          {
            duration: 900,
            delay: idx * 55,
            easing: 'cubic-bezier(.16,.84,.24,1)',
            fill: 'forwards'
          }
        );
      });
    }, 450);

    addTimer(() => {
      if (bandEl) bandEl.style.opacity = '1';
      sliceEls.forEach(slice => {
        if (slice) slice.style.display = 'none';
      });
    }, 610);

    addTimer(() => {
      if (loaderEl) loaderEl.style.display = 'none';
    }, 790);
  };

  Promise.resolve(waitAssetsPromise).finally(() => {
    const remain = Math.max(0, 420 - (performance.now() - startTime));
    addTimer(reveal, remain);
  });

  addTimer(() => {
    root.classList.add('done');
    if (loaderEl) loaderEl.style.display = 'none';
    sliceEls.forEach(s => {
      if (s) s.style.display = 'none';
    });
  }, 5000);

  return () => {
    timers.forEach(clearTimeout);
  };
};
