export const createTrailBuffer = () => {
  const W = 360;
  const H = 239;
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, W, H);

  let prev = null;
  let energy = 0;

  const stampBlob = (x, y, r) => {
    const grad = ctx.createRadialGradient(x, y, 0, x, y, r);
    grad.addColorStop(0, 'rgba(255,255,255,0.9)');
    grad.addColorStop(0.6, 'rgba(255,255,255,0.55)');
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  };

  const pushFramePoint = (fx, fy) => {
    const x = (fx / 1440) * W;
    const y = ((fy + 28) / 956) * H;

    if (!prev) {
      prev = { x, y };
      stampBlob(x, y, 24);
      energy = 1;
      return;
    }

    const dx = x - prev.x;
    const dy = y - prev.y;
    const d = Math.hypot(dx, dy);

    if (d > 70) {
      prev = { x, y };
      stampBlob(x, y, 24);
      energy = 1;
      return;
    }

    const r = 24 + 10 * Math.min(1, d / 18);
    const step = r * 0.25;
    const count = Math.max(1, Math.ceil(d / step));
    for (let i = 1; i <= count; i += 1) {
      const t = i / count;
      stampBlob(prev.x + dx * t, prev.y + dy * t, r);
    }

    prev = { x, y };
    energy = 1;
  };

  const resetPointer = () => {
    prev = null;
  };

  const decay = dt => {
    if (energy <= 0.004) return false;
    const decayAlpha = 1 - Math.pow(0.05, dt / 850);
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = `rgba(0,0,0,${Math.min(1, decayAlpha)})`;
    ctx.fillRect(0, 0, W, H);
    energy *= Math.pow(0.05, dt / 900);
    if (energy <= 0.004) {
      energy = 0;
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, W, H);
      return false;
    }
    return true;
  };

  const clear = () => {
    energy = 0;
    prev = null;
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, W, H);
  };

  return {
    canvas,
    pushFramePoint,
    resetPointer,
    decay,
    clear,
    isActive: () => energy > 0.004
  };
};
