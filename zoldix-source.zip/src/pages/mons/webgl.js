const VERTEX_SHADER = `
attribute vec2 aPos;
varying vec2 vUv;
void main() {
  vUv = aPos * 0.5 + 0.5;
  vUv.y = 1.0 - vUv.y;
  gl_Position = vec4(aPos, 0.0, 1.0);
}
`;

const FRAGMENT_SHADER = `
precision highp float;
varying vec2 vUv;
uniform sampler2D uTexA;
uniform sampler2D uTexB;
uniform sampler2D uTrail;
uniform float uTime;
uniform vec2 uTexel;

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(hash(i + vec2(0.0, 0.0)), hash(i + vec2(1.0, 0.0)), u.x),
    mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
    u.y
  );
}

void main() {
  vec4 texA = texture2D(uTexA, vUv);
  vec4 texB = texture2D(uTexB, vUv);
  float trRaw = texture2D(uTrail, vUv).r;

  float nz = vnoise(vUv * vec2(14.0, 9.3) + uTime * vec2(0.35, -0.2)) * 0.55
           + vnoise(vUv * vec2(34.0, 22.0) - uTime * 0.5) * 0.45;
  float tr = trRaw + (nz - 0.5) * 0.16;

  float m = smoothstep(0.40, 0.47, tr);
  vec3 rgb = mix(texA.rgb, texB.rgb, m);

  float dx = texture2D(uTrail, vUv + vec2(uTexel.x * 1.6, 0.0)).r - texture2D(uTrail, vUv - vec2(uTexel.x * 1.6, 0.0)).r;
  float dy = texture2D(uTrail, vUv + vec2(0.0, uTexel.y * 1.6)).r - texture2D(uTrail, vUv - vec2(0.0, uTexel.y * 1.6)).r;
  float grad = length(vec2(dx, dy));
  float edge = smoothstep(0.012, 0.07, grad);

  float glow = edge * (1.0 - smoothstep(0.0, 0.2, abs(tr - 0.43)));
  float line = edge * smoothstep(0.405, 0.43, tr) * (1.0 - smoothstep(0.43, 0.455, tr));

  vec3 cherry = vec3(0.878, 0.192, 0.247);
  rgb = mix(rgb, cherry, glow * 0.78);
  rgb = mix(rgb, vec3(1.0, 0.86, 0.87), line * 0.9);
  rgb += cherry * glow * glow * 0.25;

  float a = max(texA.a, texB.a);
  gl_FragColor = vec4(rgb * a, a);
}
`;

const loadTexture = (gl, src, unit) =>
  new Promise((resolve, reject) => {
    const tex = gl.createTexture();
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.decoding = 'async';
    img.onload = () => {
      gl.activeTexture(gl.TEXTURE0 + unit);
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
      resolve(tex);
    };
    img.onerror = reject;
    img.src = src;
  });

export const createMonsWebGL = async (canvas, srcA, srcB, trailCanvas) => {
  const gl = canvas.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: true });
  if (!gl) return null;

  const compile = (type, source) => {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      gl.deleteShader(shader);
      return null;
    }
    return shader;
  };

  const vs = compile(gl.VERTEX_SHADER, VERTEX_SHADER);
  const fs = compile(gl.FRAGMENT_SHADER, FRAGMENT_SHADER);
  if (!vs || !fs) return null;

  const program = gl.createProgram();
  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    return null;
  }

  gl.useProgram(program);
  const buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(program, 'aPos');
  gl.enableVertexAttribArray(loc);
  gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

  let texA = null;
  let texB = null;
  try {
    [texA, texB] = await Promise.all([loadTexture(gl, srcA, 0), loadTexture(gl, srcB, 1)]);
  } catch {
    return null;
  }

  const trailTex = gl.createTexture();
  gl.activeTexture(gl.TEXTURE2);
  gl.bindTexture(gl.TEXTURE_2D, trailTex);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, trailCanvas);

  gl.uniform1i(gl.getUniformLocation(program, 'uTexA'), 0);
  gl.uniform1i(gl.getUniformLocation(program, 'uTexB'), 1);
  gl.uniform1i(gl.getUniformLocation(program, 'uTrail'), 2);
  const uTimeLoc = gl.getUniformLocation(program, 'uTime');
  const uTexelLoc = gl.getUniformLocation(program, 'uTexel');

  const setSize = frameScale => {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(1, Math.min(2048, Math.round(1440 * frameScale * dpr)));
    const h = Math.max(1, Math.round((w * 956) / 1440));
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }
    gl.viewport(0, 0, canvas.width, canvas.height);
  };

  const render = (timeSec, uploadTrail = true) => {
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform1f(uTimeLoc, timeSec);
    gl.uniform2f(uTexelLoc, 1 / trailCanvas.width, 1 / trailCanvas.height);

    if (uploadTrail) {
      gl.activeTexture(gl.TEXTURE2);
      gl.bindTexture(gl.TEXTURE_2D, trailTex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, trailCanvas);
    }

    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  };

  const destroy = () => {
    try {
      gl.deleteTexture(texA);
      gl.deleteTexture(texB);
      gl.deleteTexture(trailTex);
      gl.deleteBuffer(buffer);
      gl.deleteProgram(program);
      gl.deleteShader(vs);
      gl.deleteShader(fs);
      gl.getExtension('WEBGL_lose_context')?.loseContext();
    } catch {}
  };

  return { setSize, render, destroy };
};
