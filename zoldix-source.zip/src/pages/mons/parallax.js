export const createMonsParallax = elements => {
  let tx = 0;
  let ty = 0;
  let cx = 0;
  let cy = 0;
  let raf = 0;
  let lastTime = 0;
  let destroyed = false;
  let kUnit = 1;

  const applyTranslations = () => {
    const { chevrons = [], tags, deco, wordmark, glasses = [], texture, card, hint } = elements;
    chevrons.forEach(el => {
      if (el) el.style.translate = `${(-cx * 24).toFixed(2)}px ${(-cy * 24 * 0.7).toFixed(2)}px`;
    });
    if (tags) tags.style.translate = `${(-cx * 20).toFixed(2)}px ${(-cy * 20 * 0.7).toFixed(2)}px`;
    if (deco) deco.style.translate = `${(-cx * 18).toFixed(2)}px ${(-cy * 18 * 0.7).toFixed(2)}px`;
    if (wordmark) wordmark.style.translate = `${(-cx * 14).toFixed(2)}px ${(-cy * 14 * 0.7).toFixed(2)}px`;
    glasses.forEach(el => {
      if (el) el.style.translate = `${(-cx * 9).toFixed(2)}px ${(-cy * 9 * 0.7).toFixed(2)}px`;
    });
    if (texture) {
      texture.style.translate = `${(-cx * 8 * kUnit).toFixed(2)}px ${(-cy * 8 * 0.7 * kUnit).toFixed(2)}px`;
    }
    if (card) card.style.translate = `${(-cx * 7 * kUnit).toFixed(2)}px ${(-cy * 7 * 0.7 * kUnit).toFixed(2)}px`;
    if (hint) hint.style.translate = `${(-cx * 7 * kUnit).toFixed(2)}px ${(-cy * 7 * 0.7 * kUnit).toFixed(2)}px`;
  };

  const step = now => {
    raf = 0;
    if (destroyed) return;
    const dt = lastTime ? Math.min(50, now - lastTime) : 16;
    lastTime = now;
    const alpha = 1 - Math.exp(-dt / 220);
    cx += (tx - cx) * alpha;
    cy += (ty - cy) * alpha;
    applyTranslations();
    if (Math.abs(tx - cx) > 0.001 || Math.abs(ty - cy) > 0.001) {
      raf = requestAnimationFrame(step);
    } else {
      cx = tx;
      cy = ty;
      applyTranslations();
      lastTime = 0;
    }
  };

  const wake = () => {
    if (!raf && !destroyed) {
      lastTime = 0;
      raf = requestAnimationFrame(step);
    }
  };

  const setTarget = (nx, ny) => {
    tx = Math.max(-1, Math.min(1, nx));
    ty = Math.max(-1, Math.min(1, ny));
    wake();
  };

  const setUnit = nextK => {
    kUnit = nextK || 1;
  };

  const reset = () => {
    tx = 0;
    ty = 0;
    wake();
  };

  const destroy = () => {
    destroyed = true;
    cancelAnimationFrame(raf);
  };

  return { setTarget, setUnit, reset, destroy };
};
