import { DEFAULT_ASSETS } from '../../config/defaults.js';
import { getAsset } from '../../config/siteConfig.js';

export const getMonsMedia = () => ({
  layerA: getAsset('mons.layerA'),
  layerB: getAsset('mons.layerB'),
  fallbackA: DEFAULT_ASSETS['mons.layerA'],
  fallbackB: DEFAULT_ASSETS['mons.layerB'],
  alt: 'Model in a hooded rain shell, smoked visor and face mask, with a black sling bag'
});

export const KIT_PIECES = [
  {
    name: 'RAIN VISOR',
    specs: ['Smoked anti-fog lens', 'Wraps under the hood', 'Beads and sheds rain'],
    test: (x, y) => x >= 592 && x <= 818 && y >= 200 && y <= 300
  },
  {
    name: 'FILTER MASK',
    specs: ['Washable mesh shell', 'Swap-in filter insert', 'Magnetic quick release'],
    test: (x, y) => x >= 624 && x <= 792 && y >= 300 && y <= 420
  },
  {
    name: 'STORM HOOD',
    specs: ['Three-point adjust', 'Wired brim holds shape', 'Glove-friendly cord locks'],
    test: (x, y) => ((x - 705) / 150) ** 2 + ((y - 235) / 180) ** 2 <= 1
  },
  {
    name: 'DRY SLING',
    specs: ['Welded roll-top body', 'Four litre volume', 'One-hand buckle release'],
    test: (x, y) =>
      (x >= 585 && x <= 915 && y >= 590 && y <= 900) || (x >= 505 && x <= 640 && y >= 470 && y <= 640)
  },
  {
    name: 'TAPED SHELL',
    specs: ['Three-layer membrane', 'Fully taped seams', 'Pit zips for airflow'],
    test: (x, y) =>
      y > 420 && x >= 270 && x <= 1125 && ((x - 697) / 440) ** 2 + ((y - 930) / 520) ** 2 <= 1
  }
];

export const hitTestKit = (fx, fy) => {
  for (let i = 0; i < KIT_PIECES.length; i += 1) {
    if (KIT_PIECES[i].test(fx, fy)) return KIT_PIECES[i];
  }
  return null;
};

let cachedContourUri = null;

const hash2D = (ix, iy) => {
  const n = Math.sin(ix * 127.1 + iy * 311.7) * 43758.5453123;
  return n - Math.floor(n);
};

const valueNoise = (x, y, scale) => {
  const sx = x / scale;
  const sy = y / scale;
  const ix = Math.floor(sx);
  const iy = Math.floor(sy);
  const fx = sx - ix;
  const fy = sy - iy;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const a = hash2D(ix, iy);
  const b = hash2D(ix + 1, iy);
  const c = hash2D(ix, iy + 1);
  const d = hash2D(ix + 1, iy + 1);
  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
};

const sampleField = (x, y) =>
  valueNoise(x, y, 260) * 0.65 + valueNoise(x, y, 120) * 0.25 + valueNoise(x, y, 55) * 0.1;

export const getContourDataUri = () => {
  if (cachedContourUri) return cachedContourUri;
  const W = 1440;
  const H = 900;
  const STEP = 12;
  const cols = Math.floor(W / STEP);
  const rows = Math.floor(H / STEP);
  const grid = new Float32Array((cols + 1) * (rows + 1));

  for (let r = 0; r <= rows; r += 1) {
    for (let c = 0; c <= cols; c += 1) {
      grid[r * (cols + 1) + c] = sampleField(c * STEP, r * STEP);
    }
  }

  const buckets = [[], [], [], []];
  const opacities = [0.18, 0.36, 0.55, 0.75];

  const interp = (a, b, va, vb, iso) => {
    const den = vb - va;
    const t = Math.abs(den) < 1e-5 ? 0.5 : (iso - va) / den;
    return a + (b - a) * t;
  };

  for (let idx = 0, iso = 0.3; iso <= 0.801; iso += 0.03, idx += 1) {
    for (let r = 0; r < rows; r += 1) {
      for (let c = 0; c < cols; c += 1) {
        const i0 = r * (cols + 1) + c;
        const v0 = grid[i0];
        const v1 = grid[i0 + 1];
        const v2 = grid[i0 + cols + 2];
        const v3 = grid[i0 + cols + 1];

        let mask = 0;
        if (v0 >= iso) mask |= 8;
        if (v1 >= iso) mask |= 4;
        if (v2 >= iso) mask |= 2;
        if (v3 >= iso) mask |= 1;
        if (mask === 0 || mask === 15) continue;

        const x0 = c * STEP;
        const y0 = r * STEP;
        const x1 = x0 + STEP;
        const y1 = y0 + STEP;

        const dx = (x0 + STEP * 0.5) / W * 2 - 1;
        const dy = (y0 + STEP * 0.5) / H * 2 - 1;
        const rawW = (Math.max(Math.abs(dx) * 1.05, Math.abs(dy) * 0.6) - 0.35) / 0.5;
        const edgeW = Math.max(0, Math.min(1, rawW));
        if (edgeW <= 0.05) continue;

        const top = [interp(x0, x1, v0, v1, iso), y0];
        const right = [x1, interp(y0, y1, v1, v2, iso)];
        const bottom = [interp(x0, x1, v3, v2, iso), y1];
        const left = [x0, interp(y0, y1, v0, v3, iso)];

        const segs = [];
        switch (mask) {
          case 1:
          case 14:
            segs.push([left, bottom]);
            break;
          case 2:
          case 13:
            segs.push([bottom, right]);
            break;
          case 3:
          case 12:
            segs.push([left, right]);
            break;
          case 4:
          case 11:
            segs.push([top, right]);
            break;
          case 5:
            segs.push([left, top], [bottom, right]);
            break;
          case 6:
          case 9:
            segs.push([top, bottom]);
            break;
          case 7:
          case 8:
            segs.push([left, top]);
            break;
          case 10:
            segs.push([left, bottom], [top, right]);
            break;
          default:
            break;
        }

        const bucketIdx = Math.min(3, Math.floor(edgeW * 4));
        for (let s = 0; s < segs.length; s += 1) {
          const [p, q] = segs[s];
          buckets[bucketIdx].push(`M${p[0].toFixed(1)},${p[1].toFixed(1)}L${q[0].toFixed(1)},${q[1].toFixed(1)}`);
        }
      }
    }
  }

  const groups = buckets
    .map(
      (paths, i) =>
        `<g stroke="#9AA0A6" stroke-width="1" stroke-linecap="round" stroke-opacity="${opacities[i]}" fill="none"><path d="${paths.join('')}"/></g>`
    )
    .join('');

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 900" preserveAspectRatio="none">${groups}</svg>`;
  cachedContourUri = `data:image/svg+xml;base64,${btoa(svg)}`;
  return cachedContourUri;
};
