import { getDomCropStyle } from './data.js';

export default function ZestwellBagDrawer({
  open,
  items,
  sheetUrl,
  isSmall,
  onClose,
  onUpdateQty,
  onRemoveItem
}) {
  const subtotal = items.reduce((sum, item) => sum + item.price * item.qty, 0);
  const thumbW = isSmall ? 60 : 66;
  const thumbH = thumbW * (4 / 3);

  return (
    <>
      {open && <div className="zw-drawer-scrim" onClick={onClose} aria-hidden="true" />}
      <aside
        className={`zw-drawer ${open ? 'is-open' : ''}`}
        role="dialog"
        aria-modal="true"
        aria-label="Your bag"
      >
        <div className="zw-drawer-head">
          <h2>YOUR BAG</h2>
          <button type="button" className="zw-drawer-close" aria-label="Close bag" onClick={onClose}>
            ×
          </button>
        </div>

        <div className="zw-drawer-list">
          {items.length === 0 ? (
            <div className="zw-drawer-empty">YOUR BAG IS EMPTY</div>
          ) : (
            items.map(item => (
              <div key={item.id} className={`zw-bag-item ${item.entering ? 'is-entering' : ''}`}>
                <div
                  className="zw-bag-thumb"
                  style={getDomCropStyle(item.printIndex, thumbW, thumbH, sheetUrl)}
                />
                <div className="zw-bag-meta">
                  <div className="zw-bag-title">{item.title}</div>
                  <div className="zw-bag-artist">{item.artist}</div>
                  <div className="zw-bag-spec">
                    {item.size} · {item.frame}
                  </div>
                  <div className="zw-bag-controls">
                    <div className="zw-bag-qty">
                      <button
                        type="button"
                        aria-label="Decrease bag quantity"
                        onClick={() => onUpdateQty(item.id, -1)}
                      >
                        −
                      </button>
                      <span>{item.qty}</span>
                      <button
                        type="button"
                        aria-label="Increase bag quantity"
                        onClick={() => onUpdateQty(item.id, 1)}
                      >
                        +
                      </button>
                    </div>
                    <button
                      type="button"
                      className="zw-bag-trash"
                      aria-label="Remove item"
                      onClick={() => onRemoveItem(item.id)}
                    >
                      <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.3">
                        <path d="M2.5 4.5 H13.5 M6 2.5 H10 M4.5 4.5 V13.5 H11.5 V4.5" />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="zw-drawer-foot">
          <div className="zw-subtotal-row">
            <span>Subtotal</span>
            <span className="zw-subtotal-val">$ {subtotal}.00</span>
          </div>
          <button type="button" className="zw-checkout-btn" onClick={onClose}>
            CHECKOUT →
          </button>
        </div>
      </aside>
    </>
  );
}
