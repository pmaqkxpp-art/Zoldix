import { getAsset, getDefaultAsset, loadSiteConfig } from '../../config/siteConfig.js';

export const SHEET_W = 1744;
export const SHEET_H = 2336;

export const COL_RANGES = [
  [0, 575],
  [585, 1158],
  [1168, 1743]
];

export const ROW_RANGES = [
  [0, 769],
  [779, 1545],
  [1555, 2335]
];

export const DESCRIPTION_SUFFIX =
  ', painted in flat gouache tones. Printed on archival paper with a soft matte finish.';

export const getZestwellSheetUrl = () =>
  getAsset('zestwell.sheet') || getDefaultAsset('zestwell.sheet');

export const getPrintCrop = index => {
  const i = ((index % 9) + 9) % 9;
  const col = COL_RANGES[i % 3];
  const row = ROW_RANGES[Math.floor(i / 3)];
  return {
    x: col[0] + 6,
    y: row[0] + 6,
    w: col[1] - col[0] - 12,
    h: row[1] - row[0] - 12
  };
};

export const getDomCropStyle = (index, boxW, boxH, sheetUrl) => {
  const crop = getPrintCrop(index);
  const sx = boxW / crop.w;
  const sy = boxH / crop.h;
  return {
    backgroundImage: `url("${sheetUrl}")`,
    backgroundRepeat: 'no-repeat',
    backgroundSize: `${(SHEET_W * sx).toFixed(2)}px ${(SHEET_H * sy).toFixed(2)}px`,
    backgroundPosition: `${(-crop.x * sx).toFixed(2)}px ${(-crop.y * sy).toFixed(2)}px`
  };
};

export const getZestwellPrints = () => {
  const cfg = loadSiteConfig();
  const list = cfg.products?.zestwell || [];
  return list.map((p, idx) => ({
    ...p,
    index: idx,
    fullDescription: `${p.descriptionStart || ''}${DESCRIPTION_SUFFIX}`
  }));
};

export const ZESTWELL_OPTIONS = {
  papers: ['Art Paper', 'Fine Art Paper', 'Recycled Paper'],
  sizes: [
    '11.7 × 16.5" (A3)',
    '16.5 × 23.4" (A2)',
    '23.4 × 33.1" (A1)',
    '33.1 × 46.8" (A0)'
  ],
  signatures: ['Unsigned', 'Signed and Numbered'],
  frames: ['Unframed', 'Classic Frame', 'Framed Canvas']
};

export const ZESTWELL_ACCORDIONS = [
  {
    key: 'paper',
    title: 'Paper & Sizes',
    body: 'Art Paper is a smooth 200 gsm matte stock. Fine Art Paper is a 310 gsm cotton rag with a soft texture. Recycled Paper is 100% post-consumer fibre.'
  },
  {
    key: 'delivery',
    title: 'Delivery Info',
    body: 'Prints are made to order and ship rolled in a tube within 3–5 working days. Framed pieces ship flat within 7–10 working days.'
  },
  {
    key: 'returns',
    title: 'Returns Policy',
    body: 'Unframed prints can be returned within 30 days in their original tube. Signed editions are final sale.'
  }
];

export const SMALL_SCREEN_QUERY =
  '(max-width: 819px), ((orientation: portrait) and (max-width: 1100px)), ((orientation: landscape) and (max-height: 500px))';
