import * as THREE from 'three';
import {
  PH,
  PW,
  PY,
  RING_STEP,
  R_INNER,
  R_OUTER,
  WALL_H,
  applyPoseToCamera,
  easeOutExpo,
  getFocusPose,
  getWalkOffset,
  getWalkPose,
  interpolateFocusPose,
  shortestAngleAround
} from './camera.js';
import { SHEET_H, SHEET_W, getPrintCrop } from './data.js';

const createGradientTexture = (w, h, drawFn) => {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  drawFn(ctx, w, h);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
};

const drawLabelCanvas = (artist, title, year) => {
  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 260;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, 640, 260);
  ctx.fillStyle = '#3A3550';
  ctx.font = '500 58px "Newsreader", Georgia, serif';
  ctx.fillText(artist, 30, 82);
  ctx.font = 'italic 400 54px "Newsreader", Georgia, serif';
  ctx.fillText(title, 30, 150);
  ctx.globalAlpha = 0.7;
  ctx.font = '400 30px "DM Mono", ui-monospace, monospace';
  ctx.fillText(`${year} · PRINT`, 30, 215);
  ctx.globalAlpha = 1;
  return canvas;
};

export const createZestwellRoom = ({
  container,
  sheetUrl,
  prints,
  isPortraitSmall,
  reducedMotion,
  onReady,
  onWebGLFail,
  onHoverPrint,
  onClickPrint,
  onStepBack
}) => {
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  } catch {
    onWebGLFail?.();
    return null;
  }

  const disposables = {
    geometries: [],
    materials: [],
    textures: [],
    labelEntries: []
  };

  const trackGeo = g => {
    disposables.geometries.push(g);
    return g;
  };
  const trackMat = m => {
    disposables.materials.push(m);
    return m;
  };
  const trackTex = t => {
    disposables.textures.push(t);
    return t;
  };

  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.NoToneMapping;
  renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
  container.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#FFF9EC');
  scene.fog = new THREE.Fog('#FFF9EC', 10, 46);

  const getFov = (w, h) => (w >= h ? 56 : 70);
  const cw = container.clientWidth || window.innerWidth;
  const ch = container.clientHeight || window.innerHeight;
  const camera = new THREE.PerspectiveCamera(getFov(cw, ch), cw / Math.max(1, ch), 0.05, 100);

  scene.add(new THREE.HemisphereLight(0xfffdf6, 0xe9cfa6, 1.55));
  scene.add(new THREE.AmbientLight(0xfff6e6, 0.55));

  // Outer wall
  const outerWallTex = trackTex(
    createGradientTexture(4, 256, (ctx, w, h) => {
      const grad = ctx.createLinearGradient(0, 0, 0, h);
      grad.addColorStop(0, '#F5EBD8');
      grad.addColorStop(0.2, '#FBF3E3');
      grad.addColorStop(0.6, '#FBF3E3');
      grad.addColorStop(0.86, '#F8EDD9');
      grad.addColorStop(1, '#EFDFC4');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
    })
  );
  const outerWall = new THREE.Mesh(
    trackGeo(new THREE.CylinderGeometry(R_OUTER, R_OUTER, WALL_H, 160, 1, true)),
    trackMat(new THREE.MeshBasicMaterial({ map: outerWallTex, side: THREE.BackSide }))
  );
  outerWall.position.y = WALL_H / 2;
  scene.add(outerWall);

  // Inner pillar
  const innerWallTex = trackTex(
    createGradientTexture(4, 256, (ctx, w, h) => {
      const grad = ctx.createLinearGradient(0, 0, 0, h);
      grad.addColorStop(0, '#F7EEDD');
      grad.addColorStop(0.3, '#FFFAF0');
      grad.addColorStop(0.8, '#FDF5E6');
      grad.addColorStop(1, '#F1E1C6');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
    })
  );
  const innerWall = new THREE.Mesh(
    trackGeo(new THREE.CylinderGeometry(R_INNER, R_INNER, WALL_H, 120, 1, true)),
    trackMat(new THREE.MeshBasicMaterial({ map: innerWallTex, side: THREE.FrontSide }))
  );
  innerWall.position.y = WALL_H / 2;
  scene.add(innerWall);

  // Floor
  const floorTex = trackTex(
    createGradientTexture(1024, 1024, (ctx, w) => {
      const half = w / 2;
      const rInPx = half * (R_INNER / R_OUTER);
      const grad = ctx.createRadialGradient(half, half, rInPx, half, half, half);
      grad.addColorStop(0, '#EDD6B0');
      grad.addColorStop(0.55, '#F3E1C3');
      grad.addColorStop(1, '#EFDAB8');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, w);
    })
  );
  const floorMesh = new THREE.Mesh(
    trackGeo(new THREE.CircleGeometry(R_OUTER, 160)),
    trackMat(new THREE.MeshBasicMaterial({ map: floorTex }))
  );
  floorMesh.rotation.x = -Math.PI / 2;
  scene.add(floorMesh);

  // Ceiling
  const ceilingMesh = new THREE.Mesh(
    trackGeo(new THREE.CircleGeometry(R_OUTER, 160)),
    trackMat(new THREE.MeshBasicMaterial({ color: '#FAF1E0', side: THREE.BackSide }))
  );
  ceilingMesh.rotation.x = -Math.PI / 2;
  ceilingMesh.position.y = WALL_H;
  scene.add(ceilingMesh);

  // Shared print geometries & gradient textures
  const haloTex = trackTex(
    createGradientTexture(256, 256, (ctx, w) => {
      const half = w / 2;
      const grad = ctx.createRadialGradient(half, half, half * 0.35, half, half, half);
      grad.addColorStop(0, 'rgba(255,255,255,0.95)');
      grad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, w);
    })
  );
  const shadowTex = trackTex(
    createGradientTexture(256, 256, (ctx, w) => {
      const half = w / 2;
      const grad = ctx.createRadialGradient(half, half, half * 0.25, half, half, half);
      grad.addColorStop(0, 'rgba(120,90,50,0.28)');
      grad.addColorStop(1, 'rgba(120,90,50,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, w);
    })
  );

  const haloGeo = trackGeo(new THREE.PlaneGeometry(2.1 * PW, 1.75 * PH));
  const haloMat = trackMat(
    new THREE.MeshBasicMaterial({ map: haloTex, transparent: true, depthWrite: false, fog: true })
  );
  const shadowGeo = trackGeo(new THREE.PlaneGeometry(1.25 * PW, 1.18 * PH));
  const shadowMat = trackMat(
    new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false })
  );
  const frameGeo = trackGeo(new THREE.BoxGeometry(PW + 0.07, PH + 0.07, 0.06));
  const frameMat = trackMat(new THREE.MeshBasicMaterial({ color: '#D3AA72' }));
  const printGeo = trackGeo(new THREE.PlaneGeometry(PW, PH));
  const labelGeo = trackGeo(new THREE.PlaneGeometry(0.92, (0.92 * 260) / 640));

  const maxAniso = renderer.capabilities.getMaxAnisotropy();

  // Create cropped textures per 9 prints + 9 label textures
  const baseImg = new Image();
  baseImg.crossOrigin = 'anonymous';
  const baseTex = trackTex(new THREE.Texture());
  baseTex.colorSpace = THREE.SRGBColorSpace;

  const printMaterials = [];
  const labelTextures = [];

  for (let pIdx = 0; pIdx < 9; pIdx += 1) {
    const crop = getPrintCrop(pIdx);
    const cropTex = trackTex(baseTex.clone());
    cropTex.repeat.set(crop.w / SHEET_W, crop.h / SHEET_H);
    cropTex.offset.set(crop.x / SHEET_W, 1 - (crop.y + crop.h) / SHEET_H);
    cropTex.colorSpace = THREE.SRGBColorSpace;
    cropTex.anisotropy = maxAniso;
    cropTex.needsUpdate = true;
    printMaterials.push(trackMat(new THREE.MeshBasicMaterial({ map: cropTex })));

    const pr = prints[pIdx] || { artist: '', title: '', year: '2024' };
    const lblCanvas = drawLabelCanvas(pr.artist, pr.title, pr.year);
    const lblTex = trackTex(new THREE.CanvasTexture(lblCanvas));
    lblTex.colorSpace = THREE.SRGBColorSpace;
    lblTex.anisotropy = maxAniso;
    labelTextures.push(lblTex);
    disposables.labelEntries.push({ canvas: lblCanvas, tex: lblTex, print: pr });
  }

  const labelMats = labelTextures.map(t =>
    trackMat(new THREE.MeshBasicMaterial({ map: t, transparent: true }))
  );

  const printMeshes = [];
  const outerEntries = [];

  const addPrintGroup = (wall, angle, printIdx) => {
    const group = new THREE.Group();
    const radius = wall === 'outer' ? 17.98 : 12.22;
    const gx = radius * Math.cos(angle);
    const gz = radius * Math.sin(angle);
    group.position.set(gx, 0, gz);
    if (wall === 'outer') {
      group.lookAt(0, 0, 0);
    } else {
      group.lookAt(gx * 2, 0, gz * 2);
    }

    const halo = new THREE.Mesh(haloGeo, haloMat);
    halo.position.set(0, PY + 0.05, 0.005);
    group.add(halo);

    const shadow = new THREE.Mesh(shadowGeo, shadowMat);
    shadow.position.set(0.05, PY - 0.06, 0.01);
    group.add(shadow);

    const frame = new THREE.Mesh(frameGeo, frameMat);
    frame.position.set(0, PY, 0.045);
    group.add(frame);

    const plane = new THREE.Mesh(printGeo, printMaterials[printIdx]);
    plane.position.set(0, PY, 0.077);
    plane.userData = { printIdx, angle, wall, plane };
    group.add(plane);
    printMeshes.push(plane);
    if (wall === 'outer') outerEntries.push(plane.userData);

    const lbl = new THREE.Mesh(labelGeo, labelMats[printIdx]);
    lbl.position.set(-PW / 2 + 0.46, PY - PH / 2 - 0.42, 0.02);
    group.add(lbl);

    scene.add(group);
  };

  for (let s = 0; s < 36; s += 1) {
    addPrintGroup('outer', (s * 2 * Math.PI) / 36, s % 9);
  }
  for (let k = 0; k < 24; k += 1) {
    addPrintGroup('inner', ((k + 0.5) * 2 * Math.PI) / 24, (k + 4) % 9);
  }

  // Camera & Animation state
  let smallPortrait = isPortraitSmall();
  let D = getWalkOffset(smallPortrait);
  let targetTh = D;
  const walkBase = getWalkPose(D, smallPortrait);
  let curPose = { ...walkBase };
  let introAnim = null;
  let glideAnim = null;
  let focusedItem = null;
  let hoveredMesh = null;
  let alive = true;
  let readyFired = false;

  const updateCameraImmediate = () => {
    applyPoseToCamera(camera, curPose);
  };
  updateCameraImmediate();

  const trySignalReady = () => {
    if (readyFired) return;
    readyFired = true;
    onReady?.();
  };

  baseImg.onload = () => {
    if (!alive) return;
    baseTex.image = baseImg;
    baseTex.needsUpdate = true;
    printMaterials.forEach(mat => {
      if (mat.map) {
        mat.map.image = baseImg;
        mat.map.needsUpdate = true;
      }
    });
    renderer.render(scene, camera);
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(() => {
        if (!alive) return;
        disposables.labelEntries.forEach(entry => {
          const ctx = entry.canvas.getContext('2d');
          ctx.clearRect(0, 0, 640, 260);
          ctx.fillStyle = '#3A3550';
          ctx.font = '500 58px "Newsreader", Georgia, serif';
          ctx.fillText(entry.print.artist, 30, 82);
          ctx.font = 'italic 400 54px "Newsreader", Georgia, serif';
          ctx.fillText(entry.print.title, 30, 150);
          ctx.globalAlpha = 0.7;
          ctx.font = '400 30px "DM Mono", ui-monospace, monospace';
          ctx.fillText(`${entry.print.year} · PRINT`, 30, 215);
          ctx.globalAlpha = 1;
          entry.tex.needsUpdate = true;
        });
        trySignalReady();
      });
    } else {
      trySignalReady();
    }
  };
  baseImg.onerror = () => trySignalReady();
  baseImg.src = sheetUrl;

  const failsafeReady = setTimeout(trySignalReady, 4000);

  const raycaster = new THREE.Raycaster();
  const pointerNDC = new THREE.Vector2();

  const pickPrintAt = (clientX, clientY) => {
    const rect = renderer.domElement.getBoundingClientRect();
    pointerNDC.x = ((clientX - rect.left) / rect.width) * 2 - 1;
    pointerNDC.y = -((clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointerNDC, camera);
    const hits = raycaster.intersectObjects(printMeshes, false);
    return hits.length > 0 ? hits[0].object : null;
  };

  const getPrintScreenRect = mesh => {
    if (!mesh) return { left: window.innerWidth * 0.2, top: window.innerHeight * 0.2, width: 320, height: 420 };
    const halfW = PW / 2;
    const halfH = PH / 2;
    const corners = [
      new THREE.Vector3(-halfW, -halfH, 0),
      new THREE.Vector3(halfW, -halfH, 0),
      new THREE.Vector3(-halfW, halfH, 0),
      new THREE.Vector3(halfW, halfH, 0)
    ];
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    corners.forEach(c => {
      const p = c.clone().applyMatrix4(mesh.matrixWorld).project(camera);
      const sx = (p.x * 0.5 + 0.5) * vw;
      const sy = (-p.y * 0.5 + 0.5) * vh;
      minX = Math.min(minX, sx);
      maxX = Math.max(maxX, sx);
      minY = Math.min(minY, sy);
      maxY = Math.max(maxY, sy);
    });
    return {
      left: minX,
      top: minY,
      width: Math.max(40, maxX - minX),
      height: Math.max(50, maxY - minY)
    };
  };

  const focusMesh = mesh => {
    const data = mesh.userData;
    const nextAngle = shortestAngleAround(data.angle, curPose.th);
    const dest = getFocusPose(nextAngle, data.wall, smallPortrait);
    focusedItem = { mesh, ...data, targetAngle: nextAngle };
    onHoverPrint?.(false, getPrintScreenRect(mesh));

    if (reducedMotion()) {
      curPose = { ...dest };
      targetTh = dest.th;
      glideAnim = null;
      updateCameraImmediate();
      return;
    }

    glideAnim = {
      from: { ...curPose },
      to: dest,
      start: performance.now(),
      duration: 950
    };
  };

  const stepBack = () => {
    if (!focusedItem) return;
    focusedItem = null;
    targetTh = curPose.th + D;
    const dest = getWalkPose(targetTh, smallPortrait);
    onStepBack?.();

    if (reducedMotion()) {
      curPose = { ...dest };
      glideAnim = null;
      updateCameraImmediate();
      return;
    }

    glideAnim = {
      from: { ...curPose },
      to: dest,
      start: performance.now(),
      duration: 950
    };
  };

  const startIntro = () => {
    if (reducedMotion()) return;
    const endPose = getWalkPose(D, smallPortrait);
    const startPose = { ...endPose, th: D + 0.16, r: endPose.r - 0.35 };
    curPose = startPose;
    introAnim = { from: startPose, to: endPose, start: performance.now(), duration: 1400 };
  };

  const snapStep = dir => {
    if (focusedItem) stepBack();
    targetTh = (Math.round((targetTh - D) / RING_STEP) - dir) * RING_STEP + D;
    if (reducedMotion()) curPose.th = targetTh;
  };

  const addWheelDelta = dy => {
    if (focusedItem) stepBack();
    targetTh += -dy * 0.0016;
    if (reducedMotion()) curPose.th = targetTh;
  };

  const focusNearestOuterPrint = printIdx => {
    let best = outerEntries[0];
    let bestDiff = Infinity;
    outerEntries.forEach(entry => {
      if (entry.printIdx !== printIdx) return;
      const cand = shortestAngleAround(entry.angle, curPose.th);
      const diff = Math.abs(cand - curPose.th);
      if (diff < bestDiff) {
        bestDiff = diff;
        best = entry;
      }
    });
    if (best) {
      focusMesh(best.plane);
    }
  };

  const setResize = () => {
    smallPortrait = isPortraitSmall();
    D = getWalkOffset(smallPortrait);
    const w = container.clientWidth || window.innerWidth;
    const h = container.clientHeight || window.innerHeight;
    camera.fov = getFov(w, h);
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
    if (!focusedItem && !glideAnim && !introAnim) {
      const wp = getWalkPose(curPose.th, smallPortrait);
      curPose.r = wp.r;
      curPose.yaw = wp.yaw;
      curPose.y = wp.y;
      curPose.pitch = wp.pitch;
    }
  };

  const handlePointerHover = (clientX, clientY) => {
    const hit = pickPrintAt(clientX, clientY);
    hoveredMesh = hit;
    if (focusedItem && hit === focusedItem.mesh) {
      onHoverPrint?.(true, { x: clientX, y: clientY }, getPrintScreenRect(hit));
    } else {
      onHoverPrint?.(Boolean(hit), { x: clientX, y: clientY }, null);
    }
    return Boolean(hit);
  };

  const handlePointerClick = (clientX, clientY) => {
    const hit = pickPrintAt(clientX, clientY);
    if (!focusedItem) {
      if (hit) focusMesh(hit);
      return;
    }
    if (hit === focusedItem.mesh) {
      onClickPrint?.(hit.userData.printIdx, getPrintScreenRect(hit));
    } else if (hit) {
      focusMesh(hit);
    } else {
      stepBack();
    }
  };

  let lastFrame = performance.now();
  let rafId = 0;

  const renderLoop = now => {
    if (!alive) return;
    const dt = Math.min(0.05, (now - lastFrame) * 0.001);
    lastFrame = now;

    if (!document.hidden) {
      if (introAnim) {
        const t = Math.min(1, (now - introAnim.start) / introAnim.duration);
        const e = easeOutExpo(t);
        curPose.th = introAnim.from.th + (introAnim.to.th - introAnim.from.th) * e;
        curPose.r = introAnim.from.r + (introAnim.to.r - introAnim.from.r) * e;
        if (t >= 1) {
          curPose = { ...introAnim.to };
          targetTh = curPose.th;
          introAnim = null;
        }
      } else if (glideAnim) {
        const t = Math.min(1, (now - glideAnim.start) / glideAnim.duration);
        curPose = interpolateFocusPose(glideAnim.from, glideAnim.to, t);
        if (t >= 1) {
          curPose = { ...glideAnim.to };
          targetTh = curPose.th;
          glideAnim = null;
        }
      } else if (!focusedItem) {
        const alpha = reducedMotion() ? 1 : 1 - Math.exp(-dt / 0.36);
        curPose.th += (targetTh - curPose.th) * alpha;
      }

      applyPoseToCamera(camera, curPose);
      renderer.render(scene, camera);

      if (focusedItem && smallPortrait) {
        const rect = getPrintScreenRect(focusedItem.mesh);
        onHoverPrint?.(true, null, rect);
      }
    }

    rafId = requestAnimationFrame(renderLoop);
  };

  rafId = requestAnimationFrame(renderLoop);

  const destroy = () => {
    alive = false;
    cancelAnimationFrame(rafId);
    clearTimeout(failsafeReady);
    disposables.geometries.forEach(g => g.dispose());
    disposables.materials.forEach(m => m.dispose());
    disposables.textures.forEach(t => t.dispose());
    renderer.dispose();
    try {
      renderer.getContext()?.getExtension('WEBGL_lose_context')?.loseContext();
    } catch {}
    if (renderer.domElement && renderer.domElement.parentNode === container) {
      container.removeChild(renderer.domElement);
    }
  };

  return {
    startIntro,
    snapStep,
    addWheelDelta,
    addTargetTh: delta => {
      targetTh += delta;
      if (reducedMotion()) curPose.th = targetTh;
    },
    getTargetTh: () => targetTh,
    setTargetTh: v => {
      targetTh = v;
      if (reducedMotion()) curPose.th = v;
    },
    isFocused: () => Boolean(focusedItem),
    getFocusedMesh: () => focusedItem?.mesh || null,
    getFocusedRect: () => (focusedItem ? getPrintScreenRect(focusedItem.mesh) : null),
    stepBack,
    focusNearestOuterPrint,
    handlePointerHover,
    handlePointerClick,
    setResize,
    getHoveredMesh: () => hoveredMesh,
    destroy
  };
};
