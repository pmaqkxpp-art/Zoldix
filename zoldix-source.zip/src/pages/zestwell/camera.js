export const R_OUTER = 18;
export const R_INNER = 12.2;
export const WALL_H = 6.2;
export const PW = 1.36;
export const PH = (1.36 * 763) / 567;
export const PY = 1.95;
export const RING_STEP = (2 * Math.PI) / 36;

export const getWalkOffset = isPortraitSmall =>
  isPortraitSmall ? 0.14 + 0.9 * RING_STEP : 0.14;

export const getWalkPose = (th, isPortraitSmall) =>
  isPortraitSmall
    ? { th, r: 15.4, yaw: -0.42, y: 1.9, pitch: -0.1 }
    : { th, r: 15.6, yaw: -0.3, y: 1.92, pitch: -0.12 };

export const getFocusPose = (printTh, wall, isPortraitSmall) => {
  const offset = isPortraitSmall ? 5.2 : 4.26;
  const dy = isPortraitSmall ? 1.05 : 0.52;
  return wall === 'outer'
    ? { th: printTh, r: R_OUTER - offset, yaw: Math.PI / 2, y: PY - dy, pitch: 0 }
    : { th: printTh, r: R_INNER + offset, yaw: -Math.PI / 2, y: PY - dy, pitch: 0 };
};

export const shortestAngleAround = (angle, ref) => {
  const twoPi = Math.PI * 2;
  let a = angle;
  while (a - ref > Math.PI) a -= twoPi;
  while (a - ref < -Math.PI) a += twoPi;
  return a;
};

export const easeOutQuad = t => 1 - Math.pow(1 - t, 2);
export const easeOutCubic = t => 1 - Math.pow(1 - t, 3);
export const easeOutQuart = t => 1 - Math.pow(1 - t, 4);
export const easeOutExpo = t => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t));

export const interpolateFocusPose = (from, to, t) => {
  const ct = Math.max(0, Math.min(1, t));
  const qt = easeOutQuart(ct);
  const quad = easeOutQuad(ct);
  const cub = easeOutCubic(ct);
  return {
    th: from.th + (to.th - from.th) * qt,
    yaw: from.yaw + (to.yaw - from.yaw) * quad,
    r: from.r + (to.r - from.r) * cub,
    y: from.y + (to.y - from.y) * cub,
    pitch: from.pitch + (to.pitch - from.pitch) * cub
  };
};

export const applyPoseToCamera = (camera, pose) => {
  const px = pose.r * Math.cos(pose.th);
  const py = pose.y;
  const pz = pose.r * Math.sin(pose.th);
  camera.position.set(px, py, pz);

  const tx = Math.sin(pose.th);
  const tz = -Math.cos(pose.th);
  const nx = Math.cos(pose.th);
  const nz = Math.sin(pose.th);

  const cosY = Math.cos(pose.yaw);
  const sinY = Math.sin(pose.yaw);
  const dx = cosY * tx + sinY * nx;
  const dz = cosY * tz + sinY * nz;

  camera.lookAt(px + dx, py + pose.pitch, pz + dz);
};
