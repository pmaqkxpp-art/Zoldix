import { useState } from 'react';
import {
  ZESTWELL_ACCORDIONS,
  ZESTWELL_OPTIONS,
  getDomCropStyle
} from './data.js';

export default function ZestwellProductPage({
  print,
  allPrints,
  sheetUrl,
  isSmall,
  flyerActive,
  detailsVisible,
  onAddToBag,
  onSelectCollectionPrint,
  pageRef,
  imgBoxRef
}) {
  const [paper, setPaper] = useState(ZESTWELL_OPTIONS.papers[0]);
  const [size, setSize] = useState(ZESTWELL_OPTIONS.sizes[1]);
  const [signature, setSignature] = useState(ZESTWELL_OPTIONS.signatures[0]);
  const [frame, setFrame] = useState(ZESTWELL_OPTIONS.frames[0]);
  const [qty, setQty] = useState(1);
  const [openAcc, setOpenAcc] = useState({});

  const boxW = isSmall ? Math.min(420, typeof window !== 'undefined' ? window.innerWidth - 40 : 360) : 360;
  const boxH = boxW * (4.08 / 3);

  const collectionItems = [0, 1, 2, 3].map(offset => allPrints[(print.index + offset) % allPrints.length]);

  const toggleAcc = key => {
    setOpenAcc(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <section ref={pageRef} className="zw-page" aria-label={print.title}>
      <div className="zw-page-grid">
        {/* Left Sticky Column */}
        <div className="zw-left-col">
          <div
            ref={imgBoxRef}
            className="zw-print-box"
            style={{
              ...getDomCropStyle(print.index, boxW, boxH, sheetUrl),
              opacity: flyerActive ? 0 : 1
            }}
            aria-label={print.title}
          />
          <div className={`zw-meta-row ${detailsVisible ? 'is-in' : ''}`}>
            <span>1/1</span>
            <span className="zw-meta-room">
              <svg viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.3" aria-hidden="true">
                <path d="M9 1.5 L15.5 5.2 V12.8 L9 16.5 L2.5 12.8 V5.2 Z" />
                <path d="M2.5 5.2 L9 9 L15.5 5.2 M9 9 V16.5" />
              </svg>
              <span>View in room</span>
            </span>
            <span className="zw-meta-save" aria-label="Bookmark print">
              <svg viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.3" aria-hidden="true">
                <path d="M4.5 2.5 H13.5 V15.5 L9 12.2 L4.5 15.5 Z" />
              </svg>
            </span>
          </div>
        </div>

        {/* Right Column */}
        <div className={`zw-right-col ${detailsVisible ? 'is-in' : ''}`}>
          <h2 className="zw-prod-title">{print.title}</h2>
          <p className="zw-prod-artist">{print.artist}</p>
          <p className="zw-prod-desc">{print.fullDescription}</p>
          <div className="zw-prod-price">$ {Number(print.price).toFixed(2)}</div>
          <p className="zw-prod-tax">Prices include VAT. Shipping calculated at checkout.</p>

          {/* Option Groups */}
          <div className="zw-options">
            <div className="zw-opt-group">
              <div className="zw-opt-label">
                <span>PAPER</span>
                <span className="zw-opt-cur">{paper}</span>
              </div>
              <div className="zw-chips">
                {ZESTWELL_OPTIONS.papers.map(p => (
                  <button
                    key={p}
                    type="button"
                    className={`zw-chip ${paper === p ? 'is-on' : ''}`}
                    onClick={() => setPaper(p)}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            <div className="zw-opt-group">
              <div className="zw-opt-label">
                <span>SIZE</span>
                <span className="zw-opt-cur">{size}</span>
              </div>
              <div className="zw-chips">
                {ZESTWELL_OPTIONS.sizes.map(s => (
                  <button
                    key={s}
                    type="button"
                    className={`zw-chip ${size === s ? 'is-on' : ''}`}
                    onClick={() => setSize(s)}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="zw-opt-group">
              <div className="zw-opt-label">
                <span>SIGNATURE</span>
                <span className="zw-opt-cur">{signature}</span>
              </div>
              <div className="zw-chips">
                {ZESTWELL_OPTIONS.signatures.map(sig => (
                  <button
                    key={sig}
                    type="button"
                    className={`zw-chip ${signature === sig ? 'is-on' : ''}`}
                    onClick={() => setSignature(sig)}
                  >
                    {sig}
                  </button>
                ))}
              </div>
            </div>

            <div className="zw-opt-group">
              <div className="zw-opt-label">
                <span>FRAME</span>
                <span className="zw-opt-cur">{frame}</span>
              </div>
              <div className="zw-frame-chips">
                {ZESTWELL_OPTIONS.frames.map((fr, fIdx) => {
                  const thumbW = isSmall ? 34 : 38;
                  const thumbH = thumbW * (4 / 3);
                  return (
                    <button
                      key={fr}
                      type="button"
                      className={`zw-frame-chip ${frame === fr ? 'is-on' : ''}`}
                      onClick={() => setFrame(fr)}
                    >
                      <span
                        className={`zw-frame-thumb mode-${fIdx}`}
                        style={{
                          width: `${thumbW}px`,
                          height: `${thumbH.toFixed(1)}px`,
                          ...getDomCropStyle(print.index, thumbW, thumbH, sheetUrl)
                        }}
                      />
                      <span className="zw-frame-name">{fr}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Buy Row */}
          <div className="zw-buy-row">
            <div className="zw-qty">
              <button
                type="button"
                aria-label="Decrease quantity"
                onClick={() => setQty(q => Math.max(1, q - 1))}
              >
                −
              </button>
              <span>{qty}</span>
              <button
                type="button"
                aria-label="Increase quantity"
                onClick={() => setQty(q => Math.min(9, q + 1))}
              >
                +
              </button>
            </div>
            <button
              type="button"
              className="zw-add-btn"
              onClick={() => onAddToBag({ print, paper, size, signature, frame, qty })}
            >
              ADD TO BAG
            </button>
          </div>

          {/* Accordions */}
          <div className="zw-accordions">
            {ZESTWELL_ACCORDIONS.map(acc => {
              const isOpen = Boolean(openAcc[acc.key]);
              return (
                <div key={acc.key} className={`zw-acc-item ${isOpen ? 'is-open' : ''}`}>
                  <button
                    type="button"
                    className="zw-acc-trigger"
                    aria-expanded={isOpen}
                    onClick={() => toggleAcc(acc.key)}
                  >
                    <span>{acc.title}</span>
                    <span className="zw-acc-plus">+</span>
                  </button>
                  <div className="zw-acc-body">
                    <div className="zw-acc-body-inner">
                      <p>{acc.body}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Collection Band */}
      <div className={`zw-collection ${detailsVisible ? 'is-in' : ''}`}>
        <h3 className="zw-coll-head">GET THE COLLECTION</h3>
        <div className="zw-coll-row">
          {collectionItems.map(item => {
            const cardW = isSmall ? 150 : 168;
            const cardH = cardW * (4 / 3);
            return (
              <button
                key={item.index}
                type="button"
                className="zw-coll-card"
                onClick={e => {
                  const imgEl = e.currentTarget.querySelector('.zw-coll-img');
                  const rect = imgEl?.getBoundingClientRect();
                  onSelectCollectionPrint(item.index, rect);
                }}
              >
                <div
                  className="zw-coll-img"
                  style={getDomCropStyle(item.index, cardW, cardH, sheetUrl)}
                />
                <div className="zw-coll-title">{item.title}</div>
                <div className="zw-coll-artist">{item.artist}</div>
                <div className="zw-coll-price">$ {item.price}.00</div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
