import { AERO_ANCHORS } from './data.js';

const easeInOutCubic = t => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

export const createSceneController = ({ onProgress, onSceneChange, onTransitionChange }) => {
  let pv = 0;
  let sceneIndex = 0;
  let lockedUntil = 0;
  let rafId = 0;
  let active = true;

  const isLocked = () => performance.now() < lockedUntil;

  const goTo = targetIdx => {
    if (!active) return false;
    const clamped = Math.max(0, Math.min(AERO_ANCHORS.length - 1, targetIdx));
    if (clamped === sceneIndex || isLocked()) return false;

    const prevScene = sceneIndex;
    const jumpDist = Math.abs(clamped - prevScene);
    const duration = jumpDist > 1 ? 2200 : 1700;
    const extraQuickFactsLock = clamped === 2 ? 5400 : 0;

    lockedUntil = performance.now() + duration + 150 + extraQuickFactsLock;
    sceneIndex = clamped;

    const startPv = pv;
    const endPv = AERO_ANCHORS[clamped];
    const startTime = performance.now();

    onSceneChange?.(clamped, prevScene);
    onTransitionChange?.(true);

    cancelAnimationFrame(rafId);

    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    if (reduced) {
      pv = endPv;
      onProgress?.(pv);
      onTransitionChange?.(false);
      lockedUntil = performance.now() + 100;
      return true;
    }

    const tick = now => {
      if (!active) return;
      const elapsed = now - startTime;
      const t = Math.min(1, elapsed / duration);
      pv = startPv + (endPv - startPv) * easeInOutCubic(t);
      onProgress?.(pv);
      if (t < 1) {
        rafId = requestAnimationFrame(tick);
      } else {
        pv = endPv;
        onProgress?.(pv);
        onTransitionChange?.(false);
      }
    };

    rafId = requestAnimationFrame(tick);
    return true;
  };

  const step = dir => goTo(sceneIndex + dir);

  const destroy = () => {
    active = false;
    cancelAnimationFrame(rafId);
  };

  return {
    goTo,
    step,
    getScene: () => sceneIndex,
    getPv: () => pv,
    isLocked,
    destroy
  };
};
