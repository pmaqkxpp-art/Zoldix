export const formatPragueClock = () => {
  try {
    return new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Europe/Prague',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    }).format(new Date());
  } catch {
    const d = new Date();
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }
};

export const formatAeroDate = () => {
  try {
    const d = new Date();
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yyyy = d.getFullYear();
    return `${dd}.${mm}.${yyyy}`;
  } catch {
    return '22.11.2026';
  }
};

export const attachAeroCursor = ({ cursorEl, recMode }) => {
  if (!cursorEl || typeof window === 'undefined') return () => {};
  const hasPointer = window.matchMedia?.('(hover: hover) and (pointer: fine)').matches ?? false;
  if (!hasPointer) {
    cursorEl.style.display = 'none';
    return () => {};
  }

  let raf = 0;
  let tx = -100;
  let ty = -100;
  let cx = -100;
  let cy = -100;
  let alive = true;

  const onMove = event => {
    tx = event.clientX;
    ty = event.clientY;
    const hovered = event.target.closest('button, a, .aero-hotspot, .aero-orb, .aero-icon-lobe');
    cursorEl.classList.toggle('is-hover', Boolean(hovered));
  };

  const onLeave = () => {
    cursorEl.style.opacity = '0';
  };

  const onEnter = () => {
    cursorEl.style.opacity = '1';
  };

  const loop = () => {
    if (!alive) return;
    cx += (tx - cx) * (recMode ? 0.35 : 0.24);
    cy += (ty - cy) * (recMode ? 0.35 : 0.24);
    cursorEl.style.transform = `translate3d(${cx.toFixed(1)}px, ${cy.toFixed(1)}px, 0) translate(-50%, -50%)`;
    raf = requestAnimationFrame(loop);
  };

  raf = requestAnimationFrame(loop);
  window.addEventListener('pointermove', onMove, { passive: true });
  document.addEventListener('mouseleave', onLeave);
  document.addEventListener('mouseenter', onEnter);

  return () => {
    alive = false;
    cancelAnimationFrame(raf);
    window.removeEventListener('pointermove', onMove);
    document.removeEventListener('mouseleave', onLeave);
    document.removeEventListener('mouseenter', onEnter);
  };
};
