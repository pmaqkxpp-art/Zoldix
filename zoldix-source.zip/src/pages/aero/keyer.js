const VS_SRC = `
attribute vec2 aPos;
varying vec2 vUv;
void main() {
  vUv = aPos * 0.5 + 0.5;
  gl_Position = vec4(aPos, 0.0, 1.0);
}
`;

const FS_SRC = `
precision mediump float;
uniform sampler2D uTex;
varying vec2 vUv;
void main() {
  vec2 uv = vec2(vUv.x, 1.0 - vUv.y);
  vec4 c = texture2D(uTex, uv);
  float d = min(c.r, c.b) - c.g;
  float a = 1.0 - smoothstep(0.10, 0.36, d);
  float sp = max(0.0, min(c.r, c.b) - c.g);
  c.r -= sp * 0.92;
  c.b -= sp * 0.92;
  float edge = smoothstep(0.0, 0.03, uv.x)
             * smoothstep(1.0, 0.97, uv.x)
             * smoothstep(0.0, 0.03, uv.y)
             * smoothstep(1.0, 0.97, uv.y);
  a *= edge;
  gl_FragColor = vec4(max(vec3(0.0), c.rgb) * a, a);
}
`;

const compileShader = (gl, type, src) => {
  const shader = gl.createShader(type);
  if (!shader) return null;
  gl.shaderSource(shader, src);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    gl.deleteShader(shader);
    return null;
  }
  return shader;
};

export const createMagentaKeyer = ({ canvas, posterUrl, onAspect, onFallback }) => {
  const gl =
    canvas.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: true }) ||
    canvas.getContext('experimental-webgl', { alpha: true, premultipliedAlpha: true, antialias: true });

  if (!gl) {
    onFallback?.();
    return null;
  }

  const vs = compileShader(gl, gl.VERTEX_SHADER, VS_SRC);
  const fs = compileShader(gl, gl.FRAGMENT_SHADER, FS_SRC);
  if (!vs || !fs) {
    onFallback?.();
    return null;
  }

  const program = gl.createProgram();
  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    onFallback?.();
    return null;
  }

  gl.useProgram(program);

  const buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);

  const aPos = gl.getAttribLocation(program, 'aPos');
  gl.enableVertexAttribArray(aPos);
  gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

  const tex = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 0]));

  gl.uniform1i(gl.getUniformLocation(program, 'uTex'), 0);

  let posterImg = new Image();
  let posterReady = false;
  posterImg.crossOrigin = 'anonymous';
  posterImg.onload = () => {
    posterReady = true;
    if (posterImg.naturalWidth && posterImg.naturalHeight) {
      onAspect?.(posterImg.naturalWidth / posterImg.naturalHeight);
      resize(posterImg.naturalWidth, posterImg.naturalHeight);
    }
  };
  posterImg.src = posterUrl;

  const resize = (srcW = 1280, srcH = 720) => {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const rect = canvas.getBoundingClientRect();
    const targetW = Math.max(2, Math.round((rect.width || 960) * dpr));
    const targetH = Math.max(2, Math.round((targetW * srcH) / Math.max(1, srcW)));
    if (canvas.width !== targetW || canvas.height !== targetH) {
      canvas.width = targetW;
      canvas.height = targetH;
    }
    gl.viewport(0, 0, canvas.width, canvas.height);
  };

  resize();

  const renderFrame = videoEl => {
    const videoReady = videoEl && videoEl.readyState >= 2 && videoEl.videoWidth > 0;
    const source = videoReady ? videoEl : posterReady ? posterImg : null;
    if (!source) return;

    const srcW = videoReady ? videoEl.videoWidth : posterImg.naturalWidth;
    const srcH = videoReady ? videoEl.videoHeight : posterImg.naturalHeight;
    if (srcW && srcH) {
      resize(srcW, srcH);
    }

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, tex);
    try {
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
    } catch {
      return;
    }

    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  };

  const destroy = () => {
    gl.deleteTexture(tex);
    gl.deleteBuffer(buf);
    gl.deleteProgram(program);
    gl.deleteShader(vs);
    gl.deleteShader(fs);
    try {
      gl.getExtension('WEBGL_lose_context')?.loseContext();
    } catch {}
  };

  return { renderFrame, resize, destroy };
};
