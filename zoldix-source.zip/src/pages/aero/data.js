import { getAsset, getDefaultAsset } from '../../config/siteConfig.js';

export const getAeroAssets = () => ({
  video: getAsset('aero.video') || getDefaultAsset('aero.video'),
  poster: getAsset('aero.poster') || getDefaultAsset('aero.poster'),
  plinth: getAsset('aero.plinth') || getDefaultAsset('aero.plinth'),
  wordmark: getAsset('aero.wordmark') || getDefaultAsset('aero.wordmark'),
  marquee: getAsset('aero.marquee') || getDefaultAsset('aero.marquee'),
  detail: getAsset('aero.detail') || getDefaultAsset('aero.detail'),
  blobVideo: getAsset('aero.blobVideo') || getDefaultAsset('aero.blobVideo'),
  logoVideo: getAsset('aero.logoVideo') || getDefaultAsset('aero.logoVideo'),
  fallbackPoster: getDefaultAsset('aero.poster')
});

export const AERO_ANCHORS = [0, 0.45, 0.79, 1];

export const AERO_CORNERS = [
  {
    leftTitle: 'bangers only',
    leftSub: "IT'S ALWAYS TIME TO ENJOY.",
    rightTitle: 'inspired',
    rightSub: 'FROM 10:00 TO 19:00'
  },
  {
    leftTitle: 'detail.{01}',
    leftSub: 'LOOK CLOSER. HOVER THE POINTS.',
    rightTitle: 'built light',
    rightSub: '24 GRAMS OF CHROME'
  },
  {
    leftTitle: 'quick facts',
    leftSub: 'THE NUMBERS THAT MATTER.',
    rightTitle: 'tested',
    rightSub: '2,400 KM OF RIDES'
  },
  {
    leftTitle: 'ready?',
    leftSub: 'DROP 01 · 500 PAIRS WORLDWIDE.',
    rightTitle: 'ships',
    rightSub: 'JUNE 2026 FREE RETURNS'
  }
];

export const AERO_HOTSPOTS = [
  {
    id: 'lens',
    x: 64,
    y: 44,
    title: 'PHOTOCHROMIC LENS',
    body: 'Adaptive UV400 shield shifts VLT 14%–78% in 0.8 seconds under sudden cloud breaks.'
  },
  {
    id: 'frame',
    x: 49,
    y: 35,
    title: 'LIQUID-CHROME FRAME',
    body: 'Single-pour magnesium-nylon monocoque, PVD mirror-coated for zero-seam aerodynamics.'
  },
  {
    id: 'temples',
    x: 78,
    y: 39,
    title: 'GRIP TEMPLES',
    body: 'Micro-ribbed hydrophilic elastomer tips lock tighter as pace and perspiration rise.'
  }
];

export const AERO_LENSES = [
  { id: 'acid', name: 'Acid', deg: 0, color: '#c6ff3d' },
  { id: 'ice', name: 'Ice', deg: 95, color: '#4df5ff' },
  { id: 'ember', name: 'Ember', deg: -62, color: '#ff5d47' },
  { id: 'ultra', name: 'Ultra', deg: 175, color: '#b47aff' }
];

export const AERO_FITS = ['Narrow', 'Regular', 'Wide'];
