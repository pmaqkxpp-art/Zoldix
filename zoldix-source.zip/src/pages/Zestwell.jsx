import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  SMALL_SCREEN_QUERY,
  getDomCropStyle,
  getZestwellPrints,
  getZestwellSheetUrl
} from './zestwell/data.js';
import { createZestwellRoom } from './zestwell/room.js';
import ZestwellProductPage from './zestwell/page.jsx';
import ZestwellBagDrawer from './zestwell/bag.jsx';
import './zestwell.css';

export default function Zestwell({ pageReady }) {
  const sheetUrl = useMemo(() => getZestwellSheetUrl(), []);
  const prints = useMemo(() => getZestwellPrints(), []);

  const [view, setView] = useState('gallery'); // 'gallery' | 'page' | 'list'
  const [selectedPrintIdx, setSelectedPrintIdx] = useState(0);
  const [focused, setFocused] = useState(false);
  const [veilCleared, setVeilCleared] = useState(false);
  const [roomReady, setRoomReady] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [hoverPrint, setHoverPrint] = useState(false);
  const [pillState, setPillState] = useState({ visible: false, x: 0, y: 0 });
  const [flyerActive, setFlyerActive] = useState(false);
  const [detailsVisible, setDetailsVisible] = useState(false);
  const [bagOpen, setBagOpen] = useState(false);
  const [bagItems, setBagItems] = useState([]);
  const [isSmall, setIsSmall] = useState(() =>
    typeof window !== 'undefined' ? window.matchMedia(SMALL_SCREEN_QUERY).matches : false
  );

  const canvasMountRef = useRef(null);
  const galleryRef = useRef(null);
  const navRef = useRef(null);
  const pageScrollRef = useRef(null);
  const imgBoxRef = useRef(null);
  const maskLineRefs = useRef([]);
  const roomRef = useRef(null);
  const lastPrintIdxRef = useRef(0);
  const viewRef = useRef('gallery');
  viewRef.current = view;

  const isReducedMotion = useCallback(
    () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false,
    []
  );

  // Lock body overflow
  useEffect(() => {
    const prevHtml = document.documentElement.style.overflow;
    const prevBody = document.body.style.overflow;
    const prevBg = document.body.style.background;
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';
    document.body.style.background = '#FFF9EC';
    return () => {
      document.documentElement.style.overflow = prevHtml;
      document.body.style.overflow = prevBody;
      document.body.style.background = prevBg;
    };
  }, []);

  // Small-screen matcher
  useEffect(() => {
    const mq = window.matchMedia(SMALL_SCREEN_QUERY);
    const update = () => {
      setIsSmall(mq.matches);
      roomRef.current?.setResize();
    };
    update();
    mq.addEventListener?.('change', update);
    window.addEventListener('resize', update);
    return () => {
      mq.removeEventListener?.('change', update);
      window.removeEventListener('resize', update);
    };
  }, []);

  // Fly-in opener for print product page
  const openPrintPage = useCallback(
    (printIdx, sourceRect) => {
      lastPrintIdxRef.current = printIdx;
      setSelectedPrintIdx(printIdx);
      setView('page');
      setPillState(prev => ({ ...prev, visible: false }));

      const reduced = isReducedMotion();
      if (reduced || !sourceRect) {
        setFlyerActive(false);
        setDetailsVisible(true);
        return;
      }

      setFlyerActive(true);
      setDetailsVisible(false);

      requestAnimationFrame(() => {
        if (pageScrollRef.current) pageScrollRef.current.scrollTop = 0;
        const targetBox = imgBoxRef.current;
        if (!targetBox) {
          setFlyerActive(false);
          setDetailsVisible(true);
          return;
        }
        const dest = targetBox.getBoundingClientRect();
        const flyer = document.createElement('div');
        flyer.className = 'zw-flyer';
        Object.assign(flyer.style, {
          left: `${sourceRect.left}px`,
          top: `${sourceRect.top}px`,
          width: `${sourceRect.width}px`,
          height: `${sourceRect.height}px`,
          ...getDomCropStyle(printIdx, sourceRect.width, sourceRect.height, sheetUrl)
        });
        document.body.appendChild(flyer);

        const dx = dest.left - sourceRect.left;
        const dy = dest.top - sourceRect.top;
        const sx = dest.width / Math.max(1, sourceRect.width);
        const sy = dest.height / Math.max(1, sourceRect.height);

        const anim = flyer.animate(
          [
            { transform: 'translate(0px, 0px) scale(1, 1)' },
            { transform: `translate(${dx}px, ${dy}px) scale(${sx}, ${sy})` }
          ],
          { duration: 300, easing: 'cubic-bezier(.25,.75,.25,1)', fill: 'forwards' }
        );

        const cleanupFlyer = () => {
          setFlyerActive(false);
          flyer.remove();
        };
        anim.onfinish = cleanupFlyer;
        setTimeout(() => {
          if (flyer.parentNode) cleanupFlyer();
        }, 380);
      });

      setTimeout(() => {
        setDetailsVisible(true);
      }, 1000);
    },
    [isReducedMotion, sheetUrl]
  );

  // Mount Three.js curved room
  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return undefined;

    const mq = window.matchMedia(SMALL_SCREEN_QUERY);
    const room = createZestwellRoom({
      container: mount,
      sheetUrl,
      prints,
      isPortraitSmall: () => mq.matches && window.innerHeight > window.innerWidth,
      reducedMotion: isReducedMotion,
      onReady: () => setRoomReady(true),
      onWebGLFail: () => {
        setRoomReady(true);
        setView('list');
      },
      onHoverPrint: (isOver, cursorPt, focusedRect) => {
        setHoverPrint(isOver);
        const focusedNow = roomRef.current?.isFocused();
        if (focusedNow && focusedRect) {
          setPillState({
            visible: mq.matches ? true : isOver,
            x: mq.matches ? focusedRect.left + focusedRect.width / 2 : cursorPt?.x || 0,
            y: mq.matches ? focusedRect.top + focusedRect.height * 0.55 : cursorPt?.y || 0
          });
        } else {
          setPillState(prev => (prev.visible ? { ...prev, visible: false } : prev));
        }
      },
      onClickPrint: (printIdx, rect) => {
        openPrintPage(printIdx, rect);
      },
      onStepBack: () => {
        setFocused(false);
        setPillState(prev => ({ ...prev, visible: false }));
      }
    });

    roomRef.current = room;
    return () => {
      room?.destroy();
      roomRef.current = null;
    };
  }, [isReducedMotion, openPrintPage, prints, sheetUrl]);

  // Entrance sequence runs ONLY after pageReady AND roomReady (4s failsafe inside room)
  useEffect(() => {
    if (!pageReady || !roomReady) return undefined;
    setVeilCleared(true);
    roomRef.current?.startIntro();

    const reduced = isReducedMotion();
    if (reduced) return undefined;

    const targets = [
      ...maskLineRefs.current.filter(Boolean),
      ...(navRef.current ? Array.from(navRef.current.children) : [])
    ];
    const anims = [];
    const maskCount = maskLineRefs.current.filter(Boolean).length;

    targets.forEach((el, idx) => {
      const isNav = idx >= maskCount;
      anims.push(
        el.animate(
          isNav
            ? [{ opacity: 0 }, { opacity: 1 }]
            : [
                { transform: 'translateY(105%)', opacity: 0 },
                { transform: 'translateY(0%)', opacity: 1 }
              ],
          {
            duration: 1000,
            delay: 250 + idx * 60,
            easing: 'cubic-bezier(.2,.7,.2,1)',
            fill: 'backwards'
          }
        )
      );
    });

    return () => {
      anims.forEach(a => {
        try {
          a.cancel();
        } catch {}
      });
    };
  }, [isReducedMotion, pageReady, roomReady]);

  // Pointer & Wheel & Keyboard interactions on 3D Gallery
  useEffect(() => {
    const galleryEl = galleryRef.current;
    if (!galleryEl) return undefined;

    let pointerDown = false;
    let dragged = false;
    let startX = 0;
    let startY = 0;
    let startTargetTh = 0;

    const onWheel = event => {
      if (viewRef.current !== 'gallery' || bagOpen) return;
      event.preventDefault();
      let dy = event.deltaY;
      if (event.deltaMode === 1) dy *= 33;
      roomRef.current?.addWheelDelta(dy);
      setFocused(Boolean(roomRef.current?.isFocused()));
    };

    const onPointerDown = event => {
      if (viewRef.current !== 'gallery' || bagOpen) return;
      pointerDown = true;
      dragged = false;
      startX = event.clientX;
      startY = event.clientY;
      startTargetTh = roomRef.current?.getTargetTh() || 0;
      setIsDragging(false);
    };

    const onPointerMove = event => {
      if (viewRef.current !== 'gallery') return;
      const room = roomRef.current;
      if (!room) return;

      if (pointerDown) {
        const dx = event.clientX - startX;
        const dy = event.clientY - startY;
        if (!dragged && Math.hypot(dx, dy) > 6) {
          dragged = true;
          setIsDragging(true);
          if (room.isFocused()) {
            room.stepBack();
            setFocused(false);
          }
        }
        if (dragged) {
          const factor = isSmall ? 0.0042 : 0.0022;
          const delta = Math.abs(dx) > Math.abs(dy) ? dx : dy;
          room.setTargetTh(startTargetTh + delta * factor);
        }
      } else {
        room.handlePointerHover(event.clientX, event.clientY);
      }
    };

    const onPointerUp = event => {
      if (!pointerDown) return;
      pointerDown = false;
      setIsDragging(false);
      if (!dragged && viewRef.current === 'gallery') {
        const beforeFocus = roomRef.current?.isFocused();
        roomRef.current?.handlePointerClick(event.clientX, event.clientY);
        const afterFocus = Boolean(roomRef.current?.isFocused());
        setFocused(afterFocus);
        if (beforeFocus && afterFocus) {
          // Opened product page cleanly via handlePointerClick -> onClickPrint
        }
      }
    };

    const onKeyDown = event => {
      if (event.target.closest('input, textarea, select')) return;
      if (event.key === 'Escape') {
        if (bagOpen) {
          setBagOpen(false);
        } else if (viewRef.current !== 'gallery') {
          backToGallery();
        } else if (roomRef.current?.isFocused()) {
          roomRef.current.stepBack();
          setFocused(false);
        }
        return;
      }

      if (viewRef.current === 'gallery') {
        if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
          event.preventDefault();
          roomRef.current?.snapStep(1);
          setFocused(false);
        } else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
          event.preventDefault();
          roomRef.current?.snapStep(-1);
          setFocused(false);
        }
      }
    };

    galleryEl.addEventListener('wheel', onWheel, { passive: false });
    galleryEl.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointercancel', onPointerUp);
    window.addEventListener('keydown', onKeyDown);

    return () => {
      galleryEl.removeEventListener('wheel', onWheel);
      galleryEl.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('pointercancel', onPointerUp);
      window.removeEventListener('keydown', onKeyDown);
    };
  }, [bagOpen, isSmall]);

  const backToGallery = () => {
    setView('gallery');
    roomRef.current?.focusNearestOuterPrint(lastPrintIdxRef.current);
    setFocused(true);
  };

  const handleAddToBag = ({ print, paper, size, signature, frame, qty }) => {
    const id = `${print.index}|${paper}|${size}|${signature}|${frame}`;
    const reduced = isReducedMotion();
    setBagItems(prev => {
      const existing = prev.find(item => item.id === id);
      if (existing) {
        return prev.map(item => (item.id === id ? { ...item, qty: Math.min(9, item.qty + qty) } : item));
      }
      return [
        ...prev,
        {
          id,
          printIndex: print.index,
          title: print.title,
          artist: print.artist,
          price: Number(print.price),
          size,
          frame,
          qty,
          entering: !reduced
        }
      ];
    });
    setBagOpen(true);

    if (!reduced) {
      setTimeout(() => {
        setBagItems(prev => prev.map(item => (item.id === id ? { ...item, entering: false } : item)));
      }, 750);
    }
  };

  const totalBagCount = bagItems.reduce((sum, item) => sum + item.qty, 0);
  const currentPrint = prints[selectedPrintIdx] || prints[0];

  return (
    <div className="zestwell-root">
      {/* Persistent Top Nav */}
      <header ref={navRef} className={`zw-nav ${view !== 'gallery' ? 'has-bg' : ''}`}>
        <button type="button" className="zw-logo" onClick={backToGallery}>
          Zestwell
        </button>

        <nav className="zw-nav-links" aria-label="Zestwell navigation">
          <button type="button" onClick={backToGallery}>
            Index
          </button>
          <button type="button" onClick={() => setView('list')}>
            Shop
          </button>
          <button type="button" onClick={() => setView('list')}>
            Info
          </button>
          <button type="button" onClick={() => setView('list')}>
            Auctions
          </button>
          <button type="button" onClick={() => setView('list')}>
            Help
          </button>
        </nav>

        <div className="zw-nav-right">
          <button type="button" className="zw-search-pill" onClick={() => setView('list')}>
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true">
              <circle cx="7" cy="7" r="4.5" />
              <line x1="10.5" y1="10.5" x2="14" y2="14" />
            </svg>
            <span>Search…</span>
            <kbd>⌘K</kbd>
          </button>

          <button type="button" className="zw-currency-pill">
            <span>USD</span>
            <span aria-hidden="true">▾</span>
          </button>

          <button type="button" className="zw-icon-btn zw-account-btn" aria-label="Account">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
              <circle cx="12" cy="8" r="4" />
              <path d="M5 20 c1.5-3.8 4-5.5 7-5.5 s5.5 1.7 7 5.5" />
            </svg>
          </button>

          <button type="button" className="zw-icon-btn zw-heart-btn" aria-label="Saved">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
              <path d="M12 20.5 S4.5 15 4.5 9.5 A4.2 4.2 0 0 1 12 6.8 A4.2 4.2 0 0 1 19.5 9.5 C19.5 15 12 20.5 12 20.5 Z" />
            </svg>
          </button>

          <button
            type="button"
            className="zw-icon-btn zw-bag-btn"
            aria-label="Shopping bag"
            onClick={() => setBagOpen(true)}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
              <path d="M5 8 H19 L18 20.5 H6 Z" />
              <path d="M9 9.5 V6.5 A3 3 0 0 1 15 6.5 V9.5" />
            </svg>
            {totalBagCount > 0 && <span className="zw-bag-badge">{totalBagCount}</span>}
          </button>
        </div>
      </header>

      {/* 3D WebGL Gallery */}
      <main
        id="gallery"
        ref={galleryRef}
        className={`zw-gallery ${isDragging ? 'is-dragging' : ''} ${hoverPrint ? 'is-hover-print' : ''}`}
      >
        <div ref={canvasMountRef} className="zw-canvas-mount" />
        <div id="veil" className={`zw-veil ${veilCleared ? 'is-cleared' : ''}`} aria-hidden="true" />
      </main>

      {/* Gallery HUD */}
      <div className={`zw-gui ${view !== 'gallery' ? 'is-hidden' : ''}`}>
        <div className="zw-arrows">
          <button
            type="button"
            className="zw-arrow-circle"
            aria-label="Previous print"
            onClick={() => {
              roomRef.current?.snapStep(-1);
              setFocused(false);
            }}
          >
            <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M16 10 H4 M9 5 L4 10 L9 15" />
            </svg>
          </button>
          <button
            type="button"
            className="zw-arrow-circle"
            aria-label="Next print"
            onClick={() => {
              roomRef.current?.snapStep(1);
              setFocused(false);
            }}
          >
            <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M4 10 H16 M11 5 L16 10 L11 15" />
            </svg>
          </button>
        </div>

        <div className="zw-hint">
          <span className="zw-mask">
            <span
              ref={el => {
                maskLineRefs.current[0] = el;
              }}
              className="zw-mask-line"
            >
              {focused ? 'Click the painting to open it' : 'Scroll or drag to walk round'}
            </span>
          </span>
          <span className="zw-mask">
            <span
              ref={el => {
                maskLineRefs.current[1] = el;
              }}
              className="zw-mask-line"
            >
              {focused ? 'Esc or click away to step back' : 'Click a painting to look closer'}
            </span>
          </span>
        </div>

        <div className="zw-toggle" role="tablist" aria-label="View mode">
          <button
            type="button"
            className={view === 'gallery' ? 'is-active' : ''}
            onClick={() => setView('gallery')}
          >
            GALLERY
          </button>
          <button type="button" className={view === 'list' ? 'is-active' : ''} onClick={() => setView('list')}>
            LIST
          </button>
        </div>

        <div className="zw-caption">
          <p className="zw-kicker">
            <span className="zw-mask">
              <span
                ref={el => {
                  maskLineRefs.current[2] = el;
                }}
                className="zw-mask-line"
              >
                YOU ARE WALKING PAST
              </span>
            </span>
          </p>
          <div className="zw-headline-row">
            <h1 className="zw-headline">
              <span className="zw-mask">
                <span
                  ref={el => {
                    maskLineRefs.current[3] = el;
                  }}
                  className="zw-mask-line zw-headline-wrap"
                >
                  CITRUS SEASON
                </span>
              </span>
            </h1>
            <button type="button" className="zw-enter-link" onClick={() => setView('list')}>
              <span className="zw-mask">
                <span
                  ref={el => {
                    maskLineRefs.current[4] = el;
                  }}
                  className="zw-mask-line"
                >
                  ENTER THE COLLECTION →
                </span>
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Hover / Focus Pill */}
      <div
        className={`zw-open-pill ${pillState.visible && view === 'gallery' ? 'is-visible' : ''}`}
        style={{ left: `${pillState.x}px`, top: `${pillState.y}px` }}
        aria-hidden="true"
      >
        OPEN THE PRINT
      </div>

      {/* Print Product Page */}
      {view === 'page' && (
        <ZestwellProductPage
          print={currentPrint}
          allPrints={prints}
          sheetUrl={sheetUrl}
          isSmall={isSmall}
          flyerActive={flyerActive}
          detailsVisible={detailsVisible}
          onAddToBag={handleAddToBag}
          onSelectCollectionPrint={(nextIdx, rect) => openPrintPage(nextIdx, rect)}
          pageRef={pageScrollRef}
          imgBoxRef={imgBoxRef}
        />
      )}

      {/* List View */}
      {view === 'list' && (
        <section className="zw-list" aria-label="Citrus Season Collection">
          <h2 className="zw-list-head">CITRUS SEASON — ALL PRINTS</h2>
          <div className="zw-list-grid">
            {prints.map(item => {
              const cardW = isSmall ? 160 : 168;
              const cardH = cardW * (4 / 3);
              return (
                <button
                  key={item.index}
                  type="button"
                  className="zw-coll-card"
                  style={{ width: '100%' }}
                  onClick={e => {
                    const imgEl = e.currentTarget.querySelector('.zw-coll-img');
                    openPrintPage(item.index, imgEl?.getBoundingClientRect());
                  }}
                >
                  <div
                    className="zw-coll-img"
                    style={getDomCropStyle(item.index, cardW, cardH, sheetUrl)}
                  />
                  <div className="zw-coll-title">{item.title}</div>
                  <div className="zw-coll-artist">{item.artist}</div>
                  <div className="zw-coll-price">$ {item.price}.00</div>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* Bag Drawer */}
      <ZestwellBagDrawer
        open={bagOpen}
        items={bagItems}
        sheetUrl={sheetUrl}
        isSmall={isSmall}
        onClose={() => setBagOpen(false)}
        onUpdateQty={(id, delta) =>
          setBagItems(prev =>
            prev
              .map(it => (it.id === id ? { ...it, qty: Math.min(9, it.qty + delta) } : it))
              .filter(it => it.qty > 0)
          )
        }
        onRemoveItem={id => setBagItems(prev => prev.filter(it => it.id !== id))}
      />
    </div>
  );
}
