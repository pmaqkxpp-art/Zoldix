import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  HINA_SPRITES,
  HINA_SPRITE_NATIVE_H,
  HINA_SPRITE_NATIVE_W,
  HINA_TABS,
  getHinaAssets,
  getHinaProducts,
  pad2
} from './hina/data.js';
import { computePiecePlacement, getFloorShadowTop, getRailPolygonPoints } from './hina/rail.js';
import { computeDetailLayerStyle } from './hina/detail.js';
import { attachHinaInput } from './hina/input.js';
import { runHinaIntro } from './hina/intro.js';
import './hina.css';

export default function Hina({ pageReady }) {
  const assets = useMemo(() => getHinaAssets(), []);
  const products = useMemo(() => getHinaProducts(), []);

  const [cur, setCur] = useState(0);
  const [displayIdx, setDisplayIdx] = useState(0);
  const [swappingText, setSwappingText] = useState(false);
  const [hoveredSlot, setHoveredSlot] = useState(-1);
  const [isPointer, setIsPointer] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [slowTrans, setSlowTrans] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  const [exitingPiece, setExitingPiece] = useState(null);
  const [enteringPiece, setEnteringPiece] = useState(null);
  const [isPhone, setIsPhone] = useState(() => (typeof window !== 'undefined' ? window.innerWidth <= 820 : false));
  const [boxSize, setBoxSize] = useState({ w: 270, h: 470 });

  const pageRef = useRef(null);
  const stageRef = useRef(null);
  const frameRef = useRef(null);
  const tubeRef = useRef(null);
  const navRef = useRef(null);
  const garmentRefs = useRef([]);
  const lineRefs = useRef([]);
  const indexRef = useRef(null);
  const ruleRef = useRef(null);
  const viewBtnRef = useRef(null);
  const pagerRef = useRef(null);
  const footerRef = useRef(null);
  const hintRef = useRef(null);
  const panelRef = useRef(null);
  const panelBoxRef = useRef(null);

  const metricsRef = useRef({ left: 0, top: 0, scale: 1 });
  const stateRef = useRef({ cur: 0, detailOpen: false, isPhone: false, railTimers: [] });
  stateRef.current.cur = cur;
  stateRef.current.detailOpen = detailOpen;
  stateRef.current.isPhone = isPhone;

  const railPolygonPoints = useMemo(() => getRailPolygonPoints(), []);
  const shadowTop = useMemo(() => getFloorShadowTop(cur), [cur]);

  // Body background & overflow management (desktop locked, phone scrollable)
  useEffect(() => {
    const prevHtmlOverflow = document.documentElement.style.overflow;
    const prevBodyOverflow = document.body.style.overflow;
    const prevBodyBg = document.body.style.background;

    const applyOverflow = () => {
      const phone = window.innerWidth <= 820;
      document.documentElement.style.overflow = phone ? '' : 'hidden';
      document.body.style.overflow = phone ? '' : 'hidden';
      document.body.style.background = '#ECE6EB';
    };

    applyOverflow();
    window.addEventListener('resize', applyOverflow);
    return () => {
      window.removeEventListener('resize', applyOverflow);
      document.documentElement.style.overflow = prevHtmlOverflow;
      document.body.style.overflow = prevBodyOverflow;
      document.body.style.background = prevBodyBg;
    };
  }, []);

  // Frame scale & nav scale calculation
  useEffect(() => {
    const computeLayout = () => {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const phone = vw <= 820;
      setIsPhone(phone);

      const pageEl = pageRef.current;
      const frameEl = frameRef.current;
      const stageEl = stageRef.current;
      if (!pageEl || !frameEl || !stageEl) return;

      const ns = Math.max(0.62, Math.min(1, vw / 1440));
      pageEl.style.setProperty('--ns', ns.toFixed(4));

      if (!phone) {
        const s = Math.min(Math.max(vw / 1440, vh / 900), vh / 870, vw / 1380);
        const tx = -720 * s;
        const ty = -450 * s;
        frameEl.style.left = '50%';
        frameEl.style.top = '50%';
        frameEl.style.transform = `translate(${tx.toFixed(2)}px, ${ty.toFixed(2)}px) scale(${s.toFixed(5)})`;
        metricsRef.current = {
          left: vw / 2 + tx,
          top: vh / 2 + ty,
          scale: s
        };
      } else {
        const stageRect = stageEl.getBoundingClientRect();
        const sh = Math.max(430, stageRect.height || Math.round(vh * 0.64));
        const s = sh / 780;
        const x = Math.min(0, Math.max(vw - 1100 * s, (vw - 760 * s) / 2 - 40 * s));
        const y = -sh / 2 - 20 * s;
        frameEl.style.left = '0px';
        frameEl.style.top = '50%';
        frameEl.style.transform = `translate(${x.toFixed(2)}px, ${y.toFixed(2)}px) scale(${s.toFixed(5)})`;
        metricsRef.current = {
          left: x,
          top: stageRect.top + sh / 2 + y,
          scale: s
        };
      }

      if (panelBoxRef.current) {
        const rect = panelBoxRef.current.getBoundingClientRect();
        if (rect.width > 40 && rect.height > 40) {
          setBoxSize({ w: Math.round(rect.width), h: Math.round(rect.height) });
        }
      }
    };

    computeLayout();
    window.addEventListener('resize', computeLayout);
    return () => window.removeEventListener('resize', computeLayout);
  }, [detailOpen]);

  // Trigger detail box measurement on open/tab changes
  useEffect(() => {
    if (!detailOpen) return;
    const raf = requestAnimationFrame(() => {
      if (panelBoxRef.current) {
        const rect = panelBoxRef.current.getBoundingClientRect();
        if (rect.width > 40 && rect.height > 40) {
          setBoxSize({ w: Math.round(rect.width), h: Math.round(rect.height) });
        } else if (!isPhone) {
          setBoxSize({ w: 270, h: 470 });
        }
      }
    });
    return () => cancelAnimationFrame(raf);
  }, [detailOpen, isPhone, cur]);

  // Intro animation after global Zoldix Loader completes
  useEffect(() => {
    if (!pageReady) return undefined;
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    return runHinaIntro({
      rootEl: pageRef.current,
      tubeEl: tubeRef.current,
      navEl: navRef.current,
      garmentEls: garmentRefs.current,
      lineEls: lineRefs.current,
      chromeEls: [
        indexRef.current,
        ruleRef.current,
        viewBtnRef.current,
        pagerRef.current,
        footerRef.current,
        hintRef.current
      ],
      reducedMotion: reduced
    });
  }, [pageReady]);

  // Text swap helper
  const triggerTextSwap = useCallback(nextIdx => {
    setSwappingText(true);
    setTimeout(() => {
      setDisplayIdx(nextIdx);
      setSwappingText(false);
    }, 140);
  }, []);

  // Step forward or backward
  const stepRail = useCallback(
    dir => {
      const prevCur = stateRef.current.cur;
      const nextCur = (prevCur + dir + 12) % 12;
      setHoveredSlot(-1);

      if (dir > 0) {
        // Old front exits to slot -1.3 for 360ms, then snaps to slot 11
        setExitingPiece(prevCur);
        setTimeout(() => {
          setExitingPiece(currentExit => (currentExit === prevCur ? null : currentExit));
        }, 360);
      } else {
        // Last piece jumps instantaneously to -1.3 then slides into slot 0
        setEnteringPiece(nextCur);
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            setEnteringPiece(null);
          });
        });
      }

      setCur(nextCur);
      triggerTextSwap(nextCur);
    },
    [triggerTextSwap]
  );

  // Toggle Detail View
  const setDetailMode = useCallback(
    open => {
      setSlowTrans(true);
      setTimeout(() => setSlowTrans(false), 760);
      setDetailOpen(open);
      if (open) {
        setActiveTab(0);
        setHoveredSlot(-1);
        if (window.innerWidth <= 820) {
          const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
          setTimeout(() => {
            panelRef.current?.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' });
          }, 80);
        }
      }
    },
    []
  );

  const handleClickRailSlot = useCallback(
    slot => {
      stateRef.current.railTimers.forEach(clearTimeout);
      stateRef.current.railTimers = [];
      setHoveredSlot(slot);

      const startTimer = setTimeout(() => {
        for (let step = 0; step < slot; step += 1) {
          const t = setTimeout(() => stepRail(1), step * 120);
          stateRef.current.railTimers.push(t);
        }
      }, 260);
      stateRef.current.railTimers.push(startTimer);
    },
    [stepRail]
  );

  // Input attachment
  useEffect(() => {
    const stageEl = stageRef.current;
    if (!stageEl) return undefined;
    const cleanup = attachHinaInput({
      stageEl,
      getFrameMetrics: () => metricsRef.current,
      getState: () => stateRef.current,
      onStep: stepRail,
      onHoverSlot: (slot, pointer) => {
        setHoveredSlot(slot);
        setIsPointer(pointer);
      },
      onClickFront: () => setDetailMode(!stateRef.current.detailOpen),
      onClickRailSlot: handleClickRailSlot,
      onCloseDetail: () => setDetailMode(false)
    });
    return () => {
      cleanup();
      stateRef.current.railTimers.forEach(clearTimeout);
    };
  }, [handleClickRailSlot, setDetailMode, stepRail]);

  const activeProduct = products[displayIdx] || products[0] || {};
  const thumbTop = activeTab === 0 ? 0 : activeTab === 1 ? 200 : 400;

  const renderInfoAndPanel = forMobile => (
    <>
      <div className={`hina-info ${swappingText ? 'hina-swap-out' : ''}`}>
        <div className="hina-counter">
          <span className="hina-line-mask">
            <span
              ref={el => {
                if (!forMobile) lineRefs.current[0] = el;
              }}
              className="hina-line-inner is-dynamic"
            >
              {pad2(displayIdx + 1)} / 12
            </span>
          </span>
        </div>

        <h1 className="hina-title">
          <span className="hina-line-mask">
            <span
              ref={el => {
                if (!forMobile) lineRefs.current[1] = el;
              }}
              className="hina-line-inner is-dynamic"
            >
              {activeProduct.title1}
            </span>
          </span>
          <span className="hina-line-mask">
            <span
              ref={el => {
                if (!forMobile) lineRefs.current[2] = el;
              }}
              className="hina-line-inner is-dynamic"
            >
              {activeProduct.title2}
            </span>
          </span>
        </h1>

        <div ref={!forMobile ? ruleRef : undefined} className="hina-rule" />

        <div className="hina-desc">
          <span className="hina-line-mask">
            <span
              ref={el => {
                if (!forMobile) lineRefs.current[3] = el;
              }}
              className="hina-line-inner is-dynamic"
            >
              {activeProduct.desc1}
            </span>
          </span>
          <span className="hina-line-mask">
            <span
              ref={el => {
                if (!forMobile) lineRefs.current[4] = el;
              }}
              className="hina-line-inner is-dynamic"
            >
              {activeProduct.desc2}
            </span>
          </span>
        </div>

        <div className="hina-specs">
          <div className="hina-spec-row">
            <span className="hina-spec-k">MATERIAL</span>
            <span className="hina-line-mask">
              <span
                ref={el => {
                  if (!forMobile) lineRefs.current[5] = el;
                }}
                className="hina-line-inner is-dynamic hina-spec-v"
              >
                {activeProduct.material}
              </span>
            </span>
          </div>
          <div className="hina-spec-row">
            <span className="hina-spec-k">COLOUR</span>
            <span className="hina-line-mask">
              <span
                ref={el => {
                  if (!forMobile) lineRefs.current[6] = el;
                }}
                className="hina-line-inner is-dynamic hina-spec-v"
              >
                {activeProduct.colour}
              </span>
            </span>
          </div>
          <div className="hina-spec-row">
            <span className="hina-spec-k">SIZE</span>
            <span className="hina-line-mask">
              <span
                ref={el => {
                  if (!forMobile) lineRefs.current[7] = el;
                }}
                className="hina-line-inner is-dynamic hina-spec-v"
              >
                {activeProduct.size}
              </span>
            </span>
          </div>
        </div>

        <button
          ref={!forMobile ? viewBtnRef : undefined}
          type="button"
          className="hina-view-btn"
          onClick={() => setDetailMode(!detailOpen)}
        >
          <span>VIEW DETAILS</span>
          <svg viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1" aria-hidden="true">
            <path d="M1.5 8.5 L8.5 1.5" />
            <path d="M3.5 1.5 H8.5 V6.5" />
          </svg>
        </button>
      </div>

      {/* Pager */}
      <div ref={!forMobile ? pagerRef : undefined} className={`hina-pager ${swappingText ? 'hina-swap-out' : ''}`}>
        <button type="button" className="hina-pager-btn" aria-label="Previous piece" onClick={() => stepRail(-1)}>
          <svg viewBox="0 0 36 12" fill="none" stroke="currentColor" strokeWidth="1" aria-hidden="true">
            <line x1="35" y1="6" x2="2" y2="6" />
            <path d="M7 1.5 L1.5 6 L7 10.5" />
          </svg>
        </button>
        <div className="hina-pager-count">
          <span className="hina-line-mask">
            <span className="hina-line-inner is-dynamic">{pad2(displayIdx + 1)} / 12</span>
          </span>
        </div>
        <button type="button" className="hina-pager-btn" aria-label="Next piece" onClick={() => stepRail(1)}>
          <svg viewBox="0 0 36 12" fill="none" stroke="currentColor" strokeWidth="1" aria-hidden="true">
            <line x1="1" y1="6" x2="34" y2="6" />
            <path d="M29 1.5 L34.5 6 L29 10.5" />
          </svg>
        </button>
      </div>

      {/* Detail Panel */}
      <aside ref={panelRef} className="hina-panel" aria-label="Garment details">
        <button type="button" className="hina-panel-back" onClick={() => setDetailMode(false)}>
          <span>BACK TO COLLECTION</span>
          <svg width="9" height="9" viewBox="0 0 9 9" fill="none" stroke="currentColor" strokeWidth="1" aria-hidden="true">
            <path d="M1 1 L8 8 M8 1 L1 8" />
          </svg>
        </button>

        <div className="hina-panel-head">
          <span>{HINA_TABS[activeTab].name}</span>
          <span>{pad2(activeTab + 1)} / 03</span>
        </div>

        <div className="hina-panel-tabs" role="tablist">
          {HINA_TABS.map(tab => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={activeTab === tab.id}
              className={`hina-tab-btn ${activeTab === tab.id ? 'is-active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.key}
            </button>
          ))}
        </div>

        <div ref={panelBoxRef} className="hina-panel-box">
          {HINA_TABS.map(tab => {
            const layerStyle = computeDetailLayerStyle({
              pieceIndex: cur,
              tabIndex: tab.id,
              boxW: forMobile ? boxSize.w : 270,
              boxH: forMobile ? boxSize.h : 470,
              assets
            });
            return (
              <div
                key={tab.id}
                className={`hina-panel-layer ${activeTab === tab.id ? 'is-active' : ''}`}
                style={layerStyle}
              />
            );
          })}
        </div>

        <p className="hina-panel-caption">{HINA_TABS[activeTab].caption}</p>

        <div className="hina-panel-track" aria-hidden="true">
          <div className="hina-panel-thumb" style={{ top: `${thumbTop}px` }} />
        </div>
      </aside>
    </>
  );

  return (
    <div
      ref={pageRef}
      className={`hina-page hina-pre ${detailOpen ? 'detail' : ''} ${slowTrans ? 'hina-slow' : ''}`}
    >
      <div className="hina-wall" aria-hidden="true" />

      {/* Top Navigation */}
      <header ref={navRef} className="hina-nav">
        <a href="#/" className="hina-logo">
          HINA
        </a>

        <nav className="hina-nav-center" aria-label="HINA sections">
          <a href="#/hina" className="hina-nav-link is-active" onClick={e => e.preventDefault()}>
            CLOTHING
          </a>
          <span className="hina-nav-link">ACCESSORY</span>
          <span className="hina-nav-link">JOURNAL</span>
          <span className="hina-nav-link">ABOUT</span>
        </nav>

        <div className="hina-nav-right">
          <span className="hina-nav-search">SEARCH</span>
          <span className="hina-nav-menu-label">MENU</span>
          <span className="hina-burger" aria-hidden="true">
            <span />
            <span />
            <span />
          </span>
        </div>
      </header>

      {/* Rail Stage */}
      <div ref={stageRef} className={`hina-stage ${isPointer ? 'is-pointer' : ''}`}>
        <div ref={frameRef} className="hina-frame">
          <div className="hina-shadow" style={{ top: `${shadowTop.toFixed(1)}px` }} aria-hidden="true" />

          <svg ref={tubeRef} className="hina-tube" viewBox="0 0 1440 900" aria-hidden="true">
            <defs>
              <linearGradient id="hina-rail-grad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FFFFFF" />
                <stop offset="55%" stopColor="#F3F1F5" />
                <stop offset="100%" stopColor="#C9C5D0" />
              </linearGradient>
            </defs>
            <polygon points={railPolygonPoints} fill="url(#hina-rail-grad)" />
          </svg>

          <div className="hina-garments">
            {HINA_SPRITES.map((sp, idx) => {
              const slot = (idx - cur + 12) % 12;
              const isExit = exitingPiece === idx;
              const isEnter = enteringPiece === idx;
              const overrideSlot = isExit || isEnter ? -1.3 : null;
              const overrideZ = isEnter ? 140 : isExit ? 130 : null;

              const placement = computePiecePlacement({
                index: idx,
                slot,
                isDetail: detailOpen,
                hoveredSlot,
                overrideSlot,
                overrideZ
              });

              return (
                <div
                  key={idx}
                  ref={el => {
                    garmentRefs.current[idx] = el;
                  }}
                  className={`hina-garment ${isEnter ? 'no-trans' : ''}`}
                  style={{
                    width: `${sp.w}px`,
                    height: `${sp.h}px`,
                    backgroundImage: `url("${assets.sprite}")`,
                    backgroundSize: `${HINA_SPRITE_NATIVE_W}px ${HINA_SPRITE_NATIVE_H}px`,
                    backgroundPosition: `${-sp.x}px ${-sp.y}px`,
                    transformOrigin: `${sp.hookX - sp.x}px 0px`,
                    transform: placement.transform,
                    opacity: placement.opacity,
                    filter: placement.filter,
                    zIndex: placement.zIndex
                  }}
                />
              );
            })}
          </div>

          {/* Desktop Frame UI */}
          <div className="hina-frame-ui">
            {!isPhone && renderInfoAndPanel(false)}

            <div ref={indexRef} className="hina-index">
              <span>{pad2(displayIdx + 1)}</span>
              <div className="hina-index-track">
                <div
                  className="hina-index-fill"
                  style={{ transform: `scaleY(${((cur + 1) / 12).toFixed(4)})` }}
                />
              </div>
              <span className="hina-index-total">12</span>
            </div>

            <div ref={footerRef} className="hina-footer">
              HINA · LITTLE WARDROBE | 07
            </div>

            <div ref={hintRef} className="hina-hint">
              <span>CLICK TO PEEK</span>
              <svg viewBox="0 0 20 10" fill="none" stroke="currentColor" strokeWidth="1" aria-hidden="true">
                <line x1="2" y1="5" x2="18" y2="5" />
                <path d="M5 2 L1.5 5 L5 8" />
                <path d="M15 2 L18.5 5 L15 8" />
              </svg>
              <span>CLICK AGAIN TO FOLLOW</span>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Scrollable UI below Stage */}
      {isPhone && <section className="hina-mobile-flow">{renderInfoAndPanel(true)}</section>}
    </div>
  );
}
