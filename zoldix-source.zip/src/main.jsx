import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import ErrorBoundary from './components/ErrorBoundary.jsx';
import App from './App.jsx';
import './index.css';

if (typeof window !== 'undefined') {
  window.addEventListener('error', event => {
    console.warn('Handled runtime error:', event?.message || event);
  });
  window.addEventListener('unhandledrejection', event => {
    console.warn('Handled promise rejection:', event?.reason || event);
  });
}

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ErrorBoundary label="Application">
      <HashRouter>
        <App />
      </HashRouter>
    </ErrorBoundary>
  </StrictMode>
);
