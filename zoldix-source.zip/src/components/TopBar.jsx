import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { loadSiteConfig, subscribeSiteConfig } from '../config/siteConfig.js';

const SECTION_NAV = [
  { id: 'sec-vestra', label: 'VESTRA' },
  { id: 'sec-flex', label: 'Lookbook' },
  { id: 'sec-hina', label: 'HINA' },
  { id: 'sec-circular', label: 'Silhouettes' },
  { id: 'sec-aero', label: 'AERO' },
  { id: 'sec-orbit', label: 'Orbit' },
  { id: 'sec-zestwell', label: 'Zestwell' }
];

export default function TopBar() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [brand, setBrand] = useState(() => loadSiteConfig().brand);

  useEffect(() => {
    return subscribeSiteConfig(cfg => {
      if (cfg?.brand) setBrand(cfg.brand);
    });
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const jumpToSection = sectionId => {
    setOpen(false);
    const scrollTarget = () => {
      const el = document.getElementById(sectionId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    };
    if (pathname !== '/') {
      navigate('/');
      setTimeout(scrollTarget, 160);
    } else {
      scrollTarget();
    }
  };

  return (
    <header className="zoldix-topbar">
      <div className="zoldix-topbar-inner">
        <Link to="/" className="zoldix-brand-link" aria-label={brand.siteName || 'ZOLDIX'}>
          <span className="zoldix-brand-dot" aria-hidden="true" />
          <span>{brand.logoText || brand.siteName || 'ZOLDIX'}</span>
        </Link>

        <nav className="zoldix-nav-links" aria-label="Main navigation">
          {SECTION_NAV.map(item => (
            <button
              key={item.id}
              type="button"
              className="zoldix-nav-link"
              onClick={() => jumpToSection(item.id)}
            >
              {item.label}
            </button>
          ))}
          <Link
            to="/admin"
            className={`zoldix-nav-link is-admin ${pathname === '/admin' ? 'is-active' : ''}`.trim()}
          >
            Admin
          </Link>
        </nav>

        <button
          type="button"
          className="zoldix-burger"
          aria-label={open ? 'Close navigation menu' : 'Open navigation menu'}
          aria-expanded={open}
          onClick={() => setOpen(v => !v)}
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {open && (
        <nav className="zoldix-mobile-drawer" aria-label="Mobile navigation">
          {SECTION_NAV.map(item => (
            <button
              key={item.id}
              type="button"
              className="zoldix-mobile-item"
              onClick={() => jumpToSection(item.id)}
            >
              <span>{item.label}</span>
              <span aria-hidden="true">→</span>
            </button>
          ))}
          <Link to="/admin" className={pathname === '/admin' ? 'is-active' : ''}>
            <span>Admin Panel</span>
            <span aria-hidden="true">→</span>
          </Link>
        </nav>
      )}
    </header>
  );
}
