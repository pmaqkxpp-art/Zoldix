import { useEffect, useRef, useState } from 'react';
import { getRouteLabel, preloadRouteAssets, scheduleIdlePrefetch } from '../config/preload.js';
import { loadSiteConfig, subscribeSiteConfig } from '../config/siteConfig.js';
import './loader.css';

export default function Loader({ routePath, onReadyChange }) {
  const [brand, setBrand] = useState(() => loadSiteConfig().brand);
  const [visible, setVisible] = useState(() => loadSiteConfig().brand?.loaderEnabled !== false);
  const [exiting, setExiting] = useState(false);
  const [progress, setProgress] = useState(6);
  const isFirstEntryRef = useRef(true);
  const targetRef = useRef(0.06);
  const currentRef = useRef(0.06);

  useEffect(() => {
    return subscribeSiteConfig(cfg => {
      if (cfg?.brand) setBrand(cfg.brand);
    });
  }, []);

  useEffect(() => {
    const bootEl = document.getElementById('zoldix-boot-loader');
    const latestBrand = loadSiteConfig().brand || brand;
    const enabled = latestBrand.loaderEnabled !== false;

    // Remove the plain HTML boot overlay once React Loader mounts cleanly
    if (bootEl && !bootEl.classList.contains('is-hidden')) {
      bootEl.classList.add('is-hidden');
    }

    if (!enabled) {
      setVisible(false);
      setExiting(false);
      onReadyChange(true);
      scheduleIdlePrefetch(routePath);
      return undefined;
    }

    let cancelled = false;
    let rafId = 0;
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    const minDurationMs = reduced ? 120 : 600;
    const maxFailsafeMs = 6000;
    const startTime = performance.now();

    targetRef.current = 0.08;
    currentRef.current = isFirstEntryRef.current ? 0.14 : 0.06;
    isFirstEntryRef.current = false;

    setVisible(true);
    setExiting(false);
    setProgress(Math.round(currentRef.current * 100));
    onReadyChange(false);

    let finished = false;
    let assetsDone = false;

    const triggerExit = () => {
      if (cancelled || finished) return;
      finished = true;
      targetRef.current = 1;
      currentRef.current = 1;
      setProgress(100);
      setExiting(true);
      const exitMs = reduced ? 100 : 500;
      setTimeout(() => {
        if (cancelled) return;
        setVisible(false);
        setExiting(false);
        onReadyChange(true);
        scheduleIdlePrefetch(routePath);
      }, exitMs);
    };

    const tick = now => {
      if (cancelled || finished) return;
      const elapsed = now - startTime;
      const target = assetsDone ? 1 : Math.max(targetRef.current, Math.min(0.88, elapsed / 2400));
      const next = currentRef.current + (target - currentRef.current) * (reduced ? 0.45 : 0.14);
      currentRef.current = Math.max(currentRef.current, Math.min(1, next));
      setProgress(Math.min(100, Math.round(currentRef.current * 100)));

      if (assetsDone && elapsed >= minDurationMs && currentRef.current > 0.985) {
        triggerExit();
        return;
      }
      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);

    preloadRouteAssets(routePath, (done, total) => {
      if (cancelled) return;
      const ratio = total > 0 ? done / total : 1;
      targetRef.current = Math.max(targetRef.current, Math.min(0.96, ratio * 0.96));
    }).then(() => {
      if (cancelled) return;
      assetsDone = true;
      targetRef.current = 1;
    });

    const failsafeTimer = setTimeout(() => {
      assetsDone = true;
      triggerExit();
    }, maxFailsafeMs);

    return () => {
      cancelled = true;
      cancelAnimationFrame(rafId);
      clearTimeout(failsafeTimer);
    };
  }, [routePath]);

  if (!visible) return null;

  const title = (brand?.loaderTitle || 'ZOLDIX').toUpperCase();
  const welcome = brand?.loaderWelcome || 'Welcome to Zoldix';
  const routeLabel = getRouteLabel(routePath);

  return (
    <div
      className={`zoldix-loader ${exiting ? 'is-exiting' : ''}`}
      role="status"
      aria-live="polite"
      data-loader-overlay="true"
    >
      <span className="zoldix-loader-sr">Loading</span>
      <div className="zoldix-loader-inner">
        <h1 className="zoldix-loader-title" key={title}>
          {title.split('').map((ch, idx) => (
            <span
              key={`${idx}-${ch}`}
              className="zoldix-loader-letter"
              style={{ animationDelay: `${idx * 55}ms` }}
            >
              {ch === ' ' ? '\u00A0' : ch}
            </span>
          ))}
        </h1>
        <p className="zoldix-loader-welcome">{welcome}</p>
        <div className="zoldix-loader-track" aria-hidden="true">
          <div className="zoldix-loader-fill" style={{ transform: `scaleX(${Math.max(0.02, progress / 100)})` }} />
        </div>
        <div className="zoldix-loader-pct" aria-hidden="true">
          {progress}%
        </div>
        {routeLabel && <div className="zoldix-loader-sub">Loading {routeLabel}</div>}
      </div>
    </div>
  );
}
