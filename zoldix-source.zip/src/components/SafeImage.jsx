import { useEffect, useState } from 'react';

export default function SafeImage({
  src,
  fallbackSrc,
  alt = '',
  loading = 'lazy',
  decoding = 'async',
  crossOrigin,
  className = '',
  style,
  onLoad,
  onError,
  ...rest
}) {
  const [currentSrc, setCurrentSrc] = useState(src || fallbackSrc || '');

  useEffect(() => {
    setCurrentSrc(src || fallbackSrc || '');
  }, [src, fallbackSrc]);

  const handleError = event => {
    if (fallbackSrc && currentSrc !== fallbackSrc) {
      setCurrentSrc(fallbackSrc);
    }
    if (onError) onError(event);
  };

  return (
    <img
      src={currentSrc}
      alt={alt}
      loading={loading}
      decoding={decoding}
      crossOrigin={crossOrigin}
      className={className}
      style={style}
      onLoad={onLoad}
      onError={handleError}
      {...rest}
    />
  );
}
