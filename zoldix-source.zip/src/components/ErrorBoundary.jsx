import React from 'react';
import { Link } from 'react-router-dom';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error) {
    return {
      hasError: true,
      errorMessage: error?.message || 'An unexpected rendering error occurred.'
    };
  }

  componentDidCatch(error, errorInfo) {
    console.error('Page ErrorBoundary caught:', error, errorInfo);
  }

  handleRetry = () => {
    this.setState({ hasError: false, errorMessage: '' });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: '100dvh',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '24px',
            background: '#0d0d10',
            color: '#f5f3ef',
            fontFamily: 'system-ui, sans-serif',
            textAlign: 'center',
            gap: '16px'
          }}
        >
          <p style={{ fontSize: '12px', letterSpacing: '0.2em', textTransform: 'uppercase', opacity: 0.65, margin: 0 }}>
            Section Recovery
          </p>
          <h2 style={{ fontSize: 'clamp(22px, 4vw, 32px)', fontWeight: 700, margin: 0 }}>
            {this.props.label || 'This experience'} hit a snag
          </h2>
          <p style={{ maxWidth: '44ch', fontSize: '14px', lineHeight: 1.5, opacity: 0.78, margin: 0 }}>
            {this.state.errorMessage}
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', marginTop: '8px', justifyContent: 'center' }}>
            <button
              type="button"
              onClick={this.handleRetry}
              style={{
                minHeight: '44px',
                padding: '0 20px',
                borderRadius: '999px',
                border: '1px solid rgba(255,255,255,0.22)',
                background: 'rgba(255,255,255,0.08)',
                color: '#f5f3ef',
                fontWeight: 600,
                fontSize: '13px'
              }}
            >
              Try Again
            </button>
            <Link
              to="/"
              style={{
                minHeight: '44px',
                padding: '0 20px',
                borderRadius: '999px',
                background: '#ff5a1f',
                color: '#0d0d10',
                fontWeight: 700,
                fontSize: '13px',
                display: 'inline-flex',
                alignItems: 'center',
                textDecoration: 'none'
              }}
            >
              Back to shop
            </Link>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
