import { useEffect, useState } from 'react';
import { loadSiteConfig, subscribeSiteConfig } from '../config/siteConfig.js';

export default function Footer() {
  const [brand, setBrand] = useState(() => loadSiteConfig().brand);

  useEffect(() => {
    return subscribeSiteConfig(cfg => {
      if (cfg?.brand) setBrand(cfg.brand);
    });
  }, []);

  const igUrl = brand?.instagramUrl || 'https://www.instagram.com/h6c.y';
  const igLabel = brand?.instagramLabel || 'Follow @h6c.y';

  return (
    <footer className="zoldix-footer">
      <div className="zoldix-footer-inner">
        <a
          href={igUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="zoldix-ig-link"
          data-no-ad="true"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
            <rect x="2.5" y="2.5" width="19" height="19" rx="5" />
            <circle cx="12" cy="12" r="4.2" />
            <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
          </svg>
          <span>{igLabel}</span>
        </a>
        <div className="zoldix-footer-meta">
          © {new Date().getFullYear()} {brand?.siteName || 'ZOLDIX'} — All collections &amp; ateliers
        </div>
      </div>
    </footer>
  );
}
