import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { loadSiteConfig, subscribeSiteConfig } from '../config/siteConfig.js';

const POSITION_BY_ROUTE = {
  '/mons': 'pos-top-left',
  '/vestra': 'pos-bottom-left',
  '/hina': 'pos-bottom-right',
  '/aero': 'pos-bottom-center-left',
  '/zestwell': 'pos-bottom-right'
};

export default function BackButton() {
  const { pathname } = useLocation();
  const [brand, setBrand] = useState(() => loadSiteConfig().brand);

  useEffect(() => {
    return subscribeSiteConfig(cfg => {
      if (cfg?.brand) setBrand(cfg.brand);
    });
  }, []);

  const posClass = POSITION_BY_ROUTE[pathname] || 'pos-bottom-left';
  const igUrl = brand?.instagramUrl || 'https://www.instagram.com/h6c.y';
  const igLabel = brand?.instagramLabel || 'Follow @h6c.y';

  return (
    <div className={`zoldix-immersive-dock ${posClass}`}>
      <Link to="/" className="zoldix-back-btn" aria-label="Back to shop">
        <ArrowLeft size={15} aria-hidden="true" />
        <span>Back to shop</span>
      </Link>

      <a
        href={igUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="zoldix-mini-ig"
        data-no-ad="true"
        aria-label={igLabel}
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
          <rect x="2.5" y="2.5" width="19" height="19" rx="5" />
          <circle cx="12" cy="12" r="4.2" />
          <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
        </svg>
        <span>{igLabel}</span>
      </a>
    </div>
  );
}
